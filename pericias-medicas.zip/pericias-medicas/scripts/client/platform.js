/* ===== Adaptador da versão própria (servidor + API): substitui os recursos do Claude ===== */
window.API_MODE = true;
const API = {
  async req(method, url, body) {
    const r = await fetch(url, { method, headers: body !== undefined ? { "content-type": "application/json" } : {}, body: body !== undefined ? JSON.stringify(body) : undefined, credentials: "same-origin" });
    if (r.status === 401 || (r.status === 403 && (await r.clone().json().catch(() => ({}))).code === "must_change")) { location.href = "/login.html"; throw { code: "unauthenticated" }; }
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw { code: j.code || (r.status === 403 ? "forbidden" : "invalid_argument"), message: j.message || "Erro " + r.status, status: r.status };
    return j;
  },
  get: u => API.req("GET", u), post: (u, b = {}) => API.req("POST", u, b), put: (u, b) => API.req("PUT", u, b), patch: (u, b) => API.req("PATCH", u, b), del: u => API.req("DELETE", u)
};
const ME = { user: null, ai: null };

(function () {
  const docRef = path => ({
    async get() { const j = await API.get("/api/kv?path=" + encodeURIComponent(path)); const v = j.value; return { exists: v != null, data: () => v, metadata: {} }; },
    set: v => API.put("/api/kv?path=" + encodeURIComponent(path), v),
    delete: () => API.del("/api/kv?path=" + encodeURIComponent(path))
  });
  const db = { doc: docRef, collection: p => ({ doc: k => docRef(p + "/" + k) }) };
  const user = { id: async () => String(ME.user.id), isOwner: () => ME.user.role === "admin" };

  /* ditado: reconhecimento de voz do navegador (Chrome/Edge), em português */
  function makeDictation() {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition; if (!SR) return null;
    let rec = null, want = false, cb = { p: () => {}, f: () => {}, s: () => {} };
    const start = () => new Promise((res, rej) => {
      want = true; rec = new SR(); rec.lang = "pt-BR"; rec.continuous = true; rec.interimResults = true;
      rec.onstart = () => { cb.s({ state: "listening" }); res(); };
      rec.onresult = e => { let interim = ""; for (let i = e.resultIndex; i < e.results.length; i++) { const r = e.results[i]; if (r.isFinal) cb.f({ text: r[0].transcript }); else interim += r[0].transcript; } cb.p({ text: interim }); };
      rec.onerror = e => { if (e.error === "not-allowed" || e.error === "service-not-allowed") { want = false; rej({ code: "not_granted" }); cb.s({ state: "idle", reason: "not_granted" }); } };
      rec.onend = () => { if (want) { try { rec.start(); } catch { want = false; cb.s({ state: "idle", reason: "stopped" }); } } else cb.s({ state: "idle", reason: "stopped" }); };
      try { rec.start(); } catch (e) { rej({ code: "dismissed" }); }
    });
    return { start, stop: async () => { want = false; try { rec?.stop(); } catch {} }, onPartial: f => (cb.p = f), onFinal: f => (cb.f = f), onState: f => (cb.s = f) };
  }
  const downloads = { async save({ filename, data }) { const blob = data instanceof Blob ? data : new Blob([data]); const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = filename; document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 2000); return { status: "saved" }; } };
  const sample = { limits: async () => (ME.ai?.images ? { maxPromptBytes: 4e6, images: { maxCount: 8, maxInputBytes: 20e6, mediaTypes: ["image/jpeg", "image/png", "image/webp"] } } : { maxPromptBytes: 4e6 }) };

  const ready = (async () => {
    try { ME.user = await API.get("/api/me"); } catch { return; }
    ME.ai = await API.get("/api/ai/status").catch(() => ({ configured: false }));
  })();
  window.claude = {
    use: async name => {
      await ready; if (!ME.user) return null;
      if (name === "db") return db; if (name === "user") return user; if (name === "downloads") return downloads;
      if (name === "dictation") return makeDictation();
      if (name === "sample") return ME.ai?.configured ? sample : null;
      return null;
    }
  };
})();

/* Executa uma ação de IA no servidor (o servidor monta o prompt) e recebe o texto aos poucos. */
const blobToDataURL = b => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = rej; r.readAsDataURL(b); });
async function askAction(action, params, { json = false, images, onText, signal } = {}) {
  await KV.flush();
  const imgs = images ? await Promise.all(Array.from(images).map(blobToDataURL)) : undefined;
  let r;
  try { r = await fetch("/api/ai/run", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ action, params, json, images: imgs }), signal }); }
  catch (e) { throw { code: e.name === "AbortError" ? "cancelled" : "upstream_error", message: e.message }; }
  if (r.status === 401) { location.href = "/login.html"; throw { code: "unauthenticated" }; }
  if (!r.ok) { const j = await r.json().catch(() => ({})); throw { code: j.code || "upstream_error", message: j.message }; }
  const reader = r.body.getReader(), dec = new TextDecoder(); let buf = "", result = null, err = null;
  try {
    for (;;) {
      const { value, done } = await reader.read(); if (done) break;
      buf += dec.decode(value, { stream: true });
      let i; while ((i = buf.indexOf("\n\n")) >= 0) {
        const block = buf.slice(0, i); buf = buf.slice(i + 2);
        const ev = /^event: (\w+)/m.exec(block)?.[1], data = /^data: (.*)$/m.exec(block)?.[1]; if (!ev || !data) continue;
        const d = JSON.parse(data);
        if (ev === "text") onText?.({ text: d.text }); else if (ev === "done") result = d; else if (ev === "error") err = d;
      }
    }
  } catch (e) { throw { code: e.name === "AbortError" ? "cancelled" : "upstream_error", message: e.message }; }
  if (err) throw err;
  if (!result) throw { code: "upstream_error", message: "Resposta interrompida." };
  onText?.({ text: result.text });
  if (json) return result.json;
  return result.text + (result.truncated ? "\n\n<red>[Resposta interrompida por limite de tamanho — execute esta etapa novamente ou aumente o limite de tokens.]</red>" : "");
}
