/* ===================== ÁREA DO ADMINISTRADOR (versão própria) ===================== */
const fmtDT = ms => ms ? new Date(ms).toLocaleString("pt-BR", { day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit" }) : "—";
const ADMIN_PAGES = ["admin", "usuarios", "ia", "webhooks", "uso", "prompts", "quesitos"];
let ADM = {};

async function admUsuarios() {
  const us = await API.get("/api/admin/users"); ADM.users = us;
  return `<div class="page-h"><div><div class="eyebrow">Área do administrador</div><h1>Usuários</h1></div></div>
  <p class="lead">Cadastre cada perito com o e-mail dele. A plataforma gera uma senha temporária, que você entrega ao perito; no primeiro acesso ele cria a própria senha.</p>
  <div class="card"><h4>Novo usuário</h4><div class="row">
    <input id="nu-nome" placeholder="Nome (ex.: Dra. Ana Souza)" style="flex:1;min-width:200px"><input id="nu-email" type="email" placeholder="E-mail" style="flex:1;min-width:220px">
    <select id="nu-role" style="width:auto"><option value="perito">Perito</option><option value="admin">Administrador</option></select>
    <button class="btn primary" data-adm="addUser">+ Cadastrar</button></div></div>
  <div class="card"><table class="tbl"><thead><tr><th>Nome</th><th>E-mail</th><th>Perfil</th><th>Situação</th><th>Último acesso</th><th></th></tr></thead><tbody>
  ${us.map(u => `<tr class="${u.ativo ? "" : "off"}"><td><b>${esc(u.nome || "—")}</b>${u.id === ME.user.id ? ' <span class="chip sm">você</span>' : ""}</td><td>${esc(u.email)}</td>
    <td>${u.role === "admin" ? '<span class="role admin">Administrador</span>' : '<span class="role">Perito</span>'}</td>
    <td>${u.ativo ? (u.must_change ? '<span class="st warn">aguardando 1º acesso</span>' : '<span class="st ok">ativo</span>') : '<span class="st bad">desativado</span>'}</td>
    <td>${fmtDT(u.last_login)}</td>
    <td class="acts">${u.id === ME.user.id ? "" : `<button class="btn sm" data-adm="resetUser" data-id="${u.id}">Nova senha</button><button class="btn sm ${u.ativo ? "danger" : ""}" data-adm="toggleUser" data-id="${u.id}">${u.ativo ? "Desativar" : "Reativar"}</button>`}</td></tr>`).join("")}
  </tbody></table></div>`;
}

async function admIA() {
  const c = await API.get("/api/admin/ai"); ADM.ai = c;
  const TIERS = [["quick", "Rápido", "tarefas curtas: CID-11, organizar"], ["default", "Padrão", "fichamentos, preenchimento"], ["complex", "Máximo", "laudo, conclusão, quesitos, imagens"]];
  const hints = { anthropic: "claude-sonnet-5-5", openai: "nome do modelo na sua conta OpenAI", openrouter: "ex.: anthropic/claude-sonnet-… (veja openrouter.ai/models)" };
  const card = p => { const k = c.keys[p]; return `<div class="card prov ${c.provider === p ? "on" : ""}">
    <div class="prov-h"><label class="radio"><input type="radio" name="prov" value="${p}" ${c.provider === p ? "checked" : ""} data-adm-prov> <b>${esc(c.providers[p])}</b></label>${c.provider === p ? '<span class="chip sm">em uso</span>' : ""}</div>
    <div class="f wide"><span class="lbl">Chave de API</span>${k.cadastrada ? `<div class="row"><span class="keymask">••••••••••••${esc(k.final)}</span><span class="note">cadastrada em ${fmtDT(k.atualizada)}</span></div>` : '<div class="note">Nenhuma chave cadastrada.</div>'}
      <div class="row"><input type="password" autocomplete="off" id="key-${p}" placeholder="${k.cadastrada ? "Colar nova chave para substituir" : "Colar a chave aqui"}" style="flex:1">
      <button class="btn sm primary" data-adm="saveKey" data-p="${p}">Salvar chave</button>${k.cadastrada ? `<button class="btn sm danger" data-adm="delKey" data-p="${p}">Remover</button>` : ""}</div></div>
    <div class="grid three">${TIERS.map(([t, l, d]) => `<label class="f"><span class="lbl">Modelo ${l}</span><input data-model="${p}.${t}" value="${esc(c.models[p]?.[t] || "")}" placeholder="${esc(hints[p])}"><span class="hint">${d}</span></label>`).join("")}</div>
    <div class="bar"><button class="btn sm" data-adm="saveModels">Salvar modelos</button><button class="btn sm ai-btn" data-adm="testProv" data-p="${p}">${I.spark} Testar conexão</button><span class="note" id="test-${p}"></span></div></div>`; };
  return `<div class="page-h"><div><div class="eyebrow">Área do administrador</div><h1>IA e chaves de API</h1></div></div>
  <div class="admin-note">As chaves ficam criptografadas no servidor e nunca aparecem para os peritos nem no navegador. Depois de salva, a chave não é mostrada de novo — só os 4 últimos caracteres.</div>
  ${c.mock ? '<div class="autob done"><div><b>Modo de demonstração ligado (AI_MOCK=1).</b> As respostas são fixas e não usam as chaves. Desligue no arquivo .env para usar a IA de verdade.</div></div>' : ""}
  <p class="lead">Escolha o provedor em uso. Cada etapa usa o modelo da sua “profundidade”: rápido, padrão ou máximo. Os peritos usam a cota da chave cadastrada aqui.</p>
  ${["anthropic", "openai", "openrouter"].map(card).join("")}
  <div class="card"><label class="f"><span class="lbl">Limite de tokens por resposta</span><input type="number" id="maxTokens" value="${c.maxTokens}" min="1000" max="64000" style="width:160px"><span class="hint">Aumente se alguma etapa do laudo vier “interrompida por limite de tamanho”.</span></label><div class="bar"><button class="btn sm" data-adm="saveModels">Salvar</button></div></div>`;
}

async function admWebhooks() {
  const w = await API.get("/api/admin/webhooks"); ADM.wh = w;
  const evs = Object.entries(w.eventos).filter(([e]) => e !== "teste");
  return `<div class="page-h"><div><div class="eyebrow">Área do administrador</div><h1>Webhooks</h1></div></div>
  <p class="lead">Webhooks ligam a plataforma a outros sistemas (Zapier, Make, n8n, planilhas, sistemas do escritório). <b>Saída</b>: a plataforma avisa quando algo acontece. <b>Entrada</b>: outro sistema cria uma perícia para um perito.</p>
  <h3 class="h3">Saída — avisos enviados pela plataforma</h3>
  <div class="card"><h4>Novo webhook de saída</h4>
    <div class="row"><input id="wh-nome" placeholder="Nome (ex.: Zapier — planilha)" style="width:240px"><input id="wh-url" placeholder="https://..." style="flex:1;min-width:260px"></div>
    <div class="tagpick" style="margin:10px 0">${evs.map(([e, d]) => `<label><input type="checkbox" class="wh-ev" value="${e}" ${e === "laudo.gerado" ? "checked" : ""}> <b>${e}</b> — ${esc(d)}</label>`).join("")}</div>
    <label class="row note"><input type="checkbox" id="wh-dados" style="width:auto"> Incluir nº do processo e benefício (dados do processo — avalie a LGPD)</label>
    <div class="bar"><button class="btn primary" data-adm="addHook">+ Criar webhook</button></div></div>
  ${w.saida.length ? `<div class="card"><table class="tbl"><thead><tr><th>Nome</th><th>URL</th><th>Eventos</th><th>Situação</th><th></th></tr></thead><tbody>${w.saida.map(h => `<tr class="${h.ativo ? "" : "off"}"><td><b>${esc(h.nome || "—")}</b></td><td class="mono">${esc(h.url)}</td><td>${h.events.map(e => `<span class="chip sm">${esc(e)}</span>`).join(" ")}${h.incluir_dados ? ' <span class="chip sm warn">com dados</span>' : ""}</td><td>${h.ativo ? '<span class="st ok">ativo</span>' : '<span class="st">pausado</span>'}</td>
    <td class="acts"><button class="btn sm" data-adm="testHook" data-id="${h.id}">Testar</button><button class="btn sm" data-adm="toggleHook" data-id="${h.id}" data-on="${h.ativo}">${h.ativo ? "Pausar" : "Ativar"}</button><button class="icon-btn" data-adm="delHook" data-id="${h.id}">${I.trash}</button></td></tr>`).join("")}</tbody></table>
    <p class="note">Cada envio leva o cabeçalho <code>X-Pericias-Assinatura: sha256=…</code> (HMAC do corpo com o segredo mostrado na criação), para o sistema de destino confirmar que veio da plataforma.</p></div>` : ""}
  <h3 class="h3">Entrada — outros sistemas criam perícias</h3>
  <div class="card"><div class="row"><input id="in-nome" placeholder="Nome da integração (ex.: Zapier — e-mail de nomeação)" style="flex:1"><button class="btn primary" data-adm="addInbound">+ Gerar endereço de entrada</button></div>
    ${w.entrada.length ? `<table class="tbl" style="margin-top:10px"><tbody>${w.entrada.map(t => `<tr><td><b>${esc(t.nome)}</b></td><td>criado em ${fmtDT(t.created_at)}</td><td class="acts"><button class="icon-btn" data-adm="delInbound" data-id="${t.id}">${I.trash}</button></td></tr>`).join("")}</tbody></table>` : ""}
    <details style="margin-top:10px"><summary><b>Formato do envio (JSON)</b></summary><pre class="pre">POST {endereço de entrada}
{
  "perito_email": "perito@exemplo.com",
  "processo": { "numero": "0001234-55.2026.4.01.3600", "juizo": "JEF Cuiabá", "beneficio": "auxdoenca", "data": "2026-12-01", "horario": "09:30", "local": "Cuiabá-MT" },
  "periciando": { "nome": "Nome do periciando", "cpf": "000.000.000-00" },
  "quesitos": { "modelos": ["auxdoenca"], "autor": "1. ...", "reu": "1. ..." }
}
Benefícios: ${BENEFICIOS.map(b => b[0]).join(", ")}
Modelos de quesitos: ${S.qt.map(t => t.id).join(", ")}</pre></details></div>
  <h3 class="h3">Últimos envios</h3>
  <div class="card">${w.log.length ? `<table class="tbl"><thead><tr><th>Quando</th><th>Direção</th><th>Evento</th><th>Status</th><th>Detalhe</th></tr></thead><tbody>${w.log.map(l => `<tr><td>${fmtDT(l.created_at)}</td><td>${l.direcao}</td><td>${esc(l.evento)}</td><td>${l.status >= 200 && l.status < 300 ? `<span class="st ok">${l.status}</span>` : `<span class="st bad">${l.status ?? "—"}</span>`}</td><td class="note">${esc(l.detalhe || "")}</td></tr>`).join("")}</tbody></table>` : '<div class="note">Nenhum envio ainda.</div>'}</div>`;
}

async function admUso() {
  const u = await API.get("/api/admin/usage");
  return `<div class="page-h"><div><div class="eyebrow">Área do administrador</div><h1>Uso da IA</h1></div></div>
  <p class="lead">Chamadas e tokens por perito e por mês. O custo em reais depende do preço do provedor e do modelo; confira no painel do provedor.</p>
  <div class="card">${u.length ? `<table class="tbl"><thead><tr><th>Mês</th><th>Perito</th><th>Provedor</th><th class="r">Chamadas</th><th class="r">Tokens de entrada</th><th class="r">Tokens de saída</th><th class="r">Falhas</th></tr></thead><tbody>${u.map(r => `<tr><td>${esc(r.mes)}</td><td><b>${esc(r.nome || "—")}</b><div class="note">${esc(r.email || "")}</div></td><td>${esc(r.provider || "")}</td><td class="r">${r.chamadas}</td><td class="r">${(r.entrada || 0).toLocaleString("pt-BR")}</td><td class="r">${(r.saida || 0).toLocaleString("pt-BR")}</td><td class="r">${r.falhas || 0}</td></tr>`).join("")}</tbody></table>` : '<div class="note">Nenhum uso registrado ainda.</div>'}</div>`;
}

function senhaCard() {
  return `<div class="card" style="margin-top:22px"><h4>Trocar minha senha</h4><div class="row">
    <input type="password" id="pw-atual" placeholder="Senha atual" autocomplete="current-password" style="width:200px">
    <input type="password" id="pw-nova" placeholder="Nova senha (mín. 10, letras e números)" autocomplete="new-password" style="flex:1;min-width:240px">
    <button class="btn" data-adm="changePw">Trocar senha</button></div></div>`;
}

async function renderAdminPage(h) {
  const m = $("#main"); m.innerHTML = `<div class="empty big">${SPIN} Carregando…</div>`;
  try {
    const html = await ({ usuarios: admUsuarios, ia: admIA, webhooks: admWebhooks, uso: admUso }[h])();
    if ((location.hash || "").slice(1) === h) m.innerHTML = html;
  } catch (e) { m.innerHTML = `<div class="empty big">Não foi possível carregar: ${esc(e.message || e.code || "")}</div>`; }
}

function showSecret(title, text, extra = "") {
  modal({ title, body: `<p>${extra}</p><div class="secret"><code id="sec-v">${esc(text)}</code></div><p class="note">Copie agora: por segurança, ele não será mostrado de novo.</p>`, actions: [{ label: "Copiar", cls: "", value: "c" }, { label: "Fechar" }] })
    .then(v => { if (v === "c") navigator.clipboard?.writeText(text).then(() => toast("Copiado.", "ok")).catch(() => {}); });
}

document.addEventListener("click", async e => {
  const b = e.target.closest("[data-adm]"); if (!b) return;
  const act = b.dataset.adm, id = b.dataset.id, p = b.dataset.p;
  const reload = () => renderAdminPage((location.hash || "").slice(1));
  try {
    if (act === "addUser") {
      const r = await API.post("/api/admin/users", { nome: $("#nu-nome").value, email: $("#nu-email").value, role: $("#nu-role").value });
      showSecret("Usuário cadastrado", r.senhaTemporaria, `Entregue ao usuário o endereço da plataforma, o e-mail <b>${esc($("#nu-email").value)}</b> e esta senha temporária:`); reload();
    } else if (act === "resetUser") {
      const u = ADM.users.find(x => x.id === +id);
      if (await confirmar("Gerar nova senha", `Gerar uma senha temporária para ${u.email}? A senha atual deixa de funcionar.`, "Gerar")) { const r = await API.patch("/api/admin/users/" + id, { resetSenha: true }); showSecret("Nova senha temporária", r.senhaTemporaria, `Para <b>${esc(u.email)}</b>:`); reload(); }
    } else if (act === "toggleUser") {
      const u = ADM.users.find(x => x.id === +id);
      if (!u.ativo || await confirmar("Desativar usuário", `${u.email} não conseguirá mais entrar. As perícias dele são mantidas.`, "Desativar", "danger")) { await API.patch("/api/admin/users/" + id, { ativo: !u.ativo }); reload(); }
    } else if (act === "saveKey") {
      const v = $("#key-" + p).value.trim(); if (!v) return toast("Cole a chave primeiro.", "err");
      await API.put("/api/admin/ai/key/" + p, { key: v }); toast("Chave salva com criptografia.", "ok"); reload();
    } else if (act === "delKey") {
      if (await confirmar("Remover chave", "Remover a chave deste provedor? Se ele estiver em uso, a IA para de funcionar.", "Remover", "danger")) { await API.put("/api/admin/ai/key/" + p, { key: "" }); reload(); }
    } else if (act === "saveModels") {
      const models = {}; $$("[data-model]").forEach(i => { const [pp, t] = i.dataset.model.split("."); (models[pp] ||= {})[t] = i.value; });
      await API.put("/api/admin/ai", { models, maxTokens: +($("#maxTokens")?.value || 16000) }); toast("Configuração salva.", "ok");
    } else if (act === "testProv") {
      const el = $("#test-" + p); el.innerHTML = SPIN + " testando…";
      const models = {}; $$("[data-model]").forEach(i => { const [pp, t] = i.dataset.model.split("."); (models[pp] ||= {})[t] = i.value; }); await API.put("/api/admin/ai", { models });
      const r = await API.post("/api/admin/ai/test/" + p); el.innerHTML = r.ok ? `<span class="st ok">${I.check} ${esc(r.message)}</span>` : `<span class="st bad">${esc(r.message)}</span>`;
    } else if (act === "addHook") {
      const r = await API.post("/api/admin/webhooks", { nome: $("#wh-nome").value, url: $("#wh-url").value, events: $$(".wh-ev:checked").map(x => x.value), incluirDados: $("#wh-dados").checked });
      showSecret("Webhook criado", r.segredo, "Segredo para conferir a assinatura dos envios (configure no sistema de destino):"); reload();
    } else if (act === "testHook") {
      b.disabled = true; const r = await API.post(`/api/admin/webhooks/${id}/test`); toast(r.ok ? `Entregue (HTTP ${r.status}).` : `Falhou${r.status ? " (HTTP " + r.status + ")" : ""}: ${r.erro || "veja o registro"}`, r.ok ? "ok" : "err"); reload();
    } else if (act === "toggleHook") { await API.patch("/api/admin/webhooks/" + id, { ativo: b.dataset.on !== "1" }); reload(); }
    else if (act === "delHook") { if (await confirmar("Remover webhook", "Remover este webhook de saída?", "Remover", "danger")) { await API.del("/api/admin/webhooks/" + id); reload(); } }
    else if (act === "addInbound") {
      const r = await API.post("/api/admin/inbound", { nome: $("#in-nome").value || "Entrada" });
      showSecret("Endereço de entrada criado", location.origin + r.url, "Configure o outro sistema para enviar POST (JSON) para este endereço. Quem tiver o endereço consegue criar perícias: guarde-o como uma senha."); reload();
    } else if (act === "delInbound") { if (await confirmar("Remover endereço", "Sistemas que usam este endereço deixarão de funcionar.", "Remover", "danger")) { await API.del("/api/admin/inbound/" + id); reload(); } }
    else if (act === "changePw") {
      await API.post("/api/auth/password", { atual: $("#pw-atual").value, nova: $("#pw-nova").value }); $("#pw-atual").value = $("#pw-nova").value = ""; toast("Senha alterada.", "ok");
    } else if (act === "logout") { await API.post("/api/auth/logout"); location.href = "/login.html"; }
  } catch (err) { if (err.code !== "unauthenticated") toast(err.message || "Não foi possível concluir.", "err"); }
});
document.addEventListener("change", async e => {
  if (e.target.matches("[data-adm-prov]")) { try { await API.put("/api/admin/ai", { provider: e.target.value }); toast("Provedor em uso alterado.", "ok"); renderAdminPage("ia"); } catch (err) { toast(err.message, "err"); } }
});
