"""Gera shared/defs.js (público, sem prompts) e server/defaults.js (prompts, só servidor)
a partir de scripts/plataforma/data.js e data2.js.  Uso: python3 scripts/split_defs.py"""
import re, os
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE)
src = open(f'{HERE}/plataforma/data.js').read() + '\n' + open(f'{HERE}/plataforma/data2.js').read()
chunks, cur, name = [], [], None
starts = re.compile(r'^(const (\w+)|DEFAULT_AUX\.(\w+))')
for ln in src.split('\n'):
    m = starts.match(ln)
    if m:
        if cur: chunks.append((name, '\n'.join(cur)))
        name = m.group(2) or ('DEFAULT_AUX.' + m.group(3)); cur = [ln]
    elif name is not None: cur.append(ln)
if cur: chunks.append((name, '\n'.join(cur)))
SERVER = {'DEFAULT_RULES', 'DEFAULT_FORMAT', 'MODELO_ANAMNESE_1_4', 'MODELO_ANAMNESE_SIMPLES', 'MODELO_ANAMNESE_5', 'DEFAULT_STEPS', 'DEFAULT_AUX', 'AUX_IMAGEM', 'AUX_CID11'}
is_server = lambda n: n in SERVER or n.startswith('DEFAULT_AUX.')
shared = [c for n, c in chunks if not is_server(n)]; names = [n for n, c in chunks if not is_server(n)]
server = [c for n, c in chunks if is_server(n)]
helpers = open(f'{HERE}/sh_helpers.js').read()
out = ('/* Definições compartilhadas entre o servidor e o navegador.\n   NÃO coloque prompts aqui: este arquivo é público. Os prompts ficam em server/defaults.js.\n   Arquivo gerado por scripts/split_defs.py */\n(function (root) {\n'
       + '\n'.join(shared) + '\n' + helpers + '  const api = { ' + ', '.join(names + ['SH']) + ' };\n'
       + '  if (typeof module !== "undefined" && module.exports) module.exports = api; else Object.assign(root, api);\n})(typeof window !== "undefined" ? window : globalThis);\n')
open(f'{ROOT}/shared/defs.js', 'w').write(out)
sv = ('/* Prompts padrão — SIGILOSOS: ficam só no servidor e nunca são enviados ao navegador dos peritos.\n   Arquivo gerado por scripts/split_defs.py */\n'
      + '\n'.join(server) + '\nmodule.exports = { DEFAULT_RULES, DEFAULT_FORMAT, MODELO_ANAMNESE_1_4, MODELO_ANAMNESE_SIMPLES, MODELO_ANAMNESE_5, DEFAULT_STEPS, DEFAULT_AUX };\n')
open(f'{ROOT}/server/defaults.js', 'w').write(sv)
print('shared:', len(names), 'itens | server:', len(server), 'itens')
