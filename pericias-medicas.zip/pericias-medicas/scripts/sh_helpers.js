/* ---------- utilitários puros usados pelo servidor e pelo navegador ---------- */
const SH = (() => {
  const fmtDate = iso => { if (!iso) return ""; const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(iso); return m ? `${m[3]}/${m[2]}/${m[1]}` : iso; };
  const benefLabel = id => (BENEFICIOS.find(b => b[0] === id) || [, ""])[1];
  const CATS = [["processo", "Documentos da Justiça"], ["pessoais", "Documentos pessoais"], ["saude", "Documentos de saúde"], ["imagens", "Imagens e exames de imagem"], ["outros", "Outros"]];
  const catLabel = id => (CATS.find(c => c[0] === id) || [, "Outros"])[1];
  const getPath = (o, p) => p.split(".").reduce((a, k) => (a == null ? a : a[k]), o);
  const norm = s => String(s || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase();
  const cidLine = x => x.c10 ? `${x.d10} — CID-10 ${x.c10}${x.c11 ? ` / CID-11 ${x.c11}` : ""}` : `${x.d11} — CID-11 ${x.c11}`;
  const restr = (ref, v) => (v === "" || v == null || isNaN(+v)) ? "" : Math.max(0, Math.round((ref - +v) / ref * 100));
  function testesCount(t) {
    if (!t) return 0;
    return Object.values(t.res || {}).filter(r => r && r.r).length + Object.values(t.gonio || {}).flatMap(o => Object.values(o || {})).filter(g => g && (g.d || g.e)).length + Object.values(t.med || {}).filter(m => m && (m.d || m.e)).length + (t.dor && t.dor.valor !== "" && t.dor.valor != null ? 1 : 0);
  }
  function testesTexto(t) {
    t = t || {}; const res0 = t.res || {}, gon = t.gonio || {}, med = t.med || {}, dor = t.dor || {};
    const feitos = [], res = [];
    for (const seg of Object.values(TESTES)) for (const [id, nome] of seg.testes) {
      const r = res0[id]; if (!r || !r.r || r.r === "Não realizado") continue;
      feitos.push(`${nome}${r.lado ? " (" + r.lado + ")" : ""}`);
      res.push(`${nome}${r.lado ? " — " + r.lado : ""}: ${r.r}${r.obs ? " (" + r.obs + ")" : ""}`);
    }
    const g = [];
    for (const [gk, j] of Object.entries(GONIO)) for (const [mid, mn, ref, ax] of j.mov) {
      const v = (gon[gk] || {})[mid]; if (!v || (!v.d && !v.e)) continue;
      const parts = [];
      if (v.d !== "" && v.d != null) parts.push(`${ax ? "" : "D "}${v.d}° (restrição ${restr(ref, v.d)}%)`);
      if (!ax && v.e !== "" && v.e != null) parts.push(`E ${v.e}° (restrição ${restr(ref, v.e)}%)`);
      if (parts.length) g.push(`${j.nome} — ${mn}: ${parts.join("; ")}; referência ${ref}°`);
    }
    if (g.length) { feitos.push("Goniometria"); res.push("Goniometria (referência AAOS): " + g.join(" | ")); }
    for (const [id, nome, un, bil] of MEDIDAS) { const v = med[id]; if (!v || (!v.d && !v.e)) continue; const s = `${nome}: ${bil ? [v.d ? `D ${v.d} ${un}` : "", v.e ? `E ${v.e} ${un}` : ""].filter(Boolean).join("; ") : `${v.d} ${un}`}${v.obs ? " (" + v.obs + ")" : ""}`; feitos.push(nome); res.push(s); }
    if (dor.valor !== "" && dor.valor != null) { feitos.push(dor.escala === "END" ? "Escala numérica de dor" : "Escala visual analógica de dor"); res.push(`Dor (${dor.escala || "EVA"}): ${dor.valor}/10${dor.local ? " — " + dor.local : ""}${dor.obs ? " (" + dor.obs + ")" : ""}`); }
    const i = feitos.join("; "), jj = res.map(x => "- " + x).join("\n");
    return { i, j: jj, all: feitos.length ? `3.2 i) ${i}\n3.2 j)\n${jj}` : "" };
  }
  return { fmtDate, benefLabel, CATS, catLabel, getPath, norm, cidLine, restr, testesCount, testesTexto };
})();

