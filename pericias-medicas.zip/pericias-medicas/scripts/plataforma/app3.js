/* ===================== ROTEAMENTO ===================== */
async function route() {
  let h = (location.hash || "#inicio").slice(1);
  if (!S.admin && ["prompts", "quesitos", "admin"].includes(h)) { location.hash = "#inicio"; return; }
  $$(".nav a").forEach(a => a.classList.toggle("on", a.getAttribute("href") === "#" + h || (h.startsWith("caso-") && a.dataset.nav === "inicio")));
  if (h.startsWith("caso-")) {
    const ok = await openCase(h.slice(5));
    if (!ok) { location.hash = "#inicio"; return; }
  }
  render();
}
function render() {
  const h = (location.hash || "#inicio").slice(1), m = $("#main");
  const sy = window.scrollY;
  if (h.startsWith("caso-") && S.cur) m.innerHTML = renderCase();
  else if (h === "perfil") m.innerHTML = renderPerfil();
  else if (h === "quesitos") m.innerHTML = renderQuesitosPage();
  else if (h === "prompts") m.innerHTML = renderPrompts();
  else if (h === "ajuda") m.innerHTML = renderAjuda();
  else if (h === "admin") m.innerHTML = renderAdminHome();
  else if (h === "modulos") m.innerHTML = renderModulos();
  else m.innerHTML = renderHome();
  $$("textarea[data-bind], textarea.transcript").forEach(autoGrow);
  DICT.refreshButtons(); loadThumbs(); initSigPad();
  if ($("#confbox") && S.cur) conferirIdent().then(r => { const b = $("#confbox"); if (b) b.innerHTML = confHTML(r); });
  window.scrollTo(0, sy);
}
function rerenderTab() {
  if (!S.cur || !location.hash.startsWith("#caso-")) return;
  const a = document.activeElement;
  if (a && $("#main").contains(a) && a.matches("input:not([type=file]),textarea,select,[contenteditable]")) { S.dirtyRender = true; return; }
  render();
}
document.addEventListener("focusout", () => setTimeout(() => { if (S.dirtyRender && !document.activeElement?.matches?.("input,textarea,select,[contenteditable]")) { S.dirtyRender = false; rerenderTab(); } }, 150));
function autoGrow(t) { t.style.height = "auto"; t.style.height = Math.min(Math.max(t.scrollHeight + 2, 46), 520) + "px"; }

/* ===================== EVENTOS ===================== */
document.addEventListener("input", e => {
  const t = e.target;
  if (t.dataset.bind && S.cur) {
    setPath(S.cur, t.dataset.bind, t.value); S.aiFilled.delete(t.dataset.bind); t.closest(".f")?.classList.remove("ai");
    if (t.tagName === "TEXTAREA") autoGrow(t);
    if (t.dataset.bind.startsWith("testes.")) refreshTestes();
    if (t.dataset.bind.startsWith("avaliacao.")) { const p = $("#avpend"); if (p) p.outerHTML = avalPendHTML(); }
    if (t.dataset.bind === "processo.numero" || t.dataset.bind === "periciando.nome") refreshConf();
    if (t.dataset.bind === "periciando.nasc" || t.dataset.bind === "processo.data") { S.cur.periciando.idade = idadeEm(S.cur.periciando.nasc, S.cur.processo.data); const i = $('[data-bind="periciando.idade"]'); if (i) i.value = S.cur.periciando.idade; }
    saveCase();
  } else if (t.dataset.ibind && S.cur) {
    const [id, k] = t.dataset.ibind.split("."); const iv = S.cur.entrevistas.find(x => x.id === id); if (iv) { iv[k] = t.value; saveCase(); }
    if (t.tagName === "TEXTAREA") autoGrow(t);
  } else if (t.dataset.pbind) { S.profile[t.dataset.pbind] = t.value; saveProfileD(); const pv = $(".paper.mini"); if (pv) { pv.querySelector(".ph").outerHTML = headerHTML(); pv.querySelector(".pf").outerHTML = footerHTML(); } }
  else if (t.dataset.padrao) { S.padrao[t.dataset.padrao] = t.value; savePadraoD(); const pv = $(".paper.mini .ph"); if (pv) pv.outerHTML = headerHTML(); }
  else if (t.dataset.imgdesc) { const d = S.cur.docs.find(x => x.id === t.dataset.imgdesc); if (d) { d.imgDesc = t.value; saveCase(); } }
  else if (t.id === "cidq") cidSearch(t.value);
  else if (t.dataset.pr) { S.prompts[t.dataset.pr] = t.value; savePromptsD(); }
  else if (t.dataset.pmod) { S.prompts.modelos[t.dataset.pmod] = t.value; savePromptsD(); }
  else if (t.dataset.tpad) { S.prompts.tipoPadrao = S.prompts.tipoPadrao || {}; S.prompts.tipoPadrao[t.dataset.tpad] = t.value; savePromptsD(); }
  else if (t.dataset.aux) { S.prompts.aux[t.dataset.aux] = t.value; savePromptsD(); }
  else if (t.dataset.sbind) { const [i, k] = t.dataset.sbind.split("."); let v = t.value; if (k === "ordemLaudo") v = +v || 0; if (k === "ativo") v = v === "1"; S.prompts.steps[+i][k] = v; savePromptsD(); }
  else if (t.dataset.qtbind) { const [i, k] = t.dataset.qtbind.split("."); S.qt[+i][k] = t.value; saveQtD(); }
  else if (t.id === "paper") { autoUnmark(t); S.html = t.innerHTML; syncSlot(); saveHtml(); marcarEditado(); }
  else if (t.dataset.modbind) { const [i, k] = t.dataset.modbind.split("."); S.modulos[+i][k] = t.value; saveModulosD(); }
  else if (t.dataset.homeq !== undefined) { S.homeQ = t.value; const pos = t.selectionStart; render(); const n = $("[data-homeq]"); n.focus(); n.setSelectionRange(pos, pos); }
});
const savePadraoD = debounce(() => savePadrao(), 800);
const saveModulosD = debounce(() => saveModulos(), 800);
const saveProfileD = debounce(saveProfile, 800), savePromptsD = debounce(savePrompts, 800), saveQtD = debounce(saveQt, 800);

document.addEventListener("change", e => {
  const t = e.target;
  if (t.dataset.upload) { handleFiles(t.files, t.dataset.upload); t.value = ""; }
  else if (t.dataset.doccat) { const d = S.cur.docs.find(x => x.id === t.dataset.doccat); if (d) { const wasImg = d.categoria === "imagens"; d.categoria = t.value; const isPic = ["jpg", "jpeg", "png", "webp"].includes(d.tipo);
      if (t.value === "imagens" && !d.analisado) { d.status = "imagem"; makeThumb(d); }
      else if (wasImg && d.status === "imagem") d.status = isPic ? "ocr" : (d.chars ? "pronto" : "erro");
      saveCase(); render(); } }
  else if (t.dataset.pagsel) { const d = S.cur.docs.find(x => x.id === t.dataset.pagsel); if (d) { d.pagSel = t.value.trim(); if (d.fichOk) { d.fichOk = false; toast("Seleção de páginas alterada: o documento será fichado de novo.", ""); } getText(d).then(tx => { d.charsIA = prepDocText(tx, d.pagSel).length; saveCase(); rerenderTab(); }); } }
  else if (t.dataset.stepon) { (S.cur.stepsOn ||= {})[t.dataset.stepon] = t.checked; saveCase(); render(); }
  else if (t.dataset.smod) { const st = S.prompts.steps[+t.dataset.smod], m = new Set(st.modalidades || []); t.checked ? m.add(t.value) : m.delete(t.value); st.modalidades = [...m]; savePrompts(); }
  else if (t.dataset.imgtipo) { const d = S.cur.docs.find(x => x.id === t.dataset.imgtipo); if (d) { d.imgTipo = t.value; saveCase(); } }
  else if (t.dataset.qtpl) { const q = S.cur.quesitos; q.templates = t.checked ? [...new Set([...q.templates, t.dataset.qtpl])] : q.templates.filter(x => x !== t.dataset.qtpl); saveCase(); render(); }
  else if (t.dataset.qttag) { const i = +t.dataset.qttag, tg = new Set(S.qt[i].tags || []); t.checked ? tg.add(t.value) : tg.delete(t.value); S.qt[i].tags = [...tg]; saveQt(); }
  else if (t.dataset.logo !== undefined && t.files[0]) setLogo(t.files[0]);
  else if (t.dataset.sigimg !== undefined && t.files[0]) { const f = t.files[0]; t.value = ""; sigFromImage(f); }
  else if (t.dataset.wordfix !== undefined && t.files[0]) { const f = t.files[0]; t.value = ""; wordCorrigido(f); }
  else if (t.dataset.sbind || (t.dataset.bind === "processo.beneficio")) render();
});

document.addEventListener("click", e => {
  const mic = e.target.closest("[data-mic]"); if (mic) { e.preventDefault(); DICT.toggle({ kind: "field", path: mic.dataset.mic, label: mic.dataset.miclabel }); return; }
  const rec = e.target.closest("[data-rec]"); if (rec) { DICT.toggle({ kind: "intv", id: rec.dataset.rec, label: "Entrevista" }); return; }
  const seg = e.target.closest("[data-seg] button"); if (seg) { const p = seg.parentElement.dataset.seg, cur = getPath(S.cur, p); setPath(S.cur, p, cur === seg.dataset.val ? "" : seg.dataset.val); saveCase(); $$("button", seg.parentElement).forEach(b => b.classList.toggle("on", getPath(S.cur, p) === b.dataset.val)); return; }
  const tr = e.target.closest("[data-tres]"); if (tr) { const r = S.cur.testes.res[tr.dataset.tres] ||= {}; r.r = r.r === tr.dataset.val ? "" : tr.dataset.val; saveCase(); render(); return; }
  const ts = e.target.closest("[data-tseg]"); if (ts) { const t = S.cur.testes; const k = ts.dataset.tseg; t.segs = t.segs.includes(k) ? t.segs.filter(x => x !== k) : [...t.segs, k]; saveCase(); render(); return; }
  const td = e.target.closest("[data-tdor]"); if (td) { S.cur.testes.dor.escala = td.dataset.tdor; saveCase(); render(); return; }
  const cm = e.target.closest("[data-cidmode]"); if (cm) { S.cidMode = cm.dataset.cidmode; render(); $("#cidq")?.focus(); return; }
  const ca = e.target.closest("[data-cidadd]"); if (ca) { cidAdd(ca.dataset.cidadd); return; }
  const ac = e.target.closest("[data-aceitar]"); if (ac) { aceitarSug(ac.dataset.aceitar); return; }
  const dm = e.target.closest("[data-docmode]"); if (dm) { setDoc(dm.dataset.docmode); return; }
  const cd = e.target.closest("[data-compdec]"); if (cd) { S.cur.complementar = S.cur.complementar || {}; S.cur.complementar.decisao = cd.dataset.compdec; saveCase(); rerenderTab(); return; }
  const ind = e.target.closest("[data-indireta]"); if (ind) { S.cur.indireta = { ...(S.cur.indireta || {}), sim: !!ind.dataset.indireta }; saveCase(); rerenderTab(); return; }
  const tl = e.target.closest("[data-tipolaudo]"); if (tl) { S.cur.tipoLaudo = tl.dataset.tipolaudo; saveCase(); rerenderTab(); return; }
  const ms = e.target.closest("[data-modsel]"); if (ms) { const sel = new Set(modulosDaPericia()); sel.has(ms.dataset.modsel) ? sel.delete(ms.dataset.modsel) : sel.add(ms.dataset.modsel); S.cur.modulos = [...sel]; saveCase(); render(); return; }
  const mk = e.target.closest("#paper span.red, #paper span.excesso, #paper span.investigar, #paper span.sugestao"); if (mk) { showRevPop(mk); } else if (!e.target.closest("#revpop")) hideRevPop();
  const rp = e.target.closest("[data-rev]"); if (rp) { revAction(rp.dataset.rev); return; }
  const vb = e.target.closest("[data-vel]"); if (vb) { S.vel = vb.dataset.vel; KV.set("prefs", { vel: S.vel }); render(); return; }
  const lv = e.target.closest("[data-lview]"); if (lv) { S.laudoView = lv.dataset.lview; render(); return; }
  const un = e.target.closest("[data-usenum]"); if (un) { S.cur.processo.numero = un.dataset.usenum; saveCase(); render(); toast("Nº do processo atualizado.", "ok"); return; }
  const unm = e.target.closest("[data-usenome]"); if (unm) { S.cur.periciando.nome = unm.dataset.usenome; saveCase(); render(); toast("Nome do periciando atualizado.", "ok"); return; }
  const tab = e.target.closest("[data-tab]"); if (tab) { S.tab = tab.dataset.tab; render(); window.scrollTo({ top: 0 }); return; }
  const a = e.target.closest("[data-act]"); if (!a) return;
  const act = a.dataset.act, id = a.dataset.id;
  const A = {
    newcase: async () => { const c = newCase(); c.processo.local = S.profile.cidade || ""; S.cur = c; S.out = { outputs: {} }; S.html = null; S.htmlP = null; S.htmlC = null; S.doc = "principal"; S.corrMsg = ""; S.texts = {}; S.fich = {}; S.files = {}; S.thumbs = {}; S.aiFilled = new Set(); S.tab = "documentos"; S.autoRun = null; await saveCaseNow(); location.hash = "#caso-" + c.id; },
    delcase: async () => { if (await confirmar("Excluir perícia", "Isso apaga a perícia, os documentos e o laudo. Não é possível desfazer.", "Excluir", "danger")) { await deleteCase(S.cur.id); location.hash = "#inicio"; toast("Perícia excluída."); } },
    deldoc: async () => { const d = S.cur.docs.find(x => x.id === id); if (d && await confirmar("Remover documento", `Remover “${d.nome}” desta perícia?`, "Remover", "danger")) { for (let n = 0; n < (d.parts || 0); n++) KV.del(`txt_${d.id}_${n}`); KV.del("fich_" + d.id); KV.del("img_" + d.id); S.cur.docs = S.cur.docs.filter(x => x.id !== id); saveCase(); render(); } },
    vertexto: async () => { const d = S.cur.docs.find(x => x.id === id); const t = await getText(d); modal({ title: d.nome, wide: true, body: `<pre class="pre">${esc(t.slice(0, 200000))}${t.length > 200000 ? "\n\n[… texto exibido parcialmente …]" : ""}</pre>` }); },
    verfich: async () => { const d = S.cur.docs.find(x => x.id === id); const t = await getFich(d); modal({ title: "Ficha — " + d.nome, wide: true, body: `<div class="md">${md(t)}</div>` }); },
    fichar1: () => ficharDocs([S.cur.docs.find(x => x.id === id)]),
    ficharTodos: () => ficharDocs(S.cur.docs.filter(d => d.chars && !d.fichOk && d.categoria !== "imagens")),
    ocr: () => ocrDoc(S.cur.docs.find(x => x.id === id)),
    analisar: () => analyzeImage(S.cur.docs.find(x => x.id === id)),
    cid11ia: () => cid11IA(+a.dataset.i),
    ciddel: () => { const x = S.cur.cids[+a.dataset.i]; S.cur.cids.splice(+a.dataset.i, 1); const ln = cidLine(x); S.cur.anamnese.cid = (S.cur.anamnese.cid || "").split("\n").filter(l => l.trim() !== ln).join("\n"); saveCase(); render(); },
    dorclear: () => { S.cur.testes.dor.valor = ""; saveCase(); render(); },
    aidados: () => aiDados(),
    completar: () => aiCompletar(),
    tudo: () => aiTudo(),
    cidsdocs: () => buscarCidsDocs(false),
    modauto: () => { S.cur.modulos = null; saveCase(); render(); },
    modadd: () => { const m = { id: "m" + uid(), nome: "Novo módulo", texto: "Anamnese: \nExame: " }; S.modulos.push(m); S.openMod = m.id; saveModulos(); render(); },
    moddel: async () => { const i = +a.dataset.i; if (await confirmar("Excluir módulo", `Excluir o módulo “${S.modulos[i].nome}”?`, "Excluir", "danger")) { S.modulos.splice(i, 1); saveModulos(); render(); } },
    modreset: async () => { if (await confirmar("Restaurar módulos", "Os módulos originais voltam ao texto inicial. Os módulos que você criou são mantidos.", "Restaurar")) { const extra = S.modulos.filter(m => !DEFAULT_MODULOS.some(d => d.id === m.id)); S.modulos = [...clone(DEFAULT_MODULOS), ...extra]; saveModulos(); render(); } },
    proxmarca: () => proxMarca(),
    aplicarcorr: () => aplicarCorrecoes(),
    avalsug: () => aiAvaliacao(),
    aiquesitos: () => aiQuesitos(),
    organizar: () => organizar(id),
    addintv: () => { S.cur.entrevistas.push({ id: uid(), titulo: "Entrevista " + (S.cur.entrevistas.length + 1), participante: "", data: today(), texto: "" }); saveCase(); render(); },
    delintv: async () => { if (await confirmar("Excluir entrevista", "Apagar esta entrevista e sua transcrição?", "Excluir", "danger")) { S.cur.entrevistas = S.cur.entrevistas.filter(x => x.id !== id); saveCase(); render(); } },
    addex: () => { S.cur.complementares.push({ tipo: "", data: "", resultado: "" }); saveCase(); render(); },
    delex: () => { S.cur.complementares.splice(+a.dataset.i, 1); saveCase(); render(); },
    verqt: () => { const t = S.qt.find(x => x.id === id); modal({ title: t.nome, wide: true, body: `<pre class="pre">${esc(t.texto)}</pre>` }); },
    runall: () => runPipeline(),
    runstep: () => runPipeline(id),
    stop: () => S.running?.ctl?.abort(),
    verout: () => { const s = S.prompts.steps.find(x => x.id === id); modal({ title: s.nome, wide: true, body: `<div class="md">${md(S.out.outputs[id].text)}</div>` }); },
    montar: async () => { if (S.html && !(await confirmar("Remontar o laudo?", S.cur.laudoEditado ? "Você já corrigiu a minuta nesta folha. Remontar APAGA as suas correções e volta ao texto gerado pela IA. Deseja mesmo remontar?" : "Remontar substitui a folha atual pelo resultado atual dos prompts. Continuar?", "Remontar", S.cur.laudoEditado ? "danger" : undefined))) return; montarLaudo(); },
    copiar: () => copiarLaudo(),
    compgerar: () => compGerar(),
    newcomp: async () => { const c = newCase(); c.processo.local = S.profile.cidade || ""; c.complementar = { so: true }; S.cur = c; S.out = { outputs: {} }; S.html = null; S.htmlP = null; S.htmlC = null; S.doc = "comp"; S.texts = {}; S.fich = {}; S.files = {}; S.thumbs = {}; S.aiFilled = new Set(); S.tab = "laudo"; S.autoRun = null; await saveCaseNow(); location.hash = "#caso-" + c.id; },
    docx: () => exportDocx(),
    pdf: async () => { if (!S.html) { toast("Monte o laudo primeiro.", "err"); return; } if (await confOkParaExportar()) savePdf(buildFinal(S.html)); },
    pdfconf: () => { if (!S.html) { toast("Monte o laudo primeiro.", "err"); return; } savePdf(buildFinal(S.html, { final: false }), " - CONFERENCIA"); },
    sigclear: () => sigClear(),
    sigsave: () => sigSave(),
    sigdel: async () => { if (await confirmar("Remover assinatura", "Remover a assinatura salva? Os próximos laudos sairão só com a linha para assinar.", "Remover", "danger")) { S.assinatura = null; KV.del("assinatura"); render(); } },
    logoreset: () => { S.profile.logo = null; saveProfile(); render(); },
    qtadd: () => { const t = { id: "q" + uid(), nome: "Novo modelo de quesitos", tags: [], texto: "1. " }; S.qt.push(t); S.openQt = t.id; saveQt(); render(); },
    qtdel: async () => { const i = +a.dataset.i; if (await confirmar("Excluir modelo", `Excluir “${S.qt[i].nome}”?`, "Excluir", "danger")) { S.qt.splice(i, 1); saveQt(); render(); } },
    qtreset: async () => { if (await confirmar("Restaurar modelos", "Os modelos originais voltam ao estado inicial. Modelos novos que você criou são mantidos.", "Restaurar")) { const extra = S.qt.filter(t => !DEFAULT_QTEMPLATES.some(d => d.id === t.id)); S.qt = [...clone(DEFAULT_QTEMPLATES), ...extra]; saveQt(); render(); } },
    stepadd: () => { const s = { id: "e" + uid(), nome: "Nova etapa", escopo: "caso", tier: "default", ordemLaudo: 55, ativo: true, prompt: "TAREFA: \n\nLAUDO ATÉ AGORA:\n{{LAUDO_ATE_AGORA}}" }; S.prompts.steps.push(s); S.openStep = s.id; savePrompts(); render(); },
    stepdel: async () => { const i = +a.dataset.i; if (await confirmar("Excluir etapa", `Excluir “${S.prompts.steps[i].nome}”?`, "Excluir", "danger")) { S.prompts.steps.splice(i, 1); savePrompts(); render(); } },
    stepup: () => { e.preventDefault(); const i = +a.dataset.i; if (i > 0) { const s = S.prompts.steps; [s[i - 1], s[i]] = [s[i], s[i - 1]]; S.openStep = null; savePrompts(); render(); } },
    stepdown: () => { e.preventDefault(); const i = +a.dataset.i, s = S.prompts.steps; if (i < s.length - 1) { [s[i + 1], s[i]] = [s[i], s[i + 1]]; S.openStep = null; savePrompts(); render(); } },
    promptsreset: async () => { if (await confirmar("Restaurar prompts", "Volta as diretrizes, o formato, as etapas e os prompts auxiliares ao padrão. Suas edições serão perdidas.", "Restaurar", "danger")) { S.prompts = { rules: DEFAULT_RULES, format: DEFAULT_FORMAT, steps: clone(DEFAULT_STEPS), aux: clone(DEFAULT_AUX), modelos: { completo: MODELO_ANAMNESE_1_4, simplificado: MODELO_ANAMNESE_SIMPLES }, tipoPadrao: clone(TIPO_PADRAO), v: 12 }; savePrompts(); render(); } },
    dictstop: () => DICT.stop(),
    delall: async () => {
      const n = S.index.cases.length; if (!n) return;
      const box = document.createElement("div");
      box.innerHTML = `<p>Isso apaga <b>${n} perícia(s)</b>, com documentos, fichas, entrevistas e laudos. <b>Não é possível desfazer.</b></p><p class="note">Seu perfil, os prompts e os modelos de quesitos não são apagados.</p><label class="f"><span class="lbl">Para confirmar, digite EXCLUIR</span><input id="delall-c" autocomplete="off"></label>`;
      setTimeout(() => box.querySelector("input")?.focus(), 50);
      const ok = await modal({ title: "Excluir todas as perícias", body: box, actions: [{ label: "Cancelar", cls: "", value: false }, { label: "Excluir tudo", cls: "danger", value: true }] });
      if (!ok) return;
      if (box.querySelector("input").value.trim().toUpperCase() !== "EXCLUIR") { toast("Nada foi apagado: a confirmação não foi digitada.", "err"); return; }
      const ids = S.index.cases.map(c => c.id); let k = 0;
      toast(`Apagando ${ids.length} perícia(s)…`);
      for (const id of ids) { try { await deleteCase(id); k++; } catch (e) { console.error(e); } }
      S.index.cases = []; await KV.set("index", S.index); S.cur = null; render();
      toast(`${k} perícia(s) apagada(s).`, "ok");
    }
  };
  A[act]?.();
});

/* arrastar arquivos */
document.addEventListener("dragover", e => { const z = e.target.closest("[data-drop]"); if (z) { e.preventDefault(); z.classList.add("over"); } });
document.addEventListener("dragleave", e => { const z = e.target.closest("[data-drop]"); if (z) z.classList.remove("over"); });
document.addEventListener("drop", e => { const z = e.target.closest("[data-drop]"); if (z) { e.preventDefault(); z.classList.remove("over"); handleFiles(e.dataTransfer.files, z.dataset.drop); } });

function setLogo(file) {
  const img = new Image(), url = URL.createObjectURL(file);
  img.onload = () => {
    let max = 360, q = 0.9, out = "";
    do {   // JPEG comprimido até ficar abaixo de ~110 KB
      const sc = Math.min(1, max / Math.max(img.width, img.height)), cv = document.createElement("canvas");
      cv.width = Math.round(img.width * sc); cv.height = Math.round(img.height * sc);
      const g = cv.getContext("2d"); g.fillStyle = "#fff"; g.fillRect(0, 0, cv.width, cv.height); g.drawImage(img, 0, 0, cv.width, cv.height);
      out = cv.toDataURL("image/jpeg", q); q -= 0.1; if (q < 0.5) { q = 0.85; max = Math.round(max * 0.8); }
    } while (out.length > 110000 && max > 80);
    S.profile.logo = out; URL.revokeObjectURL(url); saveProfile(); render(); toast("Logotipo atualizado.", "ok");
  };
  img.onerror = () => { URL.revokeObjectURL(url); toast("Não foi possível ler esta imagem.", "err"); };
  img.src = url;
}
async function logoPng(dataUrl) {   // o modelo Word espera PNG
  const img = await new Promise(r => { const im = new Image(); im.onload = () => r(im); im.src = dataUrl; });
  const cv = document.createElement("canvas"); cv.width = img.width; cv.height = img.height; cv.getContext("2d").drawImage(img, 0, 0);
  return { b64: cv.toDataURL("image/png").split(",")[1], img };
}

/* ===================== DOCUMENTOS: extração de texto ===================== */
if (window.pdfjsLib) pdfjsLib.GlobalWorkerOptions.workerSrc = "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js";
async function handleFiles(files, cat) {
  if (!S.cur) return;
  const arr = Array.from(files || []); if (!arr.length) return;
  const docs = arr.map(f => ({ id: uid(), nome: f.name, categoria: cat, tipo: (f.name.split(".").pop() || "").toLowerCase(), tamanho: f.size, status: "extraindo", at: Date.now() }));
  docs.forEach((d, i) => { S.cur.docs.push(d); S.files[d.id] = arr[i]; });
  render();
  for (const [i, d] of docs.entries()) {
    try {
      if (cat === "imagens") {
        d.imgTipo = guessImgTipo(d.nome);
        if (d.tipo === "pdf") await extract(d, arr[i]); else if (!["jpg", "jpeg", "png", "webp"].includes(d.tipo)) throw new Error("tipo");
        d.status = "imagem"; await makeThumb(d);
      } else await extract(d, arr[i]);
    }
    catch (err) { console.error(err); d.status = "erro"; d.erro = "não foi possível ler o arquivo"; }
    if (d.chars && S.texts[d.id] != null) d.charsIA = prepDocText(S.texts[d.id], d.pagSel).length;
    saveCase(); rerenderTab();
  }
}
async function extract(d, f) {
  const t = d.tipo;
  if (t === "pdf") {
    if (!window.pdfjsLib) throw new Error("pdf.js indisponível");
    const pdf = await pdfjsLib.getDocument({ data: await f.arrayBuffer(), isEvalSupported: false }).promise;
    d.paginas = pdf.numPages; d.semTexto = [];
    let out = "";
    for (let n = 1; n <= pdf.numPages; n++) {
      const pg = await pdf.getPage(n), tc = await pg.getTextContent();
      let s = ""; for (const it of tc.items) { s += it.str; s += it.hasEOL ? "\n" : " "; }
      s = s.replace(/[ \t]+\n/g, "\n").replace(/\n{3,}/g, "\n\n").trim();
      if (s.replace(/\s/g, "").length < 25) { d.semTexto.push(n); s = `[página ${n} sem texto — aguardando leitura por IA]`; }
      out += `\n--- página ${n} ---\n${s}\n`;
    }
    await putText(d, out.trim());
    d.status = d.semTexto.length ? "ocr" : "pronto";
  } else if (t === "docx") {
    const r = await mammoth.extractRawText({ arrayBuffer: await f.arrayBuffer() });
    await putText(d, r.value.trim()); d.status = "pronto";
  } else if (t === "odt") {
    const zip = await JSZip.loadAsync(await f.arrayBuffer());
    const xml = await zip.file("content.xml").async("string");
    const doc = new DOMParser().parseFromString(xml, "application/xml");
    const lines = []; const walk = n => { for (const c of n.childNodes) { if (c.nodeType === 1 && /^(text:p|text:h)$/.test(c.nodeName)) lines.push(c.textContent); else if (c.nodeType === 1) walk(c); } };
    walk(doc.documentElement); await putText(d, lines.join("\n").replace(/\n{3,}/g, "\n\n").trim()); d.status = "pronto";
  } else if (t === "txt" || t === "md") {
    await putText(d, (await f.text()).trim()); d.status = "pronto";
  } else if (["jpg", "jpeg", "png", "webp"].includes(t)) {
    d.status = "ocr"; d.paginas = 1;
  } else { d.status = "erro"; d.erro = "formato não suportado (use PDF, DOCX, ODT, TXT ou imagem)"; }
}

/* ===================== IA: chamada base ===================== */
function fullPrompt(task) { return `${S.prompts.rules}\n\n${S.prompts.format}\n\n${task}`; }
async function ask(prompt, { tier = "default", json = false, images, onText, signal } = {}) {
  const opts = { modelTier: tier, cache: false };
  if (images) opts.images = images; if (onText) opts.onText = onText; if (signal) opts.signal = signal;
  if (json) return CAP.sample.json(prompt, opts);
  const r = await CAP.sample(prompt, opts);
  return r.text + (r.truncated ? "\n\n<red>[Resposta interrompida por limite de tamanho — execute esta etapa novamente ou reduza o conteúdo.]</red>" : "");
}

/* ---------- leitura por IA (OCR) ---------- */
async function ocrDoc(d) {
  if (!needAI()) return;
  const f = S.files[d.id];
  if (!f) { toast("Envie o arquivo novamente para a leitura por IA (o original não fica guardado após recarregar a página).", "err"); return; }
  const lim = CAP.limits?.images;
  if (!lim) { toast("A leitura de imagens não está disponível nesta visualização.", "err"); return; }
  const per = Math.max(1, Math.min(lim.maxCount || 1, 6));
  d.status = "extraindo"; rerenderTab();
  try {
    if (d.tipo === "pdf") {
      const pdf = await pdfjsLib.getDocument({ data: await f.arrayBuffer(), isEvalSupported: false }).promise;
      let text = await getText(d);
      const pages = [...d.semTexto];
      for (let k = 0; k < pages.length; k += per) {
        const batch = pages.slice(k, k + per), blobs = [];
        for (const n of batch) blobs.push(await renderPage(pdf, n));
        toast(`Lendo páginas ${batch.join(", ")} de ${d.nome}…`);
        const out = await ask(S.prompts.aux.ocr + `\n\nAs imagens são, em ordem, as páginas ${batch.join(", ")}.`, { images: blobs, tier: "default" });
        const parts = out.split(/^\s*-{3}\s*página\s*-{3}\s*$/im).map(x => x.trim()).filter(Boolean);
        batch.forEach((n, j) => {
          const rep = parts.length === batch.length ? parts[j] : (j === 0 ? out : "(ver página anterior)");
          text = text.replace(`[página ${n} sem texto — aguardando leitura por IA]`, "[texto lido por IA]\n" + rep);
        });
        d.semTexto = d.semTexto.filter(n => !batch.includes(n));
        await putText(d, text); saveCase();
      }
    } else {
      const out = await ask(S.prompts.aux.ocr, { images: [f], tier: "default" });
      await putText(d, "[texto lido por IA]\n" + out);
    }
    d.status = "pronto"; toast("Leitura concluída: " + d.nome, "ok");
  } catch (e) { d.status = "ocr"; toast(aiMsg(e), "err"); }
  saveCase(); rerenderTab();
}
async function renderPage(pdf, n) {
  const pg = await pdf.getPage(n), v0 = pg.getViewport({ scale: 1 }), sc = Math.min(2.2, 1600 / v0.width), vp = pg.getViewport({ scale: sc });
  const cv = document.createElement("canvas"); cv.width = vp.width; cv.height = vp.height;
  const g = cv.getContext("2d"); g.fillStyle = "#fff"; g.fillRect(0, 0, cv.width, cv.height);
  await pg.render({ canvasContext: g, viewport: vp }).promise;
  return new Promise(r => cv.toBlob(r, "image/jpeg", 0.85));
}

/* ---------- fichamento ---------- */
async function ficharDocs(docs, signal) {
  if (!needAI()) return false;
  const step = S.prompts.steps.find(s => s.id === "fichamento") || S.prompts.steps.find(s => s.escopo === "documento");
  if (!step) { toast("Nenhuma etapa de fichamento configurada em Prompts.", "err"); return false; }
  let ok = true; const info = new Map(), jobs = [];
  for (const d of docs.filter(x => x && x.chars)) {       // o texto foi extraído uma única vez, no envio, e está guardado
    const text = prepDocText(await getText(d), d.pagSel), n = Math.max(1, Math.ceil(text.length / 90000));
    info.set(d.id, { outs: Array(n), left: n, n }); d.fichando = true; d.fichProg = n > 1 ? `0/${n}` : "";
    for (let k = 0; k < n; k++) jobs.push({ d, k, n, text });
  }
  rerenderTab();
  await pool(jobs, 2, async j => {                           // partes e documentos em paralelo (2 por vez)
    if (!ok) return;
    const { d, k, n, text } = j, CH = 90000, inf = info.get(d.id);
    const vars = { DOC_NOME: d.nome, DOC_CATEGORIA: catLabel(d.categoria), DOCUMENTO: text.slice(k * CH, (k + 1) * CH), PARTE: `${k + 1} de ${n}` };
    const label = `Fichamento — ${d.nome}${n > 1 ? ` (parte ${k + 1}/${n})` : ""}`; streamSet(label, "");
    try {
      const out = await ask(fullPrompt(await fillVars(step.prompt, vars)), { tier: tierFor("fichamento", step.tier, VEL()), signal, onText: ({ text }) => streamSet(label, text) });
      inf.outs[k] = n > 1 ? `#### Parte ${k + 1} de ${n}\n${out}` : out; inf.left--;
      if (n > 1) d.fichProg = `${n - inf.left}/${n}`;
      if (!inf.left) { putFich(d, inf.outs.join("\n\n")); d.fichando = false; d.fichProg = ""; saveCase(); }
      rerenderTab();
    } catch (e) { if (ok && e?.code !== "cancelled") toast(aiMsg(e) + " (" + d.nome + ")", "err"); ok = false; }
  });
  for (const d of docs) if (d?.fichando) { d.fichando = false; d.fichProg = ""; }
  saveCase(); rerenderTab();
  return ok;
}
async function pool(items, n, fn) { let i = 0; await Promise.all(Array.from({ length: Math.min(n, items.length) }, async () => { while (i < items.length) await fn(items[i++]); })); }

/* ---------- variáveis dos prompts ---------- */
const lines = (group, defs) => defs.filter(d => d[0] !== "#").map(([k, l]) => { let v = getPath(S.cur, group + "." + k); if (k === "beneficio") v = benefLabel(v); return `- ${l}: ${String(v ?? "").trim() || "[não preenchido]"}`; }).join("\n");
async function fichamentos() {
  const out = [];
  for (const d of S.cur.docs.filter(x => x.categoria !== "poslaudo")) { const f = await getFich(d); if (f) out.push(`### DOCUMENTO: ${d.nome} (${catLabel(d.categoria)}${d.paginas ? ", " + d.paginas + " pág." : ""})\n${f}`); }
  return out.join("\n\n") || "[Nenhum documento fichado]";
}
function quesitosJuizo() {
  const q = S.cur.quesitos, parts = q.templates.map(id => S.qt.find(t => t.id === id)).filter(Boolean).map(t => `### ${t.nome}\n${t.texto}`);
  if (q.juizoExtra.trim()) parts.push(`### Quesitos adicionais do Juízo\n${q.juizoExtra}`);
  return parts.join("\n\n") || "[Nenhum quesito do Juízo informado]";
}
function quesitosPartes() {
  const q = S.cur.quesitos;
  return QUESITO_GRUPOS.filter(g => g[0] !== "juizoExtra" && (q[g[0]] || "").trim()).map(g => `### ${g[1]}\n${q[g[0]]}`).join("\n\n") || "[Nenhum quesito das partes informado]";
}
function laudoAteAgora(exceptId) {
  return activeSteps().filter(s => s.ordemLaudo > 0 && s.id !== exceptId && S.out.outputs[s.id]).sort((a, b) => a.ordemLaudo - b.ordemLaudo).map(s => S.out.outputs[s.id].text).join("\n\n") || "[ainda vazio]";
}
async function fillVars(tpl, extra = {}, exceptId) {
  const c = S.cur, p = S.profile;
  const need = k => tpl.includes("{{" + k + "}}");
  const V = {
    PERITO: `${p.nome} — ${p.crm}${p.especialidade ? " — " + p.especialidade : ""}`,
    PROCESSO: lines("processo", F_PROCESSO) + "\n- Conferência automática com documento oficial anexado: " + confTexto(c.conf), BENEFICIO: benefLabel(c.processo.beneficio) + (c.processo.natureza ? " — " + c.processo.natureza : ""),
    PERICIANDO: lines("periciando", F_PERICIANDO) + indiretaTexto(c), CIDS: cidsTexto(),
    MODULOS_ANAMNESE: S.modulos.filter(m => modulosDaPericia().includes(m.id)).map(m => `### ${m.nome}\n${m.texto}`).join("\n\n") || "[nenhum módulo selecionado: siga o modelo padrão]",
    ANAMNESE: lines("anamnese", F_ANAMNESE) + "\n- Diagnósticos codificados pelo perito (usar no item 2.1 e nas tabelas DOENÇA / DATA / CID dos quesitos): " + cidsTexto(),
    EXAME: lines("exame", F_EXAME) + (testesCount() ? "\n- Testes especiais, goniometria, medidas e dor registrados pelo perito (incluir fielmente nos itens 3.2 i e 3.2 j):\n" + testesTexto().all : ""),
    EXAMES_COMPLEMENTARES: (c.complementares.map((x, i) => `- 4.${i + 1}: ${x.tipo || "[tipo não informado]"} — ${fmtDate(x.data) || "[sem data]"} — ${x.resultado || "[sem resultado]"}`).join("\n") || "[nenhum registrado pelo perito]") + (c.outrosDocs ? `\n- Outros documentos: ${c.outrosDocs}` : ""),
    ENTREVISTAS: c.entrevistas.filter(e => (e.texto || "").trim()).map(e => `### ${e.titulo} (${e.participante || "—"}, ${fmtDate(e.data)})\n${e.texto}`).join("\n\n") || "[sem transcrição]",
    QUESITOS_JUIZO: quesitosJuizo(), QUESITOS_PARTES: quesitosPartes(),
    LISTA_ARQUIVOS: c.docs.map(d => `- ${d.nome} — ${catLabel(d.categoria)}${d.paginas ? " — " + d.paginas + " pág." : ""}`).join("\n") || "[nenhum arquivo]",
    LAUDO_ATE_AGORA: need("LAUDO_ATE_AGORA") ? laudoAteAgora(exceptId) : "",
    MODELO_ANAMNESE_1_4: tipoLaudo() === "simplificado" ? (S.prompts.modelos?.simplificado || MODELO_ANAMNESE_SIMPLES) : (S.prompts.modelos?.completo || MODELO_ANAMNESE_1_4), MODELO_ANAMNESE_5,
    AVALIACAO_PERITO: avaliacaoTexto(c),
    FICHAMENTOS_NOVOS: need("FICHAMENTOS_NOVOS") ? await fichamentosNovos() : "",
    IMPUGNACAO: (c.complementar?.texto || "").trim() || "[não colado — ver os documentos juntados após o laudo]",
    DECISAO: DECISAO_COMP(c),
    LAUDO_ORIGINAL: need("LAUDO_ORIGINAL") ? (temLaudoPlataforma() ? laudoOriginalTexto() : (S.locAutos?.laudo || "[LAUDO NÃO LOCALIZADO NOS AUTOS]")) : "",
    ORIGEM_LAUDO: temLaudoPlataforma() ? "PLATAFORMA" : "AUTOS",
    AUTOS_APOS_LAUDO: temLaudoPlataforma() ? "[não aplicável: laudo feito na plataforma]" : (S.locAutos?.depois || "[nenhum texto após o laudo]"),
    TIPO_LAUDO: tipoLaudo() === "simplificado" ? "SIMPLIFICADO (perícia simples: objetivo, só os itens do modelo)" : "COMPLETO",
    FICHAMENTOS: need("FICHAMENTOS") ? await fichamentos() : "",
    ...extra
  };
  let s = tpl.replace(/\{\{SECAO:([\w-]+)\}\}/g, (_, id) => S.out.outputs[id]?.text || "[etapa ainda não executada]");
  s = s.replace(/\{\{([A-Z_0-9]+)\}\}/g, (m, k) => (k in V ? V[k] : m));
  // limite de tamanho: corta os fichamentos se necessário
  const LIM = 230000, base = bytes(fullPrompt(s));
  if (base > LIM && V.FICHAMENTOS) {
    const fb = bytes(V.FICHAMENTOS), keep = Math.max(2000, Math.floor(V.FICHAMENTOS.length * (1 - (base - LIM) / fb)) - 2000);
    s = s.replace(V.FICHAMENTOS, () => V.FICHAMENTOS.slice(0, keep) + "\n\n[FICHAMENTOS CORTADOS POR LIMITE DE TAMANHO — sinalize em <red> que parte dos documentos não pôde ser considerada nesta etapa]");
  }
  return s;
}

/* ---------- preencher dados / quesitos / organizar entrevista ---------- */
function flat(o, pre = "", out = {}) { for (const [k, v] of Object.entries(o || {})) { if (v && typeof v === "object" && !Array.isArray(v)) flat(v, pre + k + ".", out); else out[pre + k] = Array.isArray(v) ? v.join("; ") : v; } return out; }
function applyJSON(obj, allowed, mode) {
  let n = 0;
  for (const [k, v] of Object.entries(flat(obj))) {
    if (!allowed.includes(k) || v == null) continue;
    const val = String(v).trim(); if (!val) continue;
    const cur = String(getPath(S.cur, k) ?? "").trim();
    if (!cur) { setPath(S.cur, k, val); S.aiFilled.add(k); n++; }
    else if (mode === "append" && !cur.includes(val)) { setPath(S.cur, k, cur + "\n" + val); S.aiFilled.add(k); n++; }
  }
  return n;
}
async function withBusy(btn, label, fn) {
  const old = btn?.innerHTML; if (btn) { btn.disabled = true; btn.innerHTML = SPIN + " " + label; }
  try { return await fn(); } finally { if (btn && document.body.contains(btn)) { btn.disabled = false; btn.innerHTML = old; } }
}
async function aiDados() {
  if (!needAI()) return;
  if (!S.cur.docs.some(d => d.fichOk)) { toast("Fiche os documentos primeiro (aba Documentos).", "err"); return; }
  const defs = [...F_PROCESSO.filter(d => d[2] !== "yn").map(d => ["processo." + d[0], d[1]]), ...F_PERICIANDO.filter(d => d[0] !== "idade").map(d => ["periciando." + d[0], d[1]])];
  const campos = defs.map(([k, l]) => `${k}: ${l}${k === "processo.beneficio" ? " (use um destes códigos: " + BENEFICIOS.map(b => b[0]).join(", ") + ")" : ""}`).join("\n");
  await withBusy($('[data-act="aidados"]'), "Lendo documentos…", async () => {
    try {
      const obj = await ask(fullPrompt(await fillVars(S.prompts.aux.dados, { CAMPOS: campos })), { json: true, tier: tierFor("dados", "default", VEL()) });
      const n = applyJSON(obj, defs.map(d => d[0]));
      S.cur.periciando.idade = idadeEm(S.cur.periciando.nasc, S.cur.processo.data);
      saveCase(); render(); toast(n ? `${n} campo(s) preenchido(s) — confira os destacados em dourado.` : "Nenhum dado novo encontrado nos documentos.", "ok");
    } catch (e) { toast(aiMsg(e), "err"); }
  });
}
async function aiQuesitos(quiet) {
  if (!needAI()) return;
  if (!S.cur.docs.some(d => d.fichOk)) { toast("Fiche os documentos primeiro (aba Documentos).", "err"); return; }
  await withBusy($('[data-act="aiquesitos"]'), "Procurando quesitos…", async () => {
    try {
      const o = await ask(fullPrompt(await fillVars(S.prompts.aux.quesitos)), { json: true, tier: tierFor("quesitos", "default", VEL()) });
      const map = { juizo: "juizoExtra", mp: "mp", autor: "autor", reu: "reu", assistente: "assistente", outros: "outros" };
      let n = 0; for (const [k, f] of Object.entries(map)) if (o?.[k] && String(o[k]).trim() && !S.cur.quesitos[f].trim()) { S.cur.quesitos[f] = String(o[k]).trim(); S.aiFilled.add("quesitos." + f); n++; }
      saveCase(); render(); if (!quiet) toast(n ? `Quesitos encontrados em ${n} grupo(s). Confira o texto.` : "Nenhum quesito novo encontrado (campos já preenchidos são mantidos).", "ok");
    } catch (e) { toast(aiMsg(e), "err"); }
  });
}
async function organizar(id) {
  if (!needAI()) return;
  const iv = S.cur.entrevistas.find(x => x.id === id);
  if (!iv?.texto?.trim()) { toast("A transcrição está vazia.", "err"); return; }
  const defs = [...F_ANAMNESE.map(d => ["anamnese." + d[0], d[1]]), ...F_EXAME.filter(d => d[0] !== "#").map(d => ["exame." + d[0], "Exame — " + d[1] + (d[2] === "func" ? " (" + FUNC_OPTS.join(" / ") + ", com observação)" : "")]),
    ...["ocupacao", "atividadesAnteriores", "escolaridade", "estadoCivil", "afastamentos", "reabilitacao", "presentes"].map(k => { const d = F_PERICIANDO.find(x => x[0] === k) || F_PROCESSO.find(x => x[0] === k); return [(k === "presentes" ? "processo." : "periciando.") + k, d[1]]; })];
  const campos = defs.map(([k, l]) => `${k}: ${l}`).join("\n");
  await withBusy($(`[data-act="organizar"][data-id="${id}"]`), "Organizando…", async () => {
    try {
      const tpl = S.prompts.aux.organizar.replace("{{TRANSCRICAO}}", () => `(${iv.titulo} — ${iv.participante || ""})\n${iv.texto}`);
      const obj = await ask(fullPrompt(await fillVars(tpl, { CAMPOS: campos })), { json: true, tier: tierFor("organizar", "default", VEL()) });
      const n = applyJSON(obj, defs.map(d => d[0]), "append");
      saveCase(); render(); toast(n ? `${n} campo(s) atualizados nas abas Anamnese e Exame físico — destacados em dourado.` : "Nada novo para distribuir.", "ok");
    } catch (e) { toast(aiMsg(e), "err"); }
  });
}

/* ===================== EXECUÇÃO DOS PROMPTS EM ORDEM ===================== */
function streamSet(label, text) {
  if (S.running) { if (label != null) S.running.label = label; if (text != null) S.running.text = text; }
  const h = $("#stream-h"), b = $("#stream-b");
  if (h && label != null) h.textContent = label;
  if (b && text != null) { b.textContent = text || "Pensando…"; b.scrollTop = b.scrollHeight; }
}
/* dependências de uma etapa: as seções que ela cita ({{SECAO:x}}) e, se usa {{LAUDO_ATE_AGORA}}, todas as outras */
function stepDeps(s, runSet, all) {
  const usaLaudo = x => x.prompt ? x.prompt.includes("{{LAUDO_ATE_AGORA}}") : !!x.usaLaudo;
  const refs = s.prompt ? [...s.prompt.matchAll(/\{\{SECAO:([\w-]+)\}\}/g)].map(m => m[1]) : (s.deps || []);
  const viaLaudo = usaLaudo(s) ? all.filter(o => o.id !== s.id && !usaLaudo(o)).map(o => o.id) : [];
  return [...new Set([...refs, ...viaLaudo])].filter(id => id !== s.id && runSet.has(id));
}
async function runOneStep(s, ctl, onText) {
  const text = await ask(fullPrompt(await fillVars(s.prompt, {}, s.id)), { tier: tierFor(s.id, s.tier, VEL()), signal: ctl.signal, onText });
  S.out.outputs[s.id] = { text, at: Date.now() }; saveOut();
}
async function runPipeline(onlyId) {
  if (!needAI() || S.running) return;
  const steps = activeSteps().filter(s => !onlyId || s.id === onlyId);
  if (!onlyId) await buscarCidsDocs(true);
  const ctl = new AbortController(); S.running = { ctl, steps: new Set(), label: "", text: "" };
  const caseId = S.cur.id, t0 = Date.now();
  try {
    const docStep = steps.find(s => s.escopo === "documento");
    if (docStep) {
      S.running.steps.add(docStep.id); rerenderTab();
      const pend = S.cur.docs.filter(d => d.chars && d.categoria !== "imagens" && d.categoria !== "poslaudo" && (onlyId ? true : !d.fichOk));
      if (S.cur.docs.some(d => d.status === "imagem")) toast("Há imagens ainda não analisadas pela IA — elas ficarão de fora.", "err");
      if (S.cur.docs.some(d => d.status === "ocr")) toast("Há documentos digitalizados ainda não lidos pela IA — eles ficarão de fora.", "err");
      if (pend.length && !(await ficharDocs(pend, ctl.signal))) throw { code: "stopped" };
      S.running.steps.delete(docStep.id);
    }
    const caseSteps = steps.filter(s => s.escopo !== "documento"), runSet = new Set(caseSteps.map(s => s.id));
    const deps = Object.fromEntries(caseSteps.map(s => [s.id, stepDeps(s, runSet, caseSteps)]));
    const done = new Set(), pending = [...caseSteps], LIMIT = 2;
    await new Promise((resolve, reject) => {
      let failed = false;
      const pump = () => {
        if (failed || S.cur?.id !== caseId) return failed ? null : resolve();
        if (!pending.length && !S.running.steps.size) return resolve();
        for (const s of [...pending]) {
          if (S.running.steps.size >= LIMIT) break;
          if (!deps[s.id].every(d => done.has(d))) continue;
          pending.splice(pending.indexOf(s), 1); S.running.steps.add(s.id);
          const lbl = () => `Etapa: ${s.nome}${S.running?.steps.size > 1 ? ` (+${S.running.steps.size - 1} em paralelo)` : ""}`;
          streamSet(lbl(), "");
          runOneStep(s, ctl, ({ text }) => streamSet(lbl(), text))
            .then(() => { S.running.steps.delete(s.id); done.add(s.id); rerenderTab(); pump(); }, e => { failed = true; reject(e); });
        }
        if (!S.running.steps.size && pending.length) { const s = pending[0]; deps[s.id] = []; pump(); return; }   // segurança contra dependência circular
        rerenderTab();
      };
      pump();
    });
    const min = Math.max(1, Math.round((Date.now() - t0) / 60000));
    if (!onlyId) {
      if (S.html && S.cur.laudoEditado && !(await confirmar("Remontar o laudo?", "Os prompts foram executados. Você já corrigiu a minuta nesta folha: remontar APAGA as suas correções. Remontar agora?", "Remontar", "danger"))) toast("Prompts executados. A folha corrigida foi mantida.", "ok");
      else { montarLaudo(); toast(`Laudo montado em ~${min} min. Revise os pontos marcados.`, "ok"); }
    }
    else toast("Etapa concluída.", "ok");
  } catch (e) {
    ctl.abort();
    if (e?.code === "cancelled" || e?.code === "stopped") toast("Execução interrompida.");
    else toast(aiMsg(e), "err");
  } finally { S.running = null; rerenderTab(); }
}

/* ===================== MONTAGEM DO LAUDO ===================== */
function md(s) {
  s = String(s || "").replace(/<red>/gi, '<span class="red">').replace(/<\/red>/gi, "</span>")
    .replace(/<sugerir([^>]*)>/gi, (_, a) => { const at = k => (new RegExp(k + '\\s*=\\s*"([^"]*)"', "i").exec(a) || [])[1] || ""; return `<span class="sugestao" data-campo="${esc(at("campo"))}" data-valor="${esc(at("valor"))}">`; }).replace(/<\/sugerir>/gi, "</span>")
    .replace(/<excesso>/gi, '<span class="excesso">').replace(/<\/excesso>/gi, "</span>").replace(/<investigar>/gi, '<span class="investigar">').replace(/<\/investigar>/gi, "</span>");
  const html = window.marked ? marked.parse(s, { mangle: false, headerIds: false, breaks: true }).replace(/<br>\s+/g, "<br>") : `<p>${esc(s).replace(/\n/g, "<br>")}</p>`;
  return window.DOMPurify ? DOMPurify.sanitize(html, { ALLOWED_ATTR: ["class", "colspan", "rowspan", "src", "alt", "data-sig", "data-campo", "data-valor"] }) : html;
}
function assinaturaMd(data) {
  const c = S.cur, p = S.profile, loc = p.cidade || c.processo.local || "";
  const sigImg = S.assinatura ? `<p class="sig sigimgp"><img class="sigimg" data-sig="1" src="${S.assinatura}" alt="Assinatura do perito"></p>` : "";
  return `\n\n${loc ? loc + ", " : ""}${dataExtenso(data)}.\n\n${sigImg}\n\n<p class="sig${S.assinatura ? " nomt" : ""}">______________________________________<br><b>${esc(p.nome)}</b><br>Médico Perito — ${esc(p.crm)}${p.especialidade ? "<br>" + esc(p.especialidade) : ""}</p>`;
}
function montarLaudo() {
  if (S.doc === "comp") setDoc("principal", true);
  const c = S.cur, p = S.profile;
  const parts = activeSteps().filter(s => s.ordemLaudo > 0 && S.out.outputs[s.id]).sort((a, b) => a.ordemLaudo - b.ordemLaudo).map(s => S.out.outputs[s.id].text);
  if (!parts.length) { toast("Execute os prompts antes de montar o laudo.", "err"); return; }
  const loc = p.cidade || c.processo.local || "";
  const sigImg = S.assinatura ? `<p class="sig sigimgp"><img class="sigimg" data-sig="1" src="${S.assinatura}" alt="Assinatura do perito"></p>` : "";
  const sign = assinaturaMd(c.processo.data || today());
  S.html = semSecoesRepetidas(tirarTituloDuplicado(marcarOrigem(`<h1>LAUDO MÉDICO PERICIAL</h1>` + dadosPericiaHTML() + md(parts.join("\n\n") + sign)))); S.htmlP = S.html;
  S.cur.status = "gerado"; S.cur.laudoEditado = false; saveCase();
  KV.set("html_" + c.id, { html: S.html }); rerenderTab();
}
async function copiarLaudo() {
  if (!S.html) { toast("Monte o laudo primeiro.", "err"); return; }
  const el = buildFinal(S.html);
  const html = `<div style="font-family:Arial;font-size:12pt">${el.innerHTML.replace(/class="red"/g, 'style="color:#C00000"')}</div>`;
  try { await navigator.clipboard.write([new ClipboardItem({ "text/html": new Blob([html], { type: "text/html" }), "text/plain": new Blob([el.innerText], { type: "text/plain" }) })]); toast("Laudo copiado com formatação.", "ok"); }
  catch { try { await navigator.clipboard.writeText(el.innerText); toast("Laudo copiado (texto simples).", "ok"); } catch { toast("Não foi possível copiar nesta visualização.", "err"); } }
}

/* ===================== EXPORTAÇÃO WORD (modelo de cabeçalho/rodapé do perito) ===================== */
const xesc = s => String(s).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c])).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, "");
function rPr(f, sz = 24) { return `<w:rPr><w:rFonts w:ascii="Arial" w:hAnsi="Arial" w:cs="Arial"/>${f.b ? "<w:b/><w:bCs/>" : ""}${f.i ? "<w:i/><w:iCs/>" : ""}${f.u ? '<w:u w:val="single"/>' : ""}${f.red ? '<w:color w:val="C00000"/>' : ""}<w:sz w:val="${sz}"/><w:szCs w:val="${sz}"/></w:rPr>`; }
function inlineRuns(node, f, sz) {
  let out = "";
  for (const n of node.childNodes) {
    if (n.nodeType === 3) { const t = n.nodeValue.replace(/\s+/g, " "); if (t) out += `<w:r>${rPr(f, sz)}<w:t xml:space="preserve">${xesc(t)}</w:t></w:r>`; continue; }
    if (n.nodeType !== 1) continue;
    const tg = n.tagName.toLowerCase();
    if (tg === "br") { out += "<w:r><w:br/></w:r>"; continue; }
    if (/^(ul|ol|table|p|div|h\d|blockquote)$/.test(tg)) continue;
    const g = { ...f };
    if (tg === "strong" || tg === "b") g.b = true;
    if (tg === "em" || tg === "i") g.i = true;
    if (tg === "u") g.u = true;
    if (n.classList?.contains("red") || /color:\s*(red|#c00000|rgb\(19\d)/i.test(n.getAttribute("style") || "")) g.red = true;
    out += inlineRuns(n, g, sz);
  }
  return out;
}
function para(runs, o = {}) {
  const sp = `<w:spacing w:before="${o.before ?? 0}" w:after="${o.after ?? 120}" w:line="${o.line ?? 360}" w:lineRule="auto"/>`;
  return `<w:p><w:pPr>${o.keep ? "<w:keepNext/>" : ""}${sp}${o.ind ? `<w:ind w:left="${o.ind}" w:hanging="${o.hang || 0}"/>` : ""}<w:jc w:val="${o.jc || "both"}"/></w:pPr>${runs || ""}</w:p>`;
}
function blocks(el, depth = 0) {
  let out = "";
  for (const n of el.childNodes) {
    if (n.nodeType === 3) { if (n.nodeValue.trim()) out += para(`<w:r>${rPr({})}<w:t xml:space="preserve">${xesc(n.nodeValue.trim())}</w:t></w:r>`); continue; }
    if (n.nodeType !== 1) continue;
    const tg = n.tagName.toLowerCase();
    if (tg === "h1") out += para(inlineRuns(n, { b: true }, 28), { jc: "center", before: 120, after: 240, keep: true });
    else if (tg === "h2") out += para(inlineRuns(n, { b: true }, 24), { jc: "left", before: 280, after: 120, keep: true });
    else if (/^h[3-6]$/.test(tg)) out += para(inlineRuns(n, { b: true }, 24), { jc: "left", before: 200, after: 100, keep: true });
    else if (tg === "p" && n.classList.contains("sigc")) out += para(inlineRuns(n, {}, 24), { jc: "center", after: 0 });
    else if (tg === "p" && n.classList.contains("sigimgp")) { if (S.assinatura) out += sigDrawing(); }
    else if (tg === "p") {
      const sig = n.classList.contains("sig"), nomt = n.classList.contains("nomt"), segs = inlineRuns(n, {}, 24).split("<w:r><w:br/></w:r>");
      segs.forEach((r, k) => { out += para(r, sig ? { jc: "center", before: k || nomt ? 0 : 480, after: k < segs.length - 1 ? 0 : 120 } : { after: k < segs.length - 1 ? 40 : 120 }); });
    }
    else if (tg === "ul" || tg === "ol") {
      let k = 0;
      for (const li of n.children) {
        if (li.tagName.toLowerCase() !== "li") continue; k++;
        const pre = tg === "ol" ? `${k}. ` : "• ", ind = 360 * (depth + 1) + 360;
        const inner = li.querySelector(":scope > p") ? Array.from(li.querySelectorAll(":scope > p")).map(p => inlineRuns(p, {}, 24)).join("<w:r><w:br/></w:r>") : inlineRuns(li, {}, 24);
        out += para(`<w:r>${rPr({})}<w:t xml:space="preserve">${pre}</w:t></w:r>` + inner, { ind, hang: 360, after: 60 });
        for (const sub of li.querySelectorAll(":scope > ul, :scope > ol")) out += blocks({ childNodes: [sub] }, depth + 1);
      }
    }
    else if (tg === "table") out += table(n);
    else if (tg === "blockquote") out += blocks(n, depth + 1).replace(/<w:jc w:val="both"\/>/g, '<w:ind w:left="720"/><w:jc w:val="both"/>');
    else if (tg === "hr") out += `<w:p><w:pPr><w:pBdr><w:bottom w:val="single" w:sz="6" w:space="1" w:color="B67B13"/></w:pBdr></w:pPr></w:p>`;
    else if (tg === "pre") out += para(`<w:r>${rPr({})}<w:t xml:space="preserve">${xesc(n.textContent)}</w:t></w:r>`);
    else out += blocks(n, depth);
  }
  return out;
}
function table(t) {
  const rows = Array.from(t.querySelectorAll("tr")); if (!rows.length) return "";
  const cols = Math.max(...rows.map(r => r.children.length)), W = 9792, cw = Math.floor(W / cols);
  const b = s => `<w:${s} w:val="single" w:sz="4" w:space="0" w:color="8C8C8C"/>`;
  let x = `<w:tbl><w:tblPr><w:tblW w:w="${W}" w:type="dxa"/><w:tblBorders>${["top", "left", "bottom", "right", "insideH", "insideV"].map(b).join("")}</w:tblBorders><w:tblCellMar><w:left w:w="80" w:type="dxa"/><w:right w:w="80" w:type="dxa"/></w:tblCellMar></w:tblPr><w:tblGrid>${("<w:gridCol w:w=\"" + cw + "\"/>").repeat(cols)}</w:tblGrid>`;
  for (const r of rows) {
    x += "<w:tr>";
    const cells = Array.from(r.children);
    for (let i = 0; i < cols; i++) {
      const c = cells[i], th = c && c.tagName.toLowerCase() === "th";
      x += `<w:tc><w:tcPr><w:tcW w:w="${cw}" w:type="dxa"/>${th ? '<w:shd w:val="clear" w:color="auto" w:fill="F3EDE2"/>' : ""}</w:tcPr>${para(c ? inlineRuns(c, { b: th }, 20) : "", { jc: "left", after: 40, line: 276 })}</w:tc>`;
    }
    x += "</w:tr>";
  }
  return x + "</w:tbl>" + para("", { after: 0 });
}
async function exportDocx() {
  if (!S.html) { toast("Monte o laudo primeiro.", "err"); return; }
  if (!(await confOkParaExportar())) return;
  const el = buildFinal(S.html); DOCX_SIG = false;
  try {
    const zip = await JSZip.loadAsync(TEMPLATE_DOCX, { base64: true });
    const p = S.profile, D = DEFAULT_PROFILE;
    let doc = await zip.file("word/document.xml").async("string");
    const i0 = doc.indexOf("<w:body>") + 8, i1 = doc.indexOf("<w:sectPr");
    doc = doc.slice(0, i0) + blocks(el) + para("", { after: 0 }) + doc.slice(i1);
    zip.file("word/document.xml", doc);
    if (DOCX_SIG && S.assinatura) {
      zip.file("word/media/assinatura.png", S.assinatura.split(",")[1], { base64: true });
      let rels = await zip.file("word/_rels/document.xml.rels").async("string");
      if (!rels.includes('Id="rIdAssin"')) rels = rels.replace("</Relationships>", '<Relationship Id="rIdAssin" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/assinatura.png"/></Relationships>');
      zip.file("word/_rels/document.xml.rels", rels);
    }
    let hd = await zip.file("word/header1.xml").async("string"), ft = await zip.file("word/footer1.xml").async("string");
    const rep = (s, a, b) => (a === b ? s : s.split(">" + xesc(a) + "<").join(">" + xesc(b) + "<"));
    hd = rep(rep(rep(hd, D.titulo, S.padrao.titulo), D.nome, p.nome), D.linha2, p.linha2);
    ft = rep(ft, D.qualificacoes, p.qualificacoes);
    if (p.contato !== D.contato) { ft = ft.split(">(65) <").join("><"); ft = rep(ft, "99266-4423  |  hugosouzapericias@gmail.com", p.contato); }
    if (p.logo) {
      const { b64, img } = await logoPng(p.logo); zip.file("word/media/image1.png", b64, { base64: true });
      const m = /<wp:extent cx="(\d+)" cy="(\d+)"\/>/.exec(hd);
      if (m) { const ncx = Math.round(+m[2] * img.width / img.height); hd = hd.split(`cx="${m[1]}" cy="${m[2]}"`).join(`cx="${ncx}" cy="${m[2]}"`); }
    }
    zip.file("word/header1.xml", hd); zip.file("word/footer1.xml", ft);
    const blob = await zip.generateAsync({ type: "blob", mimeType: "application/vnd.openxmlformats-officedocument.wordprocessingml.document" });
    const nome = laudoNome("docx");
    if (!CAP.downloads) { toast("Download indisponível nesta visualização. Abra a página no claude.ai ou use “Copiar”.", "err"); return; }
    await CAP.downloads.save({ filename: nome, data: blob });
    toast("Laudo em Word enviado para download.", "ok");
  } catch (e) { console.error(e); if (e?.code !== "declined") toast(e?.code ? "Download não concluído." : "Falha ao gerar o arquivo Word.", "err"); }
}

/* ===================== DITADO (transcrição por voz) ===================== */
const DICT = {
  state: "idle", target: null,
  toggle(target) {
    if (!CAP.dict) { toast("O ditado funciona no Chrome ou no app do Claude para computador. Você pode digitar normalmente.", "err"); return; }
    const same = this.target && JSON.stringify(this.target) === JSON.stringify(target);
    if (this.state === "listening") { if (same) { this.stop(); return; } this.target = target; this.bar(); this.refreshButtons(); return; }
    this.target = target;
    CAP.dict.start().catch(e => { this.target = null; this.refreshButtons(); if (e?.code === "not_granted") toast("Permissão de microfone negada para o ditado.", "err"); else if (e?.code !== "dismissed") toast("Não foi possível iniciar o ditado.", "err"); });
    this.state = "starting"; this.bar(); this.refreshButtons();
  },
  stop() { CAP.dict?.stop().catch(() => {}); },
  partial(t) { const p = $("#dict-p"); if (p) p.textContent = t; },
  final(t) {
    t = (t || "").trim(); if (!t || !this.target || !S.cur) return;
    const tg = this.target;
    if (tg.kind === "intv") {
      const iv = S.cur.entrevistas.find(x => x.id === tg.id); if (!iv) return;
      iv.texto = (iv.texto ? iv.texto.replace(/\s+$/, "") + " " : "") + t; saveCase();
      const ta = $(`[data-ibind="${tg.id}.texto"]`); if (ta) { ta.value = iv.texto; autoGrow(ta); ta.scrollTop = ta.scrollHeight; }
    } else {
      const cur = String(getPath(S.cur, tg.path) ?? ""); const v = (cur ? cur.replace(/\s+$/, "") + " " : "") + t;
      setPath(S.cur, tg.path, v); saveCase();
      const el = $(`[data-bind="${tg.path}"]`); if (el) { el.value = v; if (el.tagName === "TEXTAREA") autoGrow(el); }
    }
    const p = $("#dict-p"); if (p) p.textContent = "";
  },
  stateChange(st) { this.state = st === "listening" ? "listening" : st === "idle" ? "idle" : st; if (this.state === "idle") this.target = null; this.bar(); this.refreshButtons(); },
  bar() {
    const b = $("#dictbar");
    if (this.state === "idle" || !this.target) { b.classList.add("hidden"); return; }
    b.classList.remove("hidden");
    $("#dict-l").textContent = (this.state === "listening" ? "Ouvindo — " : "Iniciando… ") + (this.target.label || "");
  },
  refreshButtons() {
    const on = this.state !== "idle" && this.target;
    $$("[data-mic]").forEach(b => b.classList.toggle("live", !!on && this.target.kind === "field" && this.target.path === b.dataset.mic));
    $$("[data-rec]").forEach(b => { const live = !!on && this.target.kind === "intv" && this.target.id === b.dataset.rec; b.classList.toggle("live", live); const s = b.querySelector("span"); if (s) s.textContent = live ? "Parar gravação" : "Gravar e transcrever"; });
  }
};

/* ===================== INÍCIO ===================== */
window.addEventListener("hashchange", route);
(async function boot() {
  $("#main").innerHTML = `<div class="empty big">${SPIN} Carregando…</div>`;
  await KV.init();
  await Promise.all([initCaps(), loadAll().catch(e => console.error(e))]);
  setSaved(); renderNav();
  if (KV.mode !== "nuvem") $("#storenote").innerHTML = KV.mode === "local" ? "Dados salvos só neste navegador. Abra no Claude para salvar na sua conta." : "Sem armazenamento disponível: os dados se perdem ao fechar.";
  route();
})();

/* ===================== IMAGENS CLÍNICAS E EXAMES DE IMAGEM ===================== */
function guessImgTipo(n) {
  n = n.toLowerCase();
  if (/rx|raio|radiogra/.test(n)) return "Radiografia";
  if (/rm|resson|mri/.test(n)) return "Ressonância magnética";
  if (/us|usg|ultra/.test(n)) return "Ultrassonografia";
  if (/tc|tomo/.test(n)) return "Tomografia";
  return "Foto clínica";
}
async function makeThumb(d) {
  const f = S.files[d.id]; if (!f) return;
  try {
    let src;
    if (d.tipo === "pdf") { const pdf = await pdfjsLib.getDocument({ data: await f.arrayBuffer(), isEvalSupported: false }).promise; src = await renderPage(pdf, 1); }
    else src = f;
    const url = URL.createObjectURL(src), img = await new Promise((res, rej) => { const im = new Image(); im.onload = () => res(im); im.onerror = rej; im.src = url; });
    const sc = Math.min(1, 280 / Math.max(img.width, img.height)), cv = document.createElement("canvas");
    cv.width = Math.round(img.width * sc); cv.height = Math.round(img.height * sc);
    cv.getContext("2d").drawImage(img, 0, 0, cv.width, cv.height); URL.revokeObjectURL(url);
    S.thumbs[d.id] = cv.toDataURL("image/jpeg", 0.72); KV.set("img_" + d.id, { d: S.thumbs[d.id] });
  } catch (e) { console.warn("miniatura", e); }
}
async function loadThumbs() {
  for (const el of $$("[data-thumb]")) {
    const id = el.dataset.thumb;
    if (S.thumbs[id] === undefined) { S.thumbs[id] = null; const r = await KV.get("img_" + id).catch(() => null); S.thumbs[id] = r?.d || null; }
    if (S.thumbs[id]) el.src = S.thumbs[id]; else el.classList.add("noimg");
  }
}
async function analyzeImage(d) {
  if (!d || !needAI()) return;
  const f = S.files[d.id];
  if (!f) { toast("Envie a imagem novamente para analisar (o arquivo original não fica guardado após recarregar a página).", "err"); return; }
  const lim = CAP.limits?.images;
  if (!lim) { toast("A análise de imagens não está disponível nesta visualização.", "err"); return; }
  d.analisando = true; rerenderTab();
  try {
    let images = [f];
    if (d.tipo === "pdf") { const pdf = await pdfjsLib.getDocument({ data: await f.arrayBuffer(), isEvalSupported: false }).promise; images = []; for (let n = 1; n <= Math.min(pdf.numPages, lim.maxCount || 1, 4); n++) images.push(await renderPage(pdf, n)); }
    const tpl = S.prompts.aux.imagem.replace("{{TIPO}}", () => d.imgTipo || "não informado").replace("{{DESCRICAO}}", () => d.imgDesc || "não informada");
    const out = await ask(fullPrompt(tpl), { images, tier: tierFor("imagem", "complex", VEL()) });
    const prev = d.tipo === "pdf" && d.chars && !d.analisado ? await getText(d) : "";
    await putText(d, (prev ? prev + "\n\n" : "") + "[Análise de imagem por IA — auxiliar, confirmar]\n" + out);
    putFich(d, `**Imagem:** ${d.imgTipo || ""}${d.imgDesc ? " — " + d.imgDesc : ""}\n\n${out}`);
    d.analisado = true; d.status = "pronto"; toast("Imagem analisada: " + d.nome, "ok");
  } catch (e) { toast(aiMsg(e), "err"); }
  d.analisando = false; saveCase(); rerenderTab();
}

/* ===================== TESTES: atualização ao digitar ===================== */
function refreshTestes() {
  const pv = $("#testes-prev"); if (pv) pv.textContent = testesTexto().all || "Nenhum teste registrado ainda.";
  $$("[data-pct]").forEach(td => { const v = getPath(S.cur.testes.gonio, td.dataset.pct), r = restr(+td.dataset.ref, v); td.textContent = r === "" ? "—" : r + "%"; td.className = "pct " + (r >= 50 ? "hi" : r > 0 ? "mid" : ""); });
  const dn = $("#dorn"), dv = S.cur.testes.dor.valor;
  if (dn && dv !== "") { dn.innerHTML = `${dv}<small>/10</small>`; dn.style.setProperty("--h", 120 - dv * 12); $('[data-bind="testes.dor.valor"]')?.classList.remove("unset"); }
}

/* ===================== CID-10 / CID-11 ===================== */
const norm = s => String(s || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase();
async function loadCid(v) {
  const k = "cid" + v; if (S[k]) return S[k];
  try { const r = await fetch(`cid${v}.json`); if (!r.ok) throw 0; S[k] = (await r.json()).map(([c, d]) => [c, d, norm(c.replace(".", "")) + " " + norm(c) + " " + norm(d)]); }
  catch { S[k] = null; toast("Não foi possível carregar a tabela CID.", "err"); }
  return S[k];
}
const cidSearch = debounce(async q => {
  const box = $("#cidres"); if (!box) return;
  q = norm(q).trim(); if (q.length < 2) { box.innerHTML = ""; return; }
  box.innerHTML = `<div class="cid-load">${SPIN} carregando tabela…</div>`;
  const list = await loadCid(S.cidMode); if (!list || !$("#cidres")) return;
  const SYN = { lombalgia: "dor lombar", lombociatalgia: "lumbago ciatica", ciatalgia: "ciatica", cervicalgia: "cervicalgia", avc: "acidente vascular", cancer: "neoplasia maligna", tumor: "neoplasia", has: "hipertensao", hipertensao: "hipertensao", dm: "diabetes", "hernia de disco": "disco", tendinite: "tendinite", bursite: "bursite", depressao: "depressivo", ansiedade: "ansiosa", tept: "estresse pos-traumatico", "tunel do carpo": "tunel do carpo", ler: "sinovite tenossinovite", dort: "sinovite tenossinovite", artrose: "artrose", fibromialgia: "fibromialgia" };
  const qq = SYN[q] || q, words = qq.split(/\s+/).filter(Boolean), roots = words.map(w => w.length > 5 ? w.slice(0, 5) : w), code = q.replace(".", "").toUpperCase();
  const hits = [];
  for (const it of list) {
    const c = it[0].replace(".", "").toUpperCase();
    if (c.startsWith(code)) hits.push([0, it]);
    else if (words.every(w => it[2].includes(w))) hits.push([1, it]);
    else if (roots.every(w => it[2].includes(w))) hits.push([2, it]);
    if (hits.length > 600) break;
  }
  hits.sort((a, b) => a[0] - b[0] || a[1][0].length - b[1][0].length);
  $("#cidres").innerHTML = hits.slice(0, 40).map(([, [c, d]]) => `<button type="button" class="cidopt" data-cidadd="${esc(c)}"><b class="code ${S.cidMode === "11" ? "c11c" : ""}">${esc(c)}</b><span>${esc(d)}</span></button>`).join("") || '<div class="cid-load">Nenhum resultado.</div>';
}, 160);
async function cidAdd(code) {
  const list = await loadCid(S.cidMode), it = list?.find(x => x[0] === code); if (!it) return;
  const x = S.cidMode === "10" ? { c10: it[0], d10: it[1] } : { c11: it[0], d11: it[1] };
  S.cur.cids ||= [];
  if (S.cur.cids.some(y => (x.c10 && y.c10 === x.c10) || (x.c11 && !x.c10 && y.c11 === x.c11))) { toast("Este CID já foi adicionado."); return; }
  S.cur.cids.push(x);
  const a = S.cur.anamnese.cid || ""; if (!a.includes(code)) S.cur.anamnese.cid = (a ? a.replace(/\s+$/, "") + "\n" : "") + cidLine(x);
  const t = S.cur.testes; if (t.segs) t.segs = [...new Set([...t.segs, ...suggestSegs()])];
  saveCase(); render(); toast("CID adicionado ao item 2.1.", "ok");
}
async function cid11IA(i) {
  if (!needAI()) return;
  const x = S.cur.cids[i]; if (!x) return;
  await withBusy($(`[data-act="cid11ia"][data-i="${i}"]`), "Consultando…", async () => {
    try {
      const [o, l11] = await Promise.all([ask(S.prompts.aux.cid11.replace("{{C10}}", () => x.c10).replace("{{D10}}", () => x.d10), { json: true, tier: "default" }), loadCid("11")]);
      const cod = String(o?.codigo || "").trim().toUpperCase(), it = l11?.find(y => y[0].toUpperCase() === cod);
      if (!it) { toast(`A IA sugeriu “${cod || "?"}”, que não está na lista oficial da CID-11. Escolha manualmente no modo CID-11.`, "err"); return; }
      const old = cidLine(x); x.c11 = it[0]; x.d11 = it[1]; x.ia11 = true; x.obs11 = o.observacao || "";
      const a = S.cur.anamnese.cid || ""; S.cur.anamnese.cid = a.includes(old) ? a.replace(old, cidLine(x)) : a;
      saveCase(); render(); toast("CID-11 sugerido: " + it[0] + (x.obs11 ? " — " + x.obs11 : ""), "ok");
    } catch (e) { toast(aiMsg(e), "err"); }
  });
}
function cidsTexto() {
  const l = (S.cur.cids || []).map(x => (x.c10 ? `${x.d10} — CID-10 ${x.c10}` : "") + (x.c11 ? `${x.c10 ? "; " : ""}CID-11 ${x.c11} (${x.d11})${x.ia11 ? " [correspondência sugerida por IA, a confirmar]" : ""}` : ""));
  return l.length ? l.join("; ") : "[nenhum CID codificado pelo perito]";
}

/* ===================== PDF (folha ou Word corrigido) ===================== */
const PDF_FONTS = { "LiberationSans-Regular.ttf": 0, "LiberationSans-Bold.ttf": 0, "LiberationSans-Italic.ttf": 0, "LiberationSans-BoldItalic.ttf": 0, "LiberationSerif-Regular.ttf": 0, "LiberationSerif-Bold.ttf": 0 };
async function loadPdfLib() {
  if (!window.pdfMake) await new Promise((res, rej) => { const s = document.createElement("script"); s.src = "https://cdn.jsdelivr.net/npm/pdfmake@0.2.10/build/pdfmake.min.js"; s.onload = res; s.onerror = rej; document.head.appendChild(s); });
  if (!pdfMake.vfs || !pdfMake.vfs["LiberationSans-Regular.ttf"]) {
    const vfs = {};
    await Promise.all(Object.keys(PDF_FONTS).map(async n => {
      const r = await fetch("fonts/" + n); if (!r.ok) throw new Error("fonte");
      const b = new Uint8Array(await r.arrayBuffer()); let s = ""; for (let i = 0; i < b.length; i += 0x8000) s += String.fromCharCode.apply(null, b.subarray(i, i + 0x8000)); vfs[n] = btoa(s);
    }));
    pdfMake.vfs = vfs;
    pdfMake.fonts = {
      Arial: { normal: "LiberationSans-Regular.ttf", bold: "LiberationSans-Bold.ttf", italics: "LiberationSans-Italic.ttf", bolditalics: "LiberationSans-BoldItalic.ttf" },
      Serif: { normal: "LiberationSerif-Regular.ttf", bold: "LiberationSerif-Bold.ttf", italics: "LiberationSerif-Regular.ttf", bolditalics: "LiberationSerif-Bold.ttf" }
    };
  }
}
function pdfRuns(node, f = {}) {
  const out = [];
  for (const n of node.childNodes) {
    if (n.nodeType === 3) { const t = n.nodeValue.replace(/\s+/g, " "); if (t) out.push({ text: t, bold: !!f.b, italics: !!(f.i || f.inv), decoration: f.u ? "underline" : f.exc ? "lineThrough" : undefined, color: f.red || f.sug ? "#C00000" : f.exc ? "#9A5B00" : f.inv ? "#1F5FA8" : undefined, background: f.sug ? "#FDECEC" : f.inv ? "#E8F0FB" : f.exc ? "#FFF1D6" : f.cor ? "#E6F4EA" : undefined }); continue; }
    if (n.nodeType !== 1) continue;
    const tg = n.tagName.toLowerCase();
    if (tg === "br") { out.push({ text: "\n" }); continue; }
    if (/^(ul|ol|table|p|div|h\d|blockquote|img)$/.test(tg)) continue;
    const g = { ...f };
    if (tg === "strong" || tg === "b") g.b = true;
    if (tg === "em" || tg === "i") g.i = true;
    if (tg === "u") g.u = true;
    if (n.classList?.contains("red") || /color:\s*(red|#c00000|rgb\(19\d)/i.test(n.getAttribute("style") || "")) g.red = true;
    if (n.classList?.contains("excesso")) g.exc = true;
    if (n.classList?.contains("investigar")) g.inv = true;
    if (n.classList?.contains("sugestao")) g.sug = true;
    if (n.classList?.contains("corrigido")) g.cor = true;
    out.push(...pdfRuns(n, g));
  }
  if (out[0] && out[0].text) out[0].text = out[0].text.replace(/^\s+/, "");
  return out;
}
function pdfParas(runs, base) {      // quebra de linha = novo parágrafo (evita esticar a linha justificada)
  const segs = [[]]; runs.forEach(r => { if (r.text === "\n") segs.push([]); else segs[segs.length - 1].push(r); });
  return segs.filter(s => s.length).map((s, k, a) => ({ text: s, ...base, margin: [0, base.margin?.[1] ?? 0, 0, k < a.length - 1 ? 2 : (base.margin?.[3] ?? 6)] }));
}
function pdfBlocks(el) {
  const out = [];
  for (const n of el.childNodes) {
    if (n.nodeType === 3) { if (n.nodeValue.trim()) out.push({ text: n.nodeValue.trim(), alignment: "justify" }); continue; }
    if (n.nodeType !== 1) continue;
    const tg = n.tagName.toLowerCase();
    if (tg === "h1") out.push({ text: pdfRuns(n, { b: true }), fontSize: 14, alignment: "center", margin: [0, 4, 0, 12] });
    else if (tg === "h2") out.push({ text: pdfRuns(n, { b: true }), fontSize: 12, margin: [0, 12, 0, 6], headlineLevel: 1 });
    else if (/^h[3-6]$/.test(tg)) out.push({ text: pdfRuns(n, { b: true }), fontSize: 12, margin: [0, 9, 0, 4], headlineLevel: 1 });
    else if (tg === "p" && n.classList.contains("sigimgp")) { if (S.assinatura) out.push({ image: S.assinatura, width: Math.min(170, 170), alignment: "center", margin: [0, 18, 0, 0] }); }
    else if (tg === "p") out.push(...pdfParas(pdfRuns(n), n.classList.contains("sig") ? { alignment: "center", margin: [0, n.classList.contains("nomt") ? 0 : 26, 0, 2] } : n.classList.contains("sigc") ? { alignment: "center", margin: [0, 0, 0, 2] } : { alignment: "justify" }));
    else if (tg === "ul" || tg === "ol") {
      const items = Array.from(n.children).filter(li => li.tagName.toLowerCase() === "li").map(li => {
        const sub = Array.from(li.querySelectorAll(":scope > ul, :scope > ol"));
        const ps = li.querySelector(":scope > p") ? Array.from(li.querySelectorAll(":scope > p")).map(p => ({ text: pdfRuns(p), alignment: "justify" })) : [{ text: pdfRuns(li), alignment: "justify" }];
        return sub.length ? { stack: [...ps, ...sub.flatMap(s => pdfBlocks({ childNodes: [s] }))] } : ps[0];
      });
      out.push({ [tg]: items, margin: [12, 0, 0, 6] });
    }
    else if (tg === "table") {
      const rows = Array.from(n.querySelectorAll("tr")); if (!rows.length) continue;
      const cols = Math.max(...rows.map(r => r.children.length));
      const body = rows.map(r => { const cs = Array.from(r.children); return Array.from({ length: cols }, (_, i) => { const c = cs[i]; const th = c && c.tagName.toLowerCase() === "th"; return c ? { text: pdfRuns(c, { b: th }), fontSize: 10, fillColor: th ? "#F3EDE2" : undefined } : ""; }); });
      out.push({ table: { widths: Array(cols).fill("*"), body, headerRows: rows[0].querySelector("th") ? 1 : 0 }, layout: { hLineColor: () => "#8C8C8C", vLineColor: () => "#8C8C8C", hLineWidth: () => 0.5, vLineWidth: () => 0.5 }, margin: [0, 4, 0, 8] });
    }
    else if (tg === "img") { const src = n.getAttribute("src") || ""; if (/^data:image\/(png|jpe?g)/.test(src)) out.push({ image: src, fit: [470, 380], alignment: "center", margin: [0, 6, 0, 6] }); }
    else if (tg === "blockquote") out.push({ stack: pdfBlocks(n), margin: [28, 0, 0, 6] });
    else if (tg === "hr") out.push({ canvas: [{ type: "line", x1: 0, y1: 0, x2: 490, y2: 0, lineWidth: 1, lineColor: "#B67B13" }], margin: [0, 6, 0, 8] });
    else if (tg === "pre") out.push({ text: n.textContent, fontSize: 10 });
    else { const img = tg !== "div" && tg !== "section" ? null : null; out.push(...pdfBlocks(n)); }
  }
  return out;
}
async function buildPdf(el) {
  await loadPdfLib();
  const p = S.profile, W = 612, M = 61;
  const dd = {
    pageSize: "LETTER", pageMargins: [M, 96, M, 70],
    defaultStyle: { font: "Arial", fontSize: 12, lineHeight: 1.3 },
    header: () => ({ margin: [M, 22, M, 0], stack: [
      { columns: [{ image: p.logo || LOGO, fit: [48, 52], width: 60 },
        { width: "*", alignment: "right", stack: [
          { text: S.padrao.titulo, font: "Serif", bold: true, fontSize: 17, lineHeight: 1 },
          { text: p.nome || "", font: "Serif", fontSize: 9.5, margin: [0, 3, 0, 0], lineHeight: 1 },
          { text: p.linha2 || "", bold: true, fontSize: 7, color: "#B67B13", margin: [0, 3, 0, 0], lineHeight: 1 }] }] },
      { canvas: [{ type: "line", x1: 0, y1: 6, x2: W - 2 * M, y2: 6, lineWidth: 1.6, lineColor: "#B67B13" }] }] }),
    footer: (cur, total) => ({ margin: [M, 8, M, 0], stack: [
      { canvas: [{ type: "line", x1: 0, y1: 0, x2: W - 2 * M, y2: 0, lineWidth: 1, lineColor: "#B67B13" }] },
      { columns: [{ width: "*", stack: [{ text: p.qualificacoes || "", fontSize: 7, color: "#595959", lineHeight: 1 }, { text: p.contato || "", fontSize: 7, color: "#595959", lineHeight: 1, margin: [0, 2, 0, 0] }] },
        { width: "auto", text: `Página ${cur} de ${total}`, fontSize: 7.5, color: "#595959", lineHeight: 1 }], margin: [0, 5, 0, 0] }] }),
    content: pdfBlocks(el),
    pageBreakBefore: (cur, following) => cur.headlineLevel === 1 && following.length === 0,
    info: { title: "Laudo médico pericial", author: p.nome || "" }
  };
  return new Promise((res, rej) => { try { pdfMake.createPdf(dd).getBlob(res); } catch (e) { rej(e); } });
}
const laudoNome = ext => `${S.doc === "comp" ? "Laudo complementar" : "Laudo pericial"} - ${(S.cur.periciando.nome || "periciando").replace(/[\\/:*?"<>|]/g, "")}${S.cur.processo.numero ? " - " + S.cur.processo.numero.replace(/[\\/:*?"<>|]/g, "") : ""}.${ext}`;
async function savePdf(el, sufixo = "") {
  if (!CAP.downloads) { toast("Download indisponível nesta visualização. Abra a página no claude.ai.", "err"); return; }
  const btn = $('[data-act="pdf"]'); const old = btn?.innerHTML; if (btn) { btn.disabled = true; btn.innerHTML = SPIN + " Gerando PDF…"; }
  try { const blob = await buildPdf(el); await CAP.downloads.save({ filename: laudoNome("pdf").replace(/\.pdf$/, sufixo + ".pdf"), data: blob }); toast("PDF enviado para download.", "ok"); }
  catch (e) { console.error(e); if (e?.code !== "declined") toast(e?.code ? "Download não concluído." : "Falha ao gerar o PDF.", "err"); }
  finally { if (btn && document.body.contains(btn)) { btn.disabled = false; btn.innerHTML = old; } }
}
async function wordCorrigido(file) {
  try {
    const r = await mammoth.convertToHtml({ arrayBuffer: await file.arrayBuffer() });
    const html = DOMPurify.sanitize(r.value, { ALLOWED_ATTR: ["class", "colspan", "rowspan", "src", "alt"] });
    const tmp = document.createElement("div"); tmp.innerHTML = html;
    let first = true;   // recupera títulos e assinatura (o Word não guarda como estilo)
    for (const pEl of Array.from(tmp.querySelectorAll(":scope > p"))) {
      const t = pEl.textContent.trim(); if (!t) continue;
      const strongs = Array.from(pEl.querySelectorAll("strong")).map(x => x.textContent).join("").trim();
      if (t.length < 130 && strongs === t && t === t.toUpperCase() && /[A-ZÀ-Ú]/.test(t)) { const h = document.createElement(first ? "h1" : "h2"); h.innerHTML = pEl.innerHTML; pEl.replaceWith(h); }
      else if (/^_{6,}/.test(t)) { pEl.classList.add("sig"); let n = pEl.nextElementSibling, k = 0; while (n && n.tagName === "P" && k < 4 && n.textContent.trim() && n.textContent.trim().length < 90) { n.classList.add("sigc"); n = n.nextElementSibling; k++; } }
      first = false;
    }
    if (!tmp.textContent.trim()) { toast("O arquivo Word parece vazio.", "err"); return; }
    const ch = await modal({ title: "Word corrigido recebido", body: `<p>Li <b>${esc(file.name)}</b>. O PDF final sai com o seu cabeçalho, rodapé e numeração “Página X de Y”.</p><p class="note">Cores do Word (como o vermelho) não são mantidas no PDF. Imagens coladas no Word são mantidas.</p>`,
      actions: [{ label: "Cancelar", value: 0, cls: "" }, { label: "Só gerar o PDF", value: 1, cls: "" }, { label: "Gerar PDF e atualizar a folha", value: 2, cls: "primary" }] });
    if (!ch) return;
    if (ch === 2) { S.html = tmp.innerHTML; if (S.doc === "comp") S.htmlC = S.html; else S.htmlP = S.html; KV.set(htmlKey(), { html: S.html }); render(); }
    await savePdf(tmp, " - final");
  } catch (e) { console.error(e); toast("Não foi possível ler este arquivo Word (.docx).", "err"); }
}


/* ===================== PREENCHER TUDO COM IA (entrevista + documentos) ===================== */
function hasSources() { const c = S.cur; return c.entrevistas.some(e => (e.texto || "").trim()) || c.docs.some(d => d.fichOk || (d.chars && d.categoria !== "imagens")); }
async function aiCompletar(quiet) {
  if (!needAI() || S.running) return;
  const c = S.cur;
  if (!hasSources()) { toast("Faça a entrevista ou envie documentos primeiro.", "err"); return; }
  const btns = $$('[data-act="completar"]'); const olds = btns.map(b => b.innerHTML);
  btns.forEach(b => { b.disabled = true; b.innerHTML = SPIN + " Preenchendo…"; });
  try {
    const pend = c.docs.filter(d => d.chars && !d.fichOk && d.categoria !== "imagens");
    if (pend.length) { toast(`Lendo ${pend.length} documento(s) antes de preencher…`); if (!(await ficharDocs(pend))) return; }
    const defs = [
      ...F_PROCESSO.map(d => ["processo." + d[0], d[1] + (d[2] === "yn" ? " (Sim/Não)" : "") + (d[2] === "date" ? " (AAAA-MM-DD)" : "")]),
      ...F_PERICIANDO.filter(d => d[0] !== "idade").map(d => ["periciando." + d[0], d[1] + (d[2] === "date" ? " (AAAA-MM-DD)" : "")]),
      ...F_ANAMNESE.map(d => ["anamnese." + d[0], d[1]]),
      ...F_EXAME.filter(d => d[0] !== "#").map(d => ["exame." + d[0], "Exame — " + d[1] + (d[2] === "func" ? " (" + FUNC_OPTS.join(" / ") + ", com observação)" : "")]),
      ["outrosDocs", "4. Outros documentos médicos apresentados"]
    ];
    const tpl = S.prompts.aux.completar || DEFAULT_AUX.completar;
    const o = await ask(fullPrompt(await fillVars(tpl, { CAMPOS: defs.map(([k, l]) => `${k}: ${l}`).join("\n"), BENEFICIOS: BENEFICIOS.map(b => b[0]).join(", ") })), { json: true, tier: tierFor("completar", "complex", VEL()) });
    let n = 0;
    // CIDs validados na tabela oficial
    const codes = Array.isArray(o?.cid10) ? o.cid10 : [];
    if (codes.length) {
      const l10 = await loadCid("10");
      for (const raw of codes) {
        const cod = String(raw).trim().toUpperCase(), it = l10?.find(x => x[0].toUpperCase() === cod) || l10?.find(x => x[0].replace(".", "") === cod.replace(".", ""));
        if (!it || (c.cids || []).some(y => y.c10 === it[0])) continue;
        const x = { c10: it[0], d10: it[1] }; (c.cids ||= []).push(x);
        const a = c.anamnese.cid || ""; if (!a.includes(it[0])) c.anamnese.cid = (a ? a.replace(/\s+$/, "") + "\n" : "") + cidLine(x);
        S.aiFilled.add("anamnese.cid"); n++;
      }
    }
    // campos: só os vazios (o que o perito escreveu nunca é sobrescrito)
    const campos = flat(o?.campos || {});
    for (const [k, v] of Object.entries(campos)) {
      const def = [...F_PROCESSO.map(d => ["processo." + d[0], d[2]]), ...F_PERICIANDO.map(d => ["periciando." + d[0], d[2]])].find(d => d[0] === k);
      if (def?.[1] === "yn" && !["Sim", "Não"].includes(String(v).trim())) delete campos[k];
      if (def?.[1] === "date" && !/^\d{4}-\d{2}-\d{2}$/.test(String(v).trim())) delete campos[k];
      if (k === "processo.beneficio" && !BENEFICIOS.some(b => b[0] === v)) delete campos[k];
    }
    n += applyJSON(campos, defs.map(d => d[0]));
    // exames complementares
    const exs = Array.isArray(o?.exames_complementares) ? o.exames_complementares : [];
    for (const e of exs) {
      if (!e?.tipo) continue;
      const data = /^\d{4}-\d{2}-\d{2}$/.test(e.data || "") ? e.data : "";
      if (c.complementares.some(x => norm(x.tipo) === norm(e.tipo) && (x.data || "") === data)) continue;
      c.complementares.push({ tipo: String(e.tipo), data, resultado: String(e.resultado || ""), ia: true }); n++;
    }
    c.complementares.sort((a, b) => (a.data || "9999").localeCompare(b.data || "9999"));
    c.periciando.idade = idadeEm(c.periciando.nasc, c.processo.data);
    c.autoAt = Date.now(); saveCase(); render();
    if (!quiet) toast(n ? `${n} item(ns) preenchido(s) — os campos dourados vieram da IA: revise e complemente.` : "Nada novo encontrado: os itens já preenchidos foram mantidos.", "ok");
  } catch (e) { toast(aiMsg(e), "err"); }
  finally { $$('[data-act="completar"]').forEach(b => { b.disabled = false; b.innerHTML = I.spark + " Preencher tudo com IA"; }); }
}


/* ===================== LAUDO FINAL × LAUDO DE CONFERÊNCIA ===================== */
const FINAL_DROP = /^(#+\s*)?(RESUMO DE INCONSIST|PONTOS QUE O PERITO PODE MELHORAR)/i;
const VAZIO = /^\(?\s*(n[aã]o\s+(informad|registrad|avaliad|documentad|realizad|preenchid)[oa]s?(\s+(nos|nas|no|na|pelo|pela|em)\s+[a-zà-ú ]{2,30})?|\[n[aã]o preenchido\]|—|–|-)\s*\)?\.?$/i;
const txtOf = h => { const d = document.createElement("div"); d.innerHTML = h; return d.textContent; };
function pruneEmpty(el) {
  const blocks = el.matches("p,li") ? [el] : Array.from(el.querySelectorAll("p,li"));
  for (const b of blocks) {
    if (!b.isConnected && b !== el) continue;
    const segs = b.innerHTML.split(/<br\s*\/?>/i);
    const keep = segs.filter(s => { const t = txtOf(s).trim(); const m = /^(.{1,160}?[:?])\s*(.+)$/.exec(t); return !(m && VAZIO.test(m[2].trim())); });
    if (keep.length !== segs.length) { if (!keep.some(s => txtOf(s).trim())) b.remove(); else b.innerHTML = keep.join("<br>"); }
  }
  if (el.matches("ul,ol") && !el.querySelector("li")) el.remove();
}
/* final: sem inconsistências, sem pontos a melhorar, sem itens vazios (fora dos quesitos), sem vermelho */
function buildFinal(html, { final = true } = {}) {
  const root = document.createElement("div"); root.innerHTML = tirarTituloDuplicado(html);
  root.querySelectorAll("img[data-sig]").forEach(i => { if (S.assinatura) i.src = S.assinatura; else i.closest("p")?.remove(); });
  if (!S.assinatura) root.querySelectorAll("p.sig.nomt").forEach(p => p.classList.remove("nomt"));
  if (!final) return root;
  let drop = false, inQ = false;
  for (const el of Array.from(root.children)) {
    if (/^H[1-3]$/.test(el.tagName) && el.tagName !== "H3") { const t = el.textContent.trim(); drop = FINAL_DROP.test(t); inQ = /QUESITO/i.test(t); }
    else if (el.tagName === "H3" && drop) { /* subtítulos dentro da seção removida */ }
    if (drop) { el.remove(); continue; }
    if (!inQ && !el.classList.contains("sig")) pruneEmpty(el);
  }
  root.querySelectorAll("span.investigar, span.excesso, span.sugestao").forEach(s => s.remove());     // fora do laudo final (sugestão não confirmada também)
  root.querySelectorAll("span.corrigido").forEach(s => s.replaceWith(...s.childNodes));
  semIntervencaoIA(root);                                                              // nenhum comentário da IA no final
  root.querySelectorAll("span.red").forEach(s => s.replaceWith(...s.childNodes));       // dado do caso fica, sem vermelho
  root.querySelectorAll("p, li").forEach(p => { if (!p.textContent.trim() && !p.querySelector("img")) p.remove(); });
  return root;
}

/* ===================== CONFERÊNCIA COM DOCUMENTO OFICIAL ===================== */
const CNJ_RE = /(\d{7})\s*-\s*(\d{2})\s*\.\s*(\d{4})\s*\.\s*(\d)\s*\.\s*(\d{2})\s*\.\s*(\d{4})/g;
const soDig = s => String(s || "").replace(/\D/g, "");
const cnjFmt = d => d.length === 20 ? `${d.slice(0, 7)}-${d.slice(7, 9)}.${d.slice(9, 13)}.${d[13]}.${d.slice(14, 16)}.${d.slice(16)}` : d;
function cnjValido(d) {            // Resolução CNJ 65/2008: DD = 98 − (NNNNNNN AAAA J TR OOOO 00 mod 97)
  if (d.length !== 20) return null;
  const n = d.slice(0, 7) + d.slice(9) + "00"; let r = 0; for (const ch of n) r = (r * 10 + +ch) % 97;
  return 98 - r === +d.slice(7, 9);
}
async function conferirIdent() {
  const c = S.cur; if (!c) return null;
  const off = c.docs.filter(d => d.categoria === "processo" && d.chars);
  const key = JSON.stringify([off.map(d => d.id + ":" + d.chars), c.processo.numero || "", c.periciando.nome || ""]);
  if (c.conf?.key === key) return c.conf;
  const nd = soDig(c.processo.numero), r = { key, at: Date.now(), docs: off.map(d => d.nome), cnjValido: nd.length === 20 ? cnjValido(nd) : null };
  if (!off.length) r.semDoc = true;
  else {
    let txt = ""; for (const d of off) txt += "\n" + await getText(d);
    const found = new Set(); for (const m of txt.matchAll(CNJ_RE)) found.add(m.slice(1).join("")); for (const m of txt.matchAll(/(?<!\d)\d{20}(?!\d)/g)) found.add(m[0]);
    r.numerosAutos = [...found].map(cnjFmt).slice(0, 6);
    r.numero = !nd ? "vazio" : found.has(nd) ? "ok" : found.size ? "divergente" : "nao_encontrado";
    const nn = norm(c.periciando.nome).replace(/\s+/g, " ").trim(), nt = norm(txt).replace(/\s+/g, " ");
    if (!nn) r.nome = "vazio";
    else if (nt.includes(nn)) r.nome = "ok";
    else { const tk = nn.split(" ").filter(w => w.length > 2 && !["dos", "das", "de", "da", "do", "e"].includes(w)); const hit = tk.filter(w => new RegExp("\\b" + w.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "\\b").test(nt)).length; r.nome = tk.length && hit / tk.length >= 0.6 ? "parcial" : "nao_encontrado"; }
    const cand = new Set(), re = /(?:autora?|requerente|reclamante|periciand[oa]|parte autora|exequente|impetrante|segurad[oa])\s*[:\-–]\s*([A-ZÁÉÍÓÚÂÊÔÃÕÇ][A-ZÁÉÍÓÚÂÊÔÃÕÇ' ]{5,80}[A-ZÁÉÍÓÚÂÊÔÃÕÇ])/gi;
    for (const m of txt.matchAll(re)) { const nm = m[1].trim().replace(/\s+/g, " "); if (nm === nm.toUpperCase()) cand.add(nm); }
    r.nomesAutos = [...cand].slice(0, 4);
  }
  if (S.cur === c) { c.conf = r; saveCase(); }
  return r;
}
function confTexto(r) {
  if (!r) return "[conferência não realizada]";
  if (r.semDoc) return "[sem documento oficial da Justiça anexado para conferência]";
  const L = { ok: "confere com os autos", divergente: "NÃO confere com os autos", nao_encontrado: "não encontrado no texto dos autos", parcial: "confere parcialmente (grafia diferente)", vazio: "não preenchido" };
  return `nº do processo ${L[r.numero] || "-"}${r.cnjValido === false ? " (dígito verificador CNJ inválido)" : ""}${r.numero === "divergente" ? " — números nos autos: " + r.numerosAutos.join(", ") : ""}; nome do periciando ${L[r.nome] || "-"}${r.nome !== "ok" && r.nomesAutos?.length ? " — nomes nos autos: " + r.nomesAutos.join(", ") : ""}`;
}
const refreshConf = debounce(async () => { const r = await conferirIdent(); const b = $("#confbox"); if (b) b.innerHTML = confHTML(r); }, 600);
async function confOkParaExportar() {
  const r = await conferirIdent();
  if (!r || r.semDoc || (r.numero === "ok" && r.nome === "ok")) return true;
  if (r.numero !== "divergente" && r.nome !== "nao_encontrado" && r.cnjValido !== false) return true;
  return await confirmar("Conferência com os autos", "O nº do processo ou o nome do periciando não conferem com o documento oficial anexado. Confira antes de exportar. Exportar mesmo assim?", "Exportar mesmo assim", "danger");
}

/* ===================== ASSINATURA DO PERITO ===================== */
let SIGPAD = null, DOCX_SIG = false;
function initSigPad() {
  const cv = $("#sigpad"); if (!cv || cv.dataset.ready) return; cv.dataset.ready = "1";
  const g = cv.getContext("2d"); g.lineCap = "round"; g.lineJoin = "round"; g.strokeStyle = "#1B2A4A"; g.lineWidth = 4.2;
  let drawing = false, pts = [];
  SIGPAD = { cv, g, used: false };
  const pos = e => { const r = cv.getBoundingClientRect(); return [(e.clientX - r.left) * cv.width / r.width, (e.clientY - r.top) * cv.height / r.height]; };
  cv.addEventListener("pointerdown", e => { e.preventDefault(); cv.setPointerCapture(e.pointerId); drawing = true; pts = [pos(e)]; SIGPAD.used = true; cv.parentElement.classList.add("inked"); });
  cv.addEventListener("pointermove", e => {
    if (!drawing) return; pts.push(pos(e)); if (pts.length < 3) return;
    const [a, b, c2] = pts.slice(-3), m1 = [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2], m2 = [(b[0] + c2[0]) / 2, (b[1] + c2[1]) / 2];
    g.beginPath(); g.moveTo(m1[0], m1[1]); g.quadraticCurveTo(b[0], b[1], m2[0], m2[1]); g.stroke();
  });
  const end = () => { if (drawing && pts.length < 3 && pts[0]) { g.beginPath(); g.arc(pts[0][0], pts[0][1], 2, 0, Math.PI * 2); g.fillStyle = g.strokeStyle; g.fill(); } drawing = false; };
  cv.addEventListener("pointerup", end); cv.addEventListener("pointercancel", end);
}
function sigClear() { if (!SIGPAD) return; SIGPAD.g.clearRect(0, 0, SIGPAD.cv.width, SIGPAD.cv.height); SIGPAD.used = false; SIGPAD.cv.parentElement.classList.remove("inked"); }
function cropToInk(src) {             // recorta as bordas vazias e devolve PNG com fundo transparente
  const g = src.getContext("2d"), { width: W, height: H } = src, d = g.getImageData(0, 0, W, H).data;
  let x0 = W, y0 = H, x1 = -1, y1 = -1;
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) if (d[(y * W + x) * 4 + 3] > 20) { if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y; }
  if (x1 < 0) return null;
  const pad = 12; x0 = Math.max(0, x0 - pad); y0 = Math.max(0, y0 - pad); x1 = Math.min(W - 1, x1 + pad); y1 = Math.min(H - 1, y1 + pad);
  const w = x1 - x0 + 1, h = y1 - y0 + 1, sc = Math.min(1, 600 / w, 220 / h), out = document.createElement("canvas");
  out.width = Math.round(w * sc); out.height = Math.round(h * sc);
  out.getContext("2d").drawImage(src, x0, y0, w, h, 0, 0, out.width, out.height);
  return { d: out.toDataURL("image/png"), w: out.width, h: out.height };
}
async function storeSig(r) {
  if (!r) { toast("Nenhum traço encontrado. Assine no quadro primeiro.", "err"); return; }
  S.assinatura = r.d; S.sigSize = { w: r.w, h: r.h };
  await KV.set("assinatura", { d: r.d, w: r.w, h: r.h }); render(); toast("Assinatura salva. Ela entra no final dos próximos laudos montados.", "ok");
}
function sigSave() { if (!SIGPAD?.used) { toast("Assine no quadro primeiro.", "err"); return; } storeSig(cropToInk(SIGPAD.cv)); }
function sigFromImage(file) {
  const img = new Image(), url = URL.createObjectURL(file);
  img.onload = () => {
    const sc = Math.min(1, 1400 / Math.max(img.width, img.height)), cv = document.createElement("canvas");
    cv.width = Math.round(img.width * sc); cv.height = Math.round(img.height * sc);
    const g = cv.getContext("2d"); g.drawImage(img, 0, 0, cv.width, cv.height);
    const id = g.getImageData(0, 0, cv.width, cv.height), p = id.data;
    for (let i = 0; i < p.length; i += 4) { const lum = 0.299 * p[i] + 0.587 * p[i + 1] + 0.114 * p[i + 2]; if (lum > 190) p[i + 3] = 0; else { p[i + 3] = Math.min(255, (190 - lum) * 3); p[i] = 27; p[i + 1] = 42; p[i + 2] = 74; } }
    g.putImageData(id, 0, 0); URL.revokeObjectURL(url); storeSig(cropToInk(cv));
  };
  img.onerror = () => { URL.revokeObjectURL(url); toast("Não foi possível ler esta imagem.", "err"); };
  img.src = url;
}
function sigDrawing() {
  DOCX_SIG = true;
  const { w, h } = S.sigSize || { w: 600, h: 200 }, cx = 1920240, cy = Math.min(Math.round(cx * h / w), 822960);
  const cx2 = Math.round(cy * w / h) < cx ? Math.round(cy * w / h) : cx;
  return `<w:p><w:pPr><w:spacing w:before="240" w:after="0"/><w:jc w:val="center"/></w:pPr><w:r><w:drawing><wp:inline distT="0" distB="0" distL="0" distR="0"><wp:extent cx="${cx2}" cy="${cy}"/><wp:docPr id="901" name="Assinatura"/><a:graphic xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:pic xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:nvPicPr><pic:cNvPr id="901" name="assinatura.png"/><pic:cNvPicPr/></pic:nvPicPr><pic:blipFill><a:blip r:embed="rIdAssin"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill><pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="${cx2}" cy="${cy}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r></w:p>`;
}


/* ===================== UM CLIQUE: documentos → perícia preenchida ===================== */
async function aiTudo() {
  if (!needAI() || S.running || S.autoRun?.on) return;
  const c = S.cur;
  if (!c.docs.length) { toast("Envie os documentos primeiro.", "err"); return; }
  const labels = [["fich", "Lendo e fichando os documentos"], ["img", "Analisando imagens e exames de imagem"], ["campos", "Preenchendo processo, periciando, anamnese e exames"], ["ques", "Buscando os quesitos nos autos"], ["mod", "Marcando os modelos de quesitos da modalidade"]];
  S.autoRun = { on: true, labels, st: Object.fromEntries(labels.map(([k]) => [k, "pend"])) };
  const set = (k, v) => { if (S.cur === c) { S.autoRun.st[k] = v; rerenderTab(); } };
  try {
    set("fich", "run");
    const pend = c.docs.filter(d => d.chars && !d.fichOk && d.categoria !== "imagens");
    if (pend.length && !(await ficharDocs(pend))) throw { code: "stopped" };
    set("fich", "ok");
    set("img", "run");
    const imgs = c.docs.filter(d => d.categoria === "imagens" && !d.analisado && S.files[d.id]);
    for (const d of imgs) await analyzeImage(d);
    set("img", imgs.length ? "ok" : "skip");
    set("campos", "run"); await buscarCidsDocs(true); await aiCompletar(true); set("campos", "ok");
    set("ques", "run"); if (c.docs.some(d => d.fichOk && d.categoria !== "imagens")) await aiQuesitos(true); set("ques", "ok");
    set("mod", "run");
    const sug = S.qt.filter(t => (t.tags || []).includes(c.processo.beneficio)).map(t => t.id);
    if (!c.quesitos.templates.length && sug.length === 1) { c.quesitos.templates = sug; saveCase(); }
    set("mod", c.quesitos.templates.length ? "ok" : "skip");
    c.autoAt ||= Date.now(); saveCase();
    toast("Pronto. Veja abaixo o que falta completar e revise os campos dourados.", "ok");
  } catch (e) {
    if (e?.code !== "stopped") toast(aiMsg(e), "err");
    for (const k in S.autoRun.st) if (S.autoRun.st[k] === "run") S.autoRun.st[k] = "err";
  } finally { S.autoRun.on = false; rerenderTab(); }
}


/* ===================== REVISÃO DA MINUTA (marcações) ===================== */
function marcarOrigem(html) {          // guarda o texto original de cada marcação para saber quando foi corrigido
  const d = document.createElement("div"); d.innerHTML = html;
  d.querySelectorAll("span.red, span.excesso, span.sugestao").forEach(s => { s.dataset.o = s.textContent.trim(); });
  return d.innerHTML;
}
function autoUnmark(root) {
  let n = 0; const sel = getSelection(), an = sel?.anchorNode, ao = sel?.anchorOffset;   // guarda o cursor: desmarcar move os nós de texto
  root.querySelectorAll("span.red, span.excesso, span.sugestao").forEach(s => { if (s.dataset.o == null) { s.dataset.o = s.textContent.trim(); return; } if (s.textContent.trim() !== s.dataset.o) { s.replaceWith(...s.childNodes); n++; } });
  if (n) { if (an && an.isConnected && root.contains(an)) { try { sel.collapse(an, ao); } catch (e) {} } hideRevPop(); refreshRevBar(); }
}
function refreshRevBar() { const b = $(".revbar"); if (b) { S.html = $("#paper")?.innerHTML ?? S.html; b.outerHTML = reviewBarHTML(); } }
let REV_EL = null;
function showRevPop(el) {
  REV_EL = el; let p = $("#revpop");
  if (!p) { p = document.createElement("div"); p.id = "revpop"; document.body.appendChild(p); }
  const tipo = el.classList.contains("sugestao") ? "sug" : el.classList.contains("investigar") ? "inv" : el.classList.contains("excesso") ? "exc" : "red";
  p.innerHTML = tipo === "sug" ? `<span><b>Sugestão da IA</b>, fundamentada nos autos e no exame. A decisão é sua.</span><button class="btn sm primary" data-rev="concordo">${I.check} Concordo</button><button class="btn sm" data-rev="altero">Altero</button><button class="btn sm ghost" data-rev="del">Descartar</button>`
    : tipo === "red" ? `<span>Erro, inconsistência ou dado não averiguado. Corrija o texto (o vermelho some sozinho) ou:</span><button class="btn sm" data-rev="ok">${I.check} Marcar como revisado</button>`
    : tipo === "exc" ? `<span>Trecho marcado como desnecessário.</span><button class="btn sm danger" data-rev="del">Remover trecho</button><button class="btn sm" data-rev="ok">Manter trecho</button>`
    : `<span>Ponto a investigar (não vai para o laudo final).</span><button class="btn sm" data-rev="del">${I.check} Concluído — apagar nota</button>`;
  const r = el.getBoundingClientRect();
  p.style.top = (window.scrollY + r.bottom + 6) + "px"; p.style.left = Math.max(8, Math.min(window.scrollX + r.left, window.scrollX + document.documentElement.clientWidth - 360)) + "px"; p.style.display = "flex";
}
function hideRevPop() { const p = $("#revpop"); if (p) p.style.display = "none"; REV_EL = null; }
function revAction(a) {
  const el = REV_EL, paper = $("#paper"); if (!el || !paper || !paper.contains(el)) return hideRevPop();
  if (a === "altero") {         // vira trecho em vermelho para o perito reescrever; ao editar, fica preto
    const s = document.createElement("span"); s.className = "red"; s.textContent = el.textContent; s.dataset.o = s.textContent.trim(); el.replaceWith(s);
    hideRevPop(); S.html = paper.innerHTML; syncSlot(); saveHtml(); refreshRevBar(); marcarEditado();
    const r = document.createRange(); r.selectNodeContents(s); const sel = getSelection(); sel.removeAllRanges(); sel.addRange(r); paper.focus();
    toast("Reescreva o trecho selecionado com a sua posição. Ao alterar, ele fica preto.", "ok"); return;
  }
  if (a === "concordo" && el.dataset.campo && el.dataset.valor) aceitarValorAval(el.dataset.campo, el.dataset.valor);
  if (a === "del") el.remove(); else el.replaceWith(...el.childNodes);
  hideRevPop(); S.html = paper.innerHTML; syncSlot(); saveHtml(); refreshRevBar(); marcarEditado();
}
function proxMarca() {
  const els = $$("#paper span.red, #paper span.excesso, #paper span.investigar, #paper span.sugestao"); if (!els.length) return;
  const y = window.scrollY + 120, next = els.find(e => e.getBoundingClientRect().top + window.scrollY > y + 5) || els[0];
  next.scrollIntoView({ behavior: "smooth", block: "center" }); next.classList.add("flash"); setTimeout(() => next.classList.remove("flash"), 1400);
}


/* ===================== LAUDO FINAL SEM INTERVENÇÃO DA IA ===================== */
// comentário da IA dentro de <red> (não é dado do caso)
const META_RED = /(\bperit[oa]s?\b|gerou\s+d[uú]vida|recomenda|suger|verificar|confirmar|checar|investigar|esclarecer|\bIA\b|intelig[eê]ncia\s+artificial|n[aã]o\s+(foi|foram)\s+poss[ií]vel|n[aã]o\s+(informad|registrad|const|localizad|identificad|encontrad|apresentad|mencionad|especificad|document)|aus[eê]ncia\s+de\s+(dado|informa|registro|document)|dado\s+ausente|pendente|diverg|contradi|inconsist|incoer|\?|^\[|\]$)/i;
// frase/trecho com comentário da IA fora das marcações
const META_FRASE = [
  /\bperit[oa]\b[^.;]{0,60}?\b(n[aã]o\s+(mencion|inform|relat|registr|descrev|avali|esclarec|especific|detalh|document|cit|aborda)|dev[ea]\b|dever[aá]|precisa|poder[aá]|recomend|suger)/i,
  /(recomenda-se|sugere-se|conv[eé]m|cabe|recomendo|sugiro)\s+(ao|à|que\s+o|que\s+a)\s+perit/i,
  /gerou\s+d[uú]vida|\ba\s+IA\b|\bpela\s+IA\b|intelig[eê]ncia\s+artificial|modelo\s+de\s+linguagem|\bminuta\b/i,
  /(necess[aá]rio|deve-se|recomenda-se|sugere-se|conv[eé]m|importante|cabe)\s+(\S+\s+){0,2}(verificar|confirmar|checar|investigar|esclarecer|solicitar)/i,
  /\b(verificar|confirmar|checar)\s+(com|junto|se\b|a\s+data|o\s+dado)/i,
  /\bn[aã]o\s+(informad|registrad|mencionad)[oa]s?\b/i,
  /\[[^\]]{2,80}\]/
];
const ehMetaFrase = t => META_FRASE.some(r => r.test(t));
function soltarRotulo(node) {       // remove o nó; se o item ficar só com o rótulo ("1.3. CPF:"), o rótulo sai junto
  let prev = node.previousSibling; const nx = node.nextSibling; node.remove();
  while (prev && prev.nodeType === 3 && !prev.nodeValue.trim()) prev = prev.previousSibling;
  const fim = !nx || nx.nodeName === "BR" || (nx.nodeType === 3 && !nx.nodeValue.trim() && (!nx.nextSibling || nx.nextSibling.nodeName === "BR"));
  if (fim && prev && prev.nodeType === 1 && /^(STRONG|B)$/.test(prev.tagName) && /:\s*$/.test(prev.textContent)) { prev.remove(); if (nx && nx.nodeName === "BR") nx.remove(); else if (nx?.nextSibling?.nodeName === "BR") nx.nextSibling.remove(); }
}
function semIntervencaoIA(root) {
  let inQ = false; const emQuesito = new WeakSet();
  for (const el of Array.from(root.children)) { if (/^H[12]$/.test(el.tagName)) inQ = /QUESITO/i.test(el.textContent); if (inQ) emQuesito.add(el); }
  const quesito = n => { let e = n.nodeType === 1 ? n : n.parentElement; while (e && e.parentElement !== root) e = e.parentElement; return e && emQuesito.has(e); };
  // 1) <red> que é comentário da IA: sai (nos quesitos vira "Prejudicado.")
  root.querySelectorAll("span.red").forEach(s => {
    const t = s.textContent.trim(); if (!t || !META_RED.test(t)) return;
    if (quesito(s) && /n[aã]o\s+(informad|registrad|const|document|apresentad)|aus[eê]ncia|dado\s+ausente/i.test(t)) s.replaceWith(document.createTextNode("Prejudicado."));
    else soltarRotulo(s);
  });
  // 2) frases com comentário da IA fora das marcações (cabeçalhos e assinatura preservados)
  const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT), nodes = [];
  while (w.nextNode()) { const n = w.currentNode; if (!n.parentElement.closest("h1,h2,h3,h4,.sig,span.red")) nodes.push(n); }
  for (const n of nodes) {
    const v = n.nodeValue; if (!ehMetaFrase(v)) continue;
    const partes = v.match(/[^.;!?]+[.;!?]*\s*|[.;!?]+\s*/g) || [v];
    const novo = partes.map(p => {
      if (!ehMetaFrase(p)) return p;
      return quesito(n) && /n[aã]o\s+(informad|registrad|mencionad)/i.test(p) && partes.length === 1 ? " Prejudicado. " : "";
    }).join("");
    n.nodeValue = novo.replace(/\s{2,}/g, " ");
    if (!n.nodeValue.trim()) {            // o item ficou só com o rótulo ("1.3. CPF:"): rótulo sai junto
      const lab = n.previousSibling;
      if (lab && lab.nodeType === 1 && /^(STRONG|B)$/.test(lab.tagName) && /:\s*$/.test(lab.textContent)) {
        const nx = n.nextSibling; lab.remove(); n.remove(); if (nx && nx.nodeName === "BR") nx.remove();
      }
    }
  }
  // 3) limpezas: pontuação solta, parênteses vazios
  root.querySelectorAll("p, li, td").forEach(e => {
    if (/\(\s*\)/.test(e.innerHTML)) e.innerHTML = e.innerHTML.replace(/\(\s*\)/g, "");
    let last = e.lastChild; while (last && last.nodeType === 3 && !last.nodeValue.trim()) last = last.previousSibling;
    if (last?.nodeType === 3) last.nodeValue = last.nodeValue.replace(/\s*[;,]\s*$/, ".");
  });
}


/* ===================== AVALIAÇÃO DO PERITO: sugestão da IA (nunca preenche sozinha) ===================== */
async function aiAvaliacao() {
  if (!needAI() || S.avalBusy) return;
  const c = S.cur; S.avalBusy = true; rerenderTab();
  try {
    const o = await ask(fullPrompt(await fillVars(S.prompts.aux.avaliacao)), { json: true, tier: tierFor("avaliacao", "complex", VEL()) });
    const sug = {}; for (const [k] of F_AVALIACAO) { const x = o?.[k]; if (x && typeof x === "object") sug[k] = { valor: String(x.valor ?? "").trim(), justificativa: String(x.justificativa ?? "").trim(), faltam: String(x.faltam ?? "").trim() }; else if (typeof x === "string" && x.trim()) sug[k] = { valor: x.trim(), justificativa: "", faltam: "" }; }
    if (o?.geral) sug.geral = String(o.geral);
    c.avaliacaoSug = sug; saveCase(); toast("Sugestões prontas. Revise e aceite só o que concordar.", "ok");
  } catch (e) { toast(aiMsg(e), "err"); }
  finally { S.avalBusy = false; rerenderTab(); }
}
function aceitarSug(k) {
  const c = S.cur, sg = c.avaliacaoSug?.[k]; if (!sg?.valor) return;
  aceitarValorAval(k, sg.valor, true); rerenderTab();
}
function aceitarValorAval(k, valor, forcar) {          // grava a decisão do perito no campo da Avaliação (se ainda vazio, ou quando ele aceita no quadro)
  const c = S.cur, f = F_AVALIACAO.find(x => x[0] === k); if (!f) return;
  if (!forcar && String(c.avaliacao?.[k] ?? "").trim()) return;
  let v = String(valor).trim(); if (!v || v.includes("|")) return;
  if (f?.[2] === "sel") { const lv = v.toLowerCase(), ops = f[3].filter(([val]) => val); const o = ops.find(([val]) => val.toLowerCase() === lv) || ops.filter(([val]) => lv.startsWith(val.toLowerCase())).sort((a, b) => b[0].length - a[0].length)[0]; if (o) v = o[0]; }
  if (k === "percentual") v = v.replace(/\s*%$/, "");
  c.avaliacao = c.avaliacao || {}; c.avaliacao[k] = v; saveCase();
}


/* ===================== LAUDO COMPLEMENTAR ===================== */
function syncSlot() { if (S.doc === "comp") S.htmlC = S.html; else S.htmlP = S.html; }
function marcarEditado() {
  const c = S.cur;
  if (S.doc === "comp") { c.complementar = c.complementar || {}; if (!c.complementar.editado) { c.complementar.editado = true; saveCase(); } }
  else if (!c.laudoEditado) { c.laudoEditado = true; saveCase(); }
}
function setDoc(d, silent) {
  d = d === "comp" ? "comp" : "principal"; if (S.doc === d) return;
  syncSlot(); S.doc = d; S.html = d === "comp" ? S.htmlC : S.htmlP; S.laudoView = "conf"; hideRevPop();
  if (!silent) rerenderTab();
}
async function fichamentosNovos() {
  const out = [];
  for (const d of S.cur.docs.filter(x => x.categoria === "poslaudo")) { const f = await getFich(d); if (f) out.push(`### DOCUMENTO: ${d.nome}${d.paginas ? " (" + d.paginas + " pág.)" : ""}\n${f}`); }
  return out.join("\n\n") || "[Nenhum documento novo juntado após o laudo]";
}
function htmlParaTexto(el) {
  const out = [];
  for (const n of Array.from(el.children)) {
    const t = n.textContent.replace(/\s+/g, " ").trim(); if (!t) continue;
    if (/^H[1-4]$/.test(n.tagName)) out.push("\n" + "#".repeat(Math.max(2, +n.tagName[1])) + " " + t);
    else if (n.tagName === "TABLE") out.push(Array.from(n.rows).map(r => Array.from(r.cells).map(x => x.textContent.trim()).join(" | ")).join("\n"));
    else if (n.tagName === "UL" || n.tagName === "OL") out.push(Array.from(n.children).map(li => "- " + li.textContent.replace(/\s+/g, " ").trim()).join("\n"));
    else out.push(t);
  }
  return out.join("\n");
}
const laudoPrincipalHtml = () => (S.doc === "comp" ? S.htmlP : S.html) || "";
function laudoOriginalTexto() {
  const h = laudoPrincipalHtml();
  if (h) return htmlParaTexto(buildFinal(h));
  const t = allSteps().filter(s => s.ordemLaudo > 0 && S.out.outputs[s.id]).sort((a, b) => a.ordemLaudo - b.ordemLaudo).map(s => S.out.outputs[s.id].text).join("\n\n");
  return t || "[Laudo original não encontrado na plataforma]";
}
/* conclusão + conclusão simplificada do laudo pericial, como estão na folha (com as correções do perito) */
function conclusaoOriginalHtml() {
  const h = laudoPrincipalHtml();
  if (h) {
    const el = buildFinal(h), kids = Array.from(el.children);
    const i = kids.findIndex(n => /^H[1-3]$/.test(n.tagName) && /^\s*5\.?\s*CONCLUS|CONCLUSÃO MÉDICO-PERICIAL/i.test(n.textContent));
    if (i >= 0) {
      const sel = [];
      for (const n of kids.slice(i)) {
        if (n.classList.contains("sig") || n.querySelector?.("img.sigimg")) break;
        if (n.tagName === "P" && /^[^,]{2,60},\s*\d{1,2}º?\s+de\s+\S+\s+de\s+\d{4}\.?$/.test(n.textContent.trim())) break;
        if (/^H[12]$/.test(n.tagName) && sel.length && !/CONCLUS/i.test(n.textContent)) break;
        sel.push(n.outerHTML);
      }
      if (sel.length) return sel.join("");
    }
  }
  const o = S.out.outputs.conclusao?.text; return o ? md(o) : "";
}
async function compGerar() {
  if (!needAI() || S.running) return;
  const c = S.cur; c.complementar = c.complementar || {}; const k = c.complementar;
  const novos = c.docs.filter(d => d.categoria === "poslaudo");
  const autos = !temLaudoPlataforma();
  if (!autos && !novos.length && !(k.texto || "").trim()) { toast("Envie a impugnação (arquivo) ou cole o texto dela.", "err"); return; }
  if (autos) {
    if (!c.docs.some(d => d.chars)) { toast("Envie os autos (PDF com texto) com o laudo anterior e a impugnação.", "err"); return; }
    if (c.docs.some(d => d.status === "extraindo")) { toast("Aguarde terminar a leitura dos arquivos.", "err"); return; }
    S.locAutos = await localizarLaudoNosAutos();
    k.loc = S.locAutos ? { ok: true, doc: S.locAutos.doc, chars: S.locAutos.laudo.length, conc: !!S.locAutos.conclusao } : { ok: false }; saveCase();
    if (!S.locAutos) { if (S.doc !== "comp") setDoc("comp", true); rerenderTab(); toast("Laudo pericial anterior não localizado nos autos. Envie o laudo separado e gere de novo.", "err"); return; }
  }
  if (S.htmlC && k.editado && !(await confirmar("Gerar de novo?", "Você já corrigiu o laudo complementar nesta folha. Gerar de novo APAGA essas correções. Continuar?", "Gerar de novo", "danger"))) return;
  if (novos.some(d => d.status === "imagem" || d.status === "ocr")) toast("Há imagens ou páginas digitalizadas ainda não lidas pela IA na impugnação — leia-as na aba Documentos.", "err");
  const ctl = new AbortController(); S.running = { ctl, steps: new Set(["complementar"]), label: "", text: "" };
  if (S.doc !== "comp") setDoc("comp", true); rerenderTab();
  try {
    const pend = autos ? [] : novos.filter(d => d.chars && !d.fichOk);   // nos autos, o texto é usado direto (sem fichar 400 páginas)
    if (pend.length && !(await ficharDocs(pend, ctl.signal))) throw { code: "stopped" };
    const label = "Laudo complementar"; streamSet(label, "");
    const out = await ask(fullPrompt(await fillVars(S.prompts.aux.complementar)), { tier: tierFor("complementar", "complex", VEL()), signal: ctl.signal, onText: ({ text }) => streamSet(label, text) });
    const sm = /Sugest[ãa]o:\s*(MANTER|ALTERAR)\s*[—–-]?\s*([^<\n]*)/i.exec(out);
    if (sm) { k.sugestao = sm[1].toUpperCase(); k.sugMotivo = sm[2].trim().slice(0, 300); } else if (k.decisao) { k.sugestao = null; }
    const dec = DECISAO_COMP(c);
    let corpo = md(out);
    if (dec !== "ALTERAR") {
      const conc = autos ? conclusaoAutosHtml() : conclusaoOriginalHtml();
      if (conc) corpo += (dec === "MANTER" ? "<h2>CONCLUSÃO RATIFICADA (LAUDO ANTERIOR)</h2>" : '<h2>CONCLUSÃO DO LAUDO ANTERIOR</h2><p><span class="red">Provisória: aguarda a decisão do perito sobre manter ou alterar.</span></p>') + conc;
    }
    S.html = semSecoesRepetidas(tirarTituloDuplicado(marcarOrigem("<h1>LAUDO MÉDICO PERICIAL COMPLEMENTAR</h1>" + corpo + md(assinaturaMd(today())))));
    S.htmlC = S.html; k.at = Date.now(); k.editado = false; saveCase();
    KV.set("chtml_" + c.id, { html: S.html });
    toast(dec === "PENDENTE" ? "Laudo complementar gerado. Veja a sugestão da IA e decida: mantém ou altera a conclusão." : "Laudo complementar gerado. Revise os pontos marcados.", "ok");
  } catch (e) {
    if (e?.code === "cancelled" || e?.code === "stopped") toast("Execução interrompida."); else toast(aiMsg(e), "err");
  } finally { S.running = null; rerenderTab(); }
}

/* ===================== LAUDO ANTERIOR FEITO FORA DA PLATAFORMA: localizar nos autos ===================== */
const temLaudoPlataforma = () => !!(laudoPrincipalHtml() || S.out.outputs.conclusao);
const linhaTitulo = l => { const t = l.trim(); return t.length > 3 && t.length < 90 && t === t.toUpperCase() && /[A-ZÀ-Ú]{4}/.test(t); };
async function localizarLaudoNosAutos() {
  const partes = [];
  for (const d of S.cur.docs.filter(x => x.chars)) partes.push({ d, t: await getText(d) });
  let melhor = null;
  for (const { d, t } of partes) {
    const re = /(^|\n)[^\n]{0,30}(LAUDO\s+(M[ÉE]DICO[\s-]+)?PERICIAL|LAUDO\s+DE\s+PER[ÍI]CIA(\s+M[ÉE]DICA)?|LAUDO\s+M[ÉE]DICO)[^\n]{0,50}(?=\n)/gi;
    let m;
    while ((m = re.exec(t))) {
      const linha = m[0].replace(/^\n/, "");
      if (!linhaTitulo(linha) || /COMPLEMENTAR|ESCLARECIMENTO/i.test(linha)) continue;
      const st = m.index + (m[1] ? 1 : 0), win = t.slice(st, st + 160000);
      const lines = win.split("\n"); let pos = 0, concPos = -1;
      for (const l of lines) { if (concPos < 0 && pos > 800 && linhaTitulo(l) && /CONCLUS/i.test(l)) concPos = pos; pos += l.length + 1; }
      if (concPos < 0) continue;
      const fimRe = /\n[^\n]*(CRM[\s\-\/:–]*[A-Z]{0,2}[\s\-\/:–]*\d{3,}|_{8,})[^\n]*/g; fimRe.lastIndex = concPos;
      const f = fimRe.exec(win); let end = f ? f.index + f[0].length : Math.min(win.length, concPos + 25000);
      if (f && !/CRM/i.test(f[0])) { const crm = /\n[^\n]*CRM[^\n]*/i.exec(win.slice(end, end + 400)); if (crm) end += crm.index + crm[0].length; }
      else if (f) { const esp = /^\n[^\n]{0,80}(?=\n)/.exec(win.slice(end)); if (esp && /especialista|perito|médic/i.test(esp[0])) end += esp[0].length; }
      end = Math.min(end, win.length);
      const laudo = win.slice(0, end); if (laudo.length < 2500) continue;
      const score = (/QUESITO/i.test(laudo) ? 2 : 0) + (/EXAME\s+(F[ÍI]SICO|CL[ÍI]NICO|PERICIAL)/i.test(laudo) ? 2 : 0) + (/ANAMNESE|HIST[ÓO]RI/i.test(laudo) ? 1 : 0) + (/CRM/i.test(laudo) ? 1 : 0) + (/PERITO/i.test(laudo) ? 1 : 0);
      if (score < 3) continue;
      const conclusao = laudo.slice(concPos, f ? f.index : end).replace(/\n[^\n]*,\s*\d{1,2}º?\s+de\s+[a-zç]+\s+de\s+\d{4}\.?\s*$/i, "").trim();
      const depois = partes.slice(partes.findIndex(p => p.d === d)).map((p, i) => i === 0 ? t.slice(st + end) : `\n\n===== DOCUMENTO: ${p.d.nome} =====\n\n` + p.t).join("").slice(0, 150000);
      const cand = { doc: d.nome, laudo: laudo.slice(0, 120000), conclusao: conclusao.slice(0, 30000), depois: depois.trim() || "[nenhum texto após o laudo]", score };
      if (!melhor || score > melhor.score) melhor = cand;
    }
  }
  return melhor;
}
function conclusaoAutosHtml() {
  const t = S.locAutos?.conclusao; if (!t) return '<p><span class="red">A conclusão do laudo anterior não foi separada automaticamente dos autos: cole aqui a conclusão e a conclusão simplificada.</span></p>';
  const out = []; let par = [];
  const flush = () => { if (par.length) { out.push(`<p>${esc(par.join(" "))}</p>`); par = []; } };
  for (const l of t.split("\n")) {
    const s = l.trim(); if (!s) { flush(); continue; }
    if (linhaTitulo(s)) { flush(); out.push(`<h2>${esc(s)}</h2>`); }
    else if (/^(\d+(\.\d+)+\.?|[a-z]\)|[-•])\s/.test(s)) { flush(); par.push(s); flush(); }
    else par.push(s);
  }
  flush(); return out.join("");
}


/* ===================== CORREÇÕES DITADAS PELO PERITO ===================== */
const normWS = t => String(t || "").replace(/\s+/g, " ").trim();
function inlineSimples(t) { return esc(t).replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>"); }
function aplicarEdicoes(root, edicoes) {
  const blocos = () => Array.from(root.querySelectorAll("h1,h2,h3,h4,p,li,td,th")).filter(b => !b.querySelector("p,li,table") && !b.closest(".sig"));
  let ok = 0; const falhas = [];
  for (const e of edicoes || []) {
    const tr = normWS(e.trecho), novo = String(e.novo ?? "").trim(), acao = e.acao || "substituir";
    if (!tr) continue;
    const b = blocos().find(x => normWS(x.textContent).includes(tr));
    if (!b) { falhas.push(tr.slice(0, 80)); continue; }
    if (acao === "inserir_apos") {
      const n = document.createElement(b.tagName === "LI" ? "li" : "p"); n.innerHTML = `<span class="corrigido">${inlineSimples(novo)}</span>`;
      if (/^T[DH]$/.test(b.tagName)) { b.appendChild(document.createElement("br")); b.appendChild(n.firstChild); } else b.after(n);
      ok++; continue;
    }
    // 1) o trecho está inteiro num só nó de texto: troca só ele
    const w = document.createTreeWalker(b, NodeFilter.SHOW_TEXT); let feito = false;
    while (w.nextNode()) {
      const t = w.currentNode, i = t.nodeValue.indexOf(e.trecho);
      if (i < 0) continue;
      const depois = t.splitText(i); depois.nodeValue = depois.nodeValue.slice(e.trecho.length);
      if (novo) { const s = document.createElement("span"); s.className = "corrigido"; s.innerHTML = inlineSimples(novo); depois.before(s); }
      feito = true; break;
    }
    // 2) o trecho atravessa negrito/marcações: reescreve o parágrafo, mantendo o rótulo em negrito
    if (!feito) {
      const txt = normWS(b.textContent), lab = b.firstElementChild?.matches("strong,b") && txt.startsWith(normWS(b.firstElementChild.textContent)) ? b.firstElementChild : null;
      const labT = lab ? normWS(lab.textContent) : "";
      if (lab && tr.length && txt.indexOf(tr) >= labT.length) {
        const resto = txt.slice(labT.length).replace(tr, novo);
        b.innerHTML = lab.outerHTML + " " + `<span class="corrigido">${inlineSimples(resto.trim())}</span>`;
      } else b.innerHTML = `<span class="corrigido">${inlineSimples(txt.replace(tr, novo))}</span>`;
    }
    if (!normWS(b.textContent) && !b.querySelector("img")) b.remove();
    ok++;
  }
  return { ok, falhas };
}
async function aplicarCorrecoes() {
  if (!needAI() || S.corrBusy) return;
  const c = S.cur, comp = S.doc === "comp", texto = normWS(comp ? c.complementar?.correcoes : c.correcoes);
  if (!texto) { toast("Dite ou escreva as correções primeiro.", "err"); return; }
  const paper = $("#paper"); if (!paper) return;
  S.corrBusy = true; S.corrMsg = ""; rerenderTab();
  try {
    const o = await ask(fullPrompt(await fillVars(S.prompts.aux.correcoes, { CORRECOES: texto, LAUDO_ATUAL: htmlParaTexto($("#paper") || paper) })), { json: true, tier: tierFor("correcoes", "complex", VEL()) });
    const root = $("#paper"); const r = aplicarEdicoes(root, o?.edicoes);
    autoUnmark(root); S.html = root.innerHTML; syncSlot(); saveHtml(); marcarEditado();
    const nao = [...(o?.nao_aplicadas || []), ...r.falhas.map(f => "trecho não localizado: “" + f + "…”")];
    S.corrMsg = `${r.ok} correção(ões) aplicada(s) — em verde na folha.` + (nao.length ? ` <span class="warnline">Não aplicadas: ${nao.map(esc).join("; ")}</span>` : "");
    if (r.ok) { if (comp) c.complementar.correcoes = ""; else c.correcoes = ""; saveCase(); }
    toast(r.ok ? "Correções aplicadas. Confira os trechos em verde." : "Nenhuma correção pôde ser aplicada.", r.ok ? "ok" : "err");
  } catch (e) { toast(aiMsg(e), "err"); }
  finally { S.corrBusy = false; rerenderTab(); }
}


/* o título "LAUDO MÉDICO PERICIAL" é inserido pela plataforma: repetições escritas pela IA (ou vindas do modelo) saem */
function tirarTituloDuplicado(html) {
  if (!html) return html;
  const d = document.createElement("div"); d.innerHTML = html; let primeiro = true, mudou = false;
  for (const el of Array.from(d.children).slice(0, 8)) {
    const t = el.textContent.replace(/\s+/g, " ").trim();
    if (!/^LAUDO\s+M[ÉE]DICO[\s-]+PERICIAL/i.test(t) || t.length > 180 || el.querySelector("img")) continue;
    if (primeiro && el.tagName === "H1") { primeiro = false; continue; }
    el.remove(); mudou = true;
  }
  return mudou ? d.innerHTML : html;
}


/* ===================== SEÇÕES REPETIDAS (rede de segurança) ===================== */
// se uma etapa repetir uma seção que já saiu (ex.: "1. IDENTIFICAÇÃO", "DADOS DA PERÍCIA"), a repetição sai inteira
function semSecoesRepetidas(html) {
  if (!html) return html;
  const d = document.createElement("div"); d.innerHTML = html;
  const kids = Array.from(d.children), vistos = new Set(); let tirar = false, mudou = false;
  for (const el of kids) {
    if (el.matches?.(".sig, .sigimgp") || el.querySelector?.("img[data-sig]")) { tirar = false; continue; }
    if (/^H[12]$/.test(el.tagName)) {
      const k = el.textContent.replace(/\s+/g, " ").trim().toUpperCase();
      tirar = vistos.has(k); vistos.add(k);
    }
    if (tirar) { el.remove(); mudou = true; }
  }
  return mudou ? d.innerHTML : html;
}

/* ===================== CIDs dos documentos e do perito ===================== */
async function buscarCidsDocs(silent) {
  const c = S.cur; if (!c) return 0;
  const list = await loadCid("10"); if (!list) return 0;
  const tab = new Map(list.map(([cd, ds]) => [cd.toUpperCase(), [cd, ds]]));
  const fontes = [];
  for (const d of c.docs.filter(x => x.chars && x.categoria !== "poslaudo")) { const t = await getText(d); if (t) fontes.push(["docs", t]); const f = await getFich(d); if (f) fontes.push(["docs", f]); }
  const perito = [...Object.values(c.anamnese || {}), ...(c.entrevistas || []).map(e => e.texto || e.text || "")].filter(v => typeof v === "string").join("\n");
  if (perito) fontes.push(["perito", perito]);
  const achados = new Map();
  const add = (raw, origem) => {
    let k = raw.toUpperCase().replace(/\s+/g, "").replace(",", ".");
    if (/^[A-Z]\d{3}$/.test(k)) k = k.slice(0, 3) + "." + k[3];
    const hit = tab.get(k) || tab.get(k.replace(/\.\d$/, "")); if (!hit) return;
    const a = achados.get(hit[0]) || { n: 0, origem }; a.n++; if (origem === "perito") a.origem = "perito"; achados.set(hit[0], a);
  };
  for (const [origem, t] of fontes) {
    for (const m of t.matchAll(/\bCID(?:[\s-]*10)?\s*[:\-–nº°.]*\s*((?:[A-TV-Z]\s?\d{2}(?:[.,]?\d)?[\s,;/e]*){1,6})/gi)) for (const cd of m[1].matchAll(/[A-TV-Z]\s?\d{2}(?:[.,]?\d)?/gi)) add(cd[0], origem);
    for (const m of t.matchAll(/(?<![\w.])([A-TV-Z]\d{2}\.\d)(?![\w.])/g)) add(m[1], origem);
  }
  c.cids ||= []; let novos = 0;
  for (const [cd, a] of [...achados].sort((x, y) => y[1].n - x[1].n).slice(0, 12)) {
    if (c.cids.some(y => y.c10 === cd)) continue;
    const x = { c10: cd, d10: tab.get(cd.toUpperCase())[1], origem: a.origem };
    c.cids.push(x); novos++;
    const an = c.anamnese.cid || ""; if (!an.includes(cd)) c.anamnese.cid = (an ? an.replace(/\s+$/, "") + "\n" : "") + cidLine(x);
  }
  if (novos) { saveCase(); if (!S.running) rerenderTab(); }
  if (!silent) toast(novos ? `${novos} CID(s) encontrado(s) e adicionado(s) ao item 2.1. Confira e remova os que não se aplicam.` : "Nenhum CID novo encontrado nos documentos.", novos ? "ok" : undefined);
  return novos;
}


/* ===================== QUADRO "DADOS DA PERÍCIA" (sempre o mesmo formato) ===================== */
function dadosPericiaHTML() {
  const c = S.cur, p = S.profile, pr = c.processo || {}, x = c.indireta || {};
  const nat = [benefLabel(pr.beneficio), pr.natureza].filter(Boolean).join(" — ");
  const ast = pr.assistente === "Sim" ? [pr.assistenteNome, pr.assistenteCRM, pr.assistenteEsp].filter(Boolean).join(" — ") || "Sim" : pr.assistente === "Não" ? "Não compareceu" : "";
  const falta = '<span class="red">Não informado</span>';
  const rows = [
    ["Processo nº", pr.numero, true], ["Juízo / Vara", pr.juizo], ["Natureza / benefício", nat], ["Parte autora", pr.autor], ["Parte ré", pr.reu],
    ["Perito(a)", p.nome, true], ["CRM", p.crm, true], ["Local da perícia", pr.local], ["Data da perícia", fmtDate(pr.data), true], ["Horário", pr.horario],
    ["Telemedicina", pr.telemedicina], ["Assistente técnico", ast],
    ["Perícia indireta", x.sim ? `Sim — informante: ${[x.nome, x.parentesco && "(" + x.parentesco + ")"].filter(Boolean).join(" ") || "não informado"}${x.motivo ? "; motivo da ausência: " + x.motivo : ""}` : ""],
    ["Presentes na perícia", pr.presentes]
  ].filter(([, v, obrig]) => String(v ?? "").trim() || obrig);
  return `<h2>DADOS DA PERÍCIA</h2><table class="dados"><tbody>${rows.map(([k, v]) => `<tr><td><strong>${esc(k)}</strong></td><td>${String(v ?? "").trim() ? esc(v) : falta}</td></tr>`).join("")}</tbody></table>`;
}
