/* ===================== UTILITÁRIOS ===================== */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
const clone = o => JSON.parse(JSON.stringify(o));
const bytes = s => new TextEncoder().encode(s).length;
const today = () => { const d = new Date(); return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0"); };
const fmtDate = iso => { if (!iso) return ""; const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(iso); return m ? `${m[3]}/${m[2]}/${m[1]}` : iso; };
const MESES = ["janeiro", "fevereiro", "março", "abril", "maio", "junho", "julho", "agosto", "setembro", "outubro", "novembro", "dezembro"];
const dataExtenso = iso => { const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(iso || ""); if (!m) return ""; return `${+m[3]} de ${MESES[+m[2] - 1]} de ${m[1]}`; };
function idadeEm(nasc, ref) {
  const a = /^(\d{4})-(\d{2})-(\d{2})/.exec(nasc || ""), b = /^(\d{4})-(\d{2})-(\d{2})/.exec(ref || today());
  if (!a || !b) return "";
  let y = b[1] - a[1]; if (+b[2] < +a[2] || (+b[2] === +a[2] && +b[3] < +a[3])) y--;
  return y >= 0 && y < 130 ? y + " anos" : "";
}
const getPath = (o, p) => p.split(".").reduce((a, k) => (a == null ? a : a[k]), o);
function setPath(o, p, v) { const ks = p.split("."); let a = o; ks.slice(0, -1).forEach(k => { if (a[k] == null || typeof a[k] !== "object") a[k] = {}; a = a[k]; }); a[ks[ks.length - 1]] = v; }
const debounce = (fn, ms) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };
const benefLabel = id => (BENEFICIOS.find(b => b[0] === id) || [, ""])[1];

function toast(msg, kind = "") {
  const t = document.createElement("div"); t.className = "toast " + kind; t.textContent = msg;
  $("#toasts").appendChild(t); setTimeout(() => t.classList.add("out"), 4200); setTimeout(() => t.remove(), 4700);
}

function modal({ title, body, actions = [{ label: "Fechar" }], wide = false }) {
  return new Promise(res => {
    const w = document.createElement("div"); w.className = "modal-bg";
    w.innerHTML = `<div class="modal ${wide ? "wide" : ""}" role="dialog" aria-modal="true"><div class="modal-h"><h3>${esc(title)}</h3><button class="icon-btn" data-x aria-label="Fechar">✕</button></div><div class="modal-b"></div><div class="modal-f"></div></div>`;
    const b = $(".modal-b", w); if (typeof body === "string") b.innerHTML = body; else b.appendChild(body);
    const f = $(".modal-f", w);
    actions.forEach((a, i) => { const btn = document.createElement("button"); btn.className = "btn " + (a.cls || (i === actions.length - 1 ? "primary" : "")); btn.textContent = a.label; btn.onclick = () => { w.remove(); res(a.value ?? i); }; f.appendChild(btn); });
    $("[data-x]", w).onclick = () => { w.remove(); res(null); };
    w.addEventListener("mousedown", e => { if (e.target === w) { w.remove(); res(null); } });
    document.body.appendChild(w);
  });
}
const confirmar = (title, text, ok = "Confirmar", cls = "primary") => modal({ title, body: `<p>${esc(text)}</p>`, actions: [{ label: "Cancelar", cls: "", value: false }, { label: ok, cls, value: true }] });

/* ===================== ARMAZENAMENTO (db do Claude, ou IndexedDB local) ===================== */
const KV = {
  mode: "carregando", db: null, uid: null, idb: null, pending: {}, running: {},
  async init() {
    try {
      if (window.claude?.use) {
        const [db, user] = await Promise.all([claude.use("db"), claude.use("user")]);
        const id = user ? await user.id() : null;
        this.user = user;
        if (db && id) { this.db = db; this.uid = id; this.mode = "nuvem"; return; }
      }
    } catch (e) { console.warn("db indisponível", e); }
    try { this.idb = await new Promise((res, rej) => { const r = indexedDB.open("pericias-medicas", 1); r.onupgradeneeded = () => r.result.createObjectStore("kv"); r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); }); this.mode = "local"; }
    catch (e) { this.mode = "memoria"; this.mem = {}; }
  },
  ref(k) { return k.startsWith("config/") ? this.db.doc(k) : this.db.collection("data/users/" + this.uid).doc(k); },
  async get(k) {
    if (this.mode === "nuvem") { const s = await this.ref(k).get(); return s.exists ? clone(s.data()) : null; }
    if (this.mode === "local") return new Promise(res => { const r = this.idb.transaction("kv").objectStore("kv").get(k); r.onsuccess = () => res(r.result ?? null); r.onerror = () => res(null); });
    return this.mem[k] ? clone(this.mem[k]) : null;
  },
  async _set(k, v) {
    if (this.mode === "nuvem") return this.ref(k).set(v);
    if (this.mode === "local") return new Promise((res, rej) => { const t = this.idb.transaction("kv", "readwrite"); t.objectStore("kv").put(v, k); t.oncomplete = res; t.onerror = () => rej(t.error); });
    this.mem[k] = clone(v);
  },
  set(k, v) {           // fila: uma escrita por vez por documento, sempre a versão mais recente
    this.pending[k] = clone(v);
    if (!this.running[k]) this.running[k] = (async () => {
      try { while (this.pending[k]) { const val = this.pending[k]; delete this.pending[k]; await this._set(k, val); } }
      catch (e) { console.error(e); toast(e?.code === "invalid_argument" ? `Não foi possível salvar ${kvLabel(k)}: conteúdo grande demais (limite de 256 KB por registro).` : e?.code === "quota_exceeded" ? "Armazenamento cheio: exclua perícias antigas." : "Falha ao salvar. Tente novamente.", "err"); }
      finally { delete this.running[k]; setSaved(); }
    })();
    setSaving();
    return this.running[k];
  },
  async del(k) {
    if (this.mode === "nuvem") return this.ref(k).delete();
    if (this.mode === "local") return new Promise(res => { const t = this.idb.transaction("kv", "readwrite"); t.objectStore("kv").delete(k); t.oncomplete = res; t.onerror = res; });
    delete this.mem[k];
  }
};
function kvLabel(k) {
  if (k === "profile") return "o perfil (provavelmente o logotipo — tente uma imagem menor)";
  if (k.startsWith("case_")) return "os dados da perícia (provavelmente uma transcrição de entrevista muito longa — divida em duas entrevistas)";
  if (k.startsWith("txt_")) return "o texto de um documento";
  if (k.startsWith("fich_")) return "o fichamento de um documento";
  if (k.startsWith("out_")) return "os resultados das etapas do laudo";
  if (k.startsWith("html_")) return "o laudo editado";
  if (k.startsWith("chtml_")) return "o laudo complementar";
  if (k.startsWith("img_")) return "a miniatura de uma imagem";
  if (k.startsWith("config/")) return "a configuração da plataforma";
  return "um registro";
}
function setSaving() { const el = $("#savestate"); if (el) { el.textContent = "Salvando…"; el.className = "savestate saving"; } }
function setSaved() { if (Object.keys(KV.running).length) return; const el = $("#savestate"); if (el) { el.textContent = KV.mode === "nuvem" ? "Salvo na sua conta" : KV.mode === "local" ? "Salvo neste navegador" : "Não salvo (sem armazenamento)"; el.className = "savestate"; } }

/* ===================== CAPACIDADES DO CLAUDE ===================== */
const CAP = { sample: null, limits: null, dict: null, downloads: null };
async function initCaps() {
  if (!window.claude?.use) return;
  const [s, d, dl] = await Promise.all([claude.use("sample").catch(() => null), claude.use("dictation").catch(() => null), claude.use("downloads").catch(() => null)]);
  CAP.sample = s; CAP.dict = d; CAP.downloads = dl;
  if (s) CAP.limits = await s.limits().catch(() => null);
  if (d) {
    d.onPartial(({ text }) => DICT.partial(text));
    d.onFinal(({ text }) => DICT.final(text));
    d.onState(({ state }) => DICT.stateChange(state));
  }
  document.body.classList.toggle("no-mic", !CAP.dict);
  document.body.classList.toggle("no-ai", !CAP.sample);
}
const AI_ERR = {
  not_granted: "Você não autorizou o uso do Claude nesta página.", sampling_disabled: "O Claude não está disponível para esta conta.",
  rate_limited: "Limite de uso atingido. Aguarde um pouco e tente de novo.", prompt_too_large: "Conteúdo grande demais para uma única etapa. Reduza documentos ou divida.",
  refused: "O Claude recusou esta solicitação.", session_expired: "Sua sessão expirou. Entre novamente.", empty_completion: "O Claude não retornou texto.",
  invalid_json: "A resposta não veio no formato esperado. Tente de novo.", image_rejected: "Imagem não aceita (tipo ou tamanho).", images_unavailable: "Leitura de imagens indisponível nesta visualização.",
  cancelled: "Execução interrompida."
};
const VEL = () => S.vel || "equilibrado";
const aiMsg = e => AI_ERR[e?.code] || "Falha na comunicação com o Claude. Tente novamente.";
function needAI() { if (CAP.sample) return true; toast("Os recursos de IA funcionam quando a página é aberta no Claude (claude.ai ou app).", "err"); return false; }

/* ===================== ESTADO ===================== */
const S = {
  profile: clone(DEFAULT_PROFILE),
  prompts: { rules: DEFAULT_RULES, format: DEFAULT_FORMAT, steps: clone(DEFAULT_STEPS), aux: clone(DEFAULT_AUX), modelos: { completo: MODELO_ANAMNESE_1_4, simplificado: MODELO_ANAMNESE_SIMPLES }, tipoPadrao: clone(TIPO_PADRAO), v: 12 },
  qt: clone(DEFAULT_QTEMPLATES),
  index: { cases: [] },
  cur: null, out: null, html: null, tab: "processo",
  texts: {}, fich: {}, files: {}, thumbs: {}, aiFilled: new Set(), running: null,
  admin: true, padrao: clone(DEFAULT_PADRAO), cid10: null, cid11: null, cidMode: "10"
};

function newCase() {
  return {
    id: uid(), created: Date.now(), updated: Date.now(), status: "rascunho",
    processo: { data: today(), beneficio: "", local: "" }, periciando: {}, anamnese: {}, exame: {},
    complementares: [], outrosDocs: "", entrevistas: [], docs: [], cids: [], modulos: null, avaliacao: {}, avaliacaoSug: null, complementar: null, indireta: null,
    testes: { res: {}, gonio: {}, med: {}, dor: { escala: "EVA", valor: "", local: "", obs: "" }, segs: null },
    quesitos: { templates: [], juizoExtra: "", assistente: "", mp: "", autor: "", reu: "", outros: "" }
  };
}

async function loadAll() {
  S.admin = KV.user ? !!KV.user.isOwner() : true;
  const [p, cpr, cqt, cpad, ix] = await Promise.all([KV.get("profile"), KV.get("config/prompts"), KV.get("config/qtemplates"), KV.get("config/padrao"), KV.get("index")]);
  let pr = cpr, qt = cqt;
  if (S.admin && !cpr) { pr = await KV.get("prompts"); if (pr) KV.set("config/prompts", pr); }      // migra a versão antiga, privada
  if (S.admin && !cqt) { qt = await KV.get("qtemplates"); if (qt) KV.set("config/qtemplates", qt); }
  S.profile = Object.assign(clone(S.admin ? DEFAULT_PROFILE : DEFAULT_PROFILE_PERITO), p || {});
  if (cpad) S.padrao = Object.assign(clone(DEFAULT_PADRAO), cpad);
  if (pr) {
    S.prompts.rules = pr.rules ?? DEFAULT_RULES; S.prompts.format = pr.format ?? DEFAULT_FORMAT;
    S.prompts.steps = Array.isArray(pr.steps) && pr.steps.length ? pr.steps : clone(DEFAULT_STEPS);
    S.prompts.aux = Object.assign(clone(DEFAULT_AUX), pr.aux || {}); S.prompts.v = pr.v || 0;
    S.prompts.modelos = Object.assign({ completo: MODELO_ANAMNESE_1_4, simplificado: MODELO_ANAMNESE_SIMPLES }, pr.modelos || {});
    S.prompts.tipoPadrao = pr.tipoPadrao || clone(TIPO_PADRAO);
    if (S.prompts.modelos.simplificado?.startsWith("LAUDO MÉDICO PERICIAL (SIMPLIFICADO")) S.prompts.modelos.simplificado = S.prompts.modelos.simplificado.replace(/^[^\n]*/, MODELO_ANAMNESE_SIMPLES.split("\n")[0] || "");
  }
  if (qt && Array.isArray(qt.list)) S.qt = qt.list;
  if (ix && Array.isArray(ix.cases)) S.index = ix;
  if ((S.prompts.v || 0) < 2) {          // v2: conclusão e conclusão simplificada no final do laudo
    const cc = S.prompts.steps.find(s => s.id === "conclusao"); if (cc && cc.ordemLaudo === 50) cc.ordemLaudo = 90;
    S.prompts.v = 2; if (S.admin && pr) savePrompts();
  }
  if (S.prompts.v < 3) {                  // v3: etapa de avaliação social e modelo de corpo de delito
    const D = DEFAULT_STEPS.find(s => s.id === "social");
    if (D && !S.prompts.steps.some(s => s.id === "social")) { const i = S.prompts.steps.findIndex(s => s.id === "finais"); S.prompts.steps.splice(i < 0 ? S.prompts.steps.length : i, 0, clone(D)); }
    const Q = DEFAULT_QTEMPLATES.find(t => t.id === "corpodelito");
    if (Q && !S.qt.some(t => t.id === "corpodelito")) { const i = S.qt.findIndex(t => t.id === "internacao"); S.qt.splice(i < 0 ? S.qt.length : i, 0, clone(Q)); if (S.admin && qt) saveQt(); }
    S.prompts.v = 3; if (S.admin && pr) savePrompts();
  }
  const pf = await KV.get("prefs"); S.vel = pf?.vel || "equilibrado";
  const md0 = await KV.get("modulos"); S.modulos = Array.isArray(md0?.list) ? md0.list : clone(DEFAULT_MODULOS);
  if (S.prompts.v < 4) {                  // v4: marcações (excesso/investigar) e módulos de anamnese
    const f = S.prompts.format || "";
    if (!f.includes("<investigar>")) S.prompts.format = f.replace(/^- Para destacar EM VERMELHO.*$/m, "- Para destacar EM VERMELHO (erro, incoerência, inconsistência, dado ausente ou informação que não foi possível averiguar) use exatamente <red>texto</red>.\n- Trecho desnecessário (repetitivo, irrelevante para os quesitos ou além do que foi pedido): envolva com <excesso>texto</excesso>.\n- Ponto que o perito precisa investigar ou confirmar (dado a checar com o periciando, exame a solicitar, documento a buscar): escreva <investigar>o que investigar e por quê</investigar> logo após o trecho a que se refere.");
    if (!S.prompts.format.includes("<investigar>")) S.prompts.format += "\n- Trecho desnecessário: <excesso>texto</excesso>. Ponto a investigar pelo perito: <investigar>o que investigar</investigar>.";
    const sc = S.prompts.steps.find(s => s.id === "secoes");
    if (sc && sc.prompt && !sc.prompt.includes("{{MODULOS_ANAMNESE}}")) {
      const bloco = "MÓDULOS DE ANAMNESE E EXAME SELECIONADOS PELO PERITO (siga estes roteiros nas seções 2 e 3; não acrescente sistemas que não foram selecionados nem examinados):\n{{MODULOS_ANAMNESE}}\n\n";
      sc.prompt = sc.prompt.includes("\nMODELO:\n") ? sc.prompt.replace("\nMODELO:\n", "\n" + bloco + "MODELO:\n") : sc.prompt + "\n\n" + bloco;
    }
    S.prompts.v = 4; if (S.admin && pr && S.prompts.rules) savePrompts();
  }
  if (S.prompts.v < 5) {                  // v5: laudo na voz do perito (comentários só em <investigar>)
    if (S.prompts.format && !S.prompts.format.includes("VOZ DO PERITO")) S.prompts.format += "\n" + DEFAULT_FORMAT.split("\n").find(l => l.startsWith("- VOZ DO PERITO"));
    S.prompts.v = 5; if (S.admin && pr && S.prompts.rules) savePrompts();
  }
  if (S.prompts.v < 12) { if (S.prompts.rules) migrarV12(S.prompts, DEFAULT_STEPS, DEFAULT_FORMAT); if (S.prompts.v >= 11) { S.prompts.v = 12; if (S.admin && pr && S.prompts.rules) savePrompts(); } }
  if (S.prompts.v < 11) { if (S.prompts.rules) migrarV11(S.prompts, DEFAULT_STEPS); if (S.prompts.v >= 10) { S.prompts.v = 12; if (S.admin && pr && S.prompts.rules) savePrompts(); } }
  if (S.prompts.v < 10) { if (S.prompts.rules) migrarV10(S.prompts, DEFAULT_FORMAT); if (S.prompts.v >= 9) { S.prompts.v = 12; if (S.admin && pr && S.prompts.rules) savePrompts(); } }
  if (S.prompts.v < 9) { if (S.prompts.rules) migrarV9(S.prompts, DEFAULT_FORMAT); if (S.prompts.v >= 8) { S.prompts.v = 12; if (S.admin && pr && S.prompts.rules) savePrompts(); } }
  if (S.prompts.v < 8) { if (S.prompts.rules) migrarV8(S.prompts, DEFAULT_STEPS, DEFAULT_FORMAT); if (S.prompts.v >= 7) { S.prompts.v = 12; if (S.admin && pr && S.prompts.rules) savePrompts(); } }
  if (S.prompts.v < 7) { if (S.prompts.rules) migrarAuxV7(S.prompts.aux, DEFAULT_AUX); if (S.prompts.v >= 6) { S.prompts.v = 12; if (S.admin && pr && S.prompts.rules) savePrompts(); } }
  if (S.prompts.v < 6) {                  // v6: avaliação do perito + todos os itens no laudo completo
    if (S.prompts.rules) S.prompts.steps = migrarPromptsV6(S.prompts.steps, DEFAULT_STEPS);
    S.prompts.v = 12; if (S.admin && pr && S.prompts.rules) savePrompts();
  }
  const sg = await KV.get("assinatura"); if (sg?.d) { S.assinatura = sg.d; S.sigSize = { w: sg.w || 600, h: sg.h || 200 }; }
}
const saveProfile = () => KV.set("profile", S.profile);
const savePrompts = () => S.admin && KV.set("config/prompts", S.prompts);
const saveQt = () => S.admin && KV.set("config/qtemplates", { list: S.qt });
const saveModulos = () => KV.set("modulos", { list: S.modulos });
const savePadrao = () => S.admin && KV.set("config/padrao", S.padrao);

function indexEntry(c) {
  return { id: c.id, nome: c.periciando.nome || "", numero: c.processo.numero || "", beneficio: c.processo.beneficio || "", data: c.processo.data || "", status: c.status, updated: c.updated };
}
const _saveCase = debounce(() => saveCaseNow(), 900);
function saveCase() { if (!S.cur) return; S.cur.updated = Date.now(); S.cur.ai = [...S.aiFilled]; setSaving(); _saveCase(); }
async function saveCaseNow() {
  const c = S.cur; if (!c) return;
  KV.set("case_" + c.id, c);
  const e = indexEntry(c), i = S.index.cases.findIndex(x => x.id === c.id);
  const old = i >= 0 ? JSON.stringify(S.index.cases[i]) : "";
  if (i >= 0) S.index.cases[i] = e; else S.index.cases.unshift(e);
  if (old !== JSON.stringify(e)) KV.set("index", S.index);
}
async function openCase(id) {
  if (S.cur?.id === id) return true;
  const c = await KV.get("case_" + id);
  if (!c) { toast("Perícia não encontrada.", "err"); return false; }
  S.cur = Object.assign(newCase(), c);
  S.cur.quesitos = Object.assign(newCase().quesitos, c.quesitos || {});
  S.cur.testes = Object.assign(newCase().testes, c.testes || {});
  S.out = (await KV.get("out_" + id)) || { outputs: {} };
  const h = await KV.get("html_" + id); S.html = h?.html ? semSecoesRepetidas(tirarTituloDuplicado(h.html)) : null; S.htmlP = S.html; S.doc = "principal";
  const hc = await KV.get("chtml_" + id); S.htmlC = hc?.html || null; S.corrMsg = "";
  S.texts = {}; S.fich = {}; S.files = {}; S.thumbs = {}; S.aiFilled = new Set(c.ai || []); S.tab = "documentos"; S.autoRun = null;
  if (S.cur.complementar?.so && !S.htmlP) { S.doc = "comp"; S.html = S.htmlC; S.tab = "laudo"; }
  return true;
}
async function getText(doc) {
  if (S.texts[doc.id] != null) return S.texts[doc.id];
  let t = "";
  for (let n = 0; n < (doc.parts || 0); n++) { const r = await KV.get(`txt_${doc.id}_${n}`); t += r?.t || ""; }
  S.texts[doc.id] = t; return t;
}
async function putText(doc, text) {
  S.texts[doc.id] = text;
  const CH = 150000, parts = Math.max(1, Math.ceil(text.length / CH));
  for (let n = parts; n < (doc.parts || 0); n++) KV.del(`txt_${doc.id}_${n}`);
  doc.parts = parts; doc.chars = text.length;
  for (let n = 0; n < parts; n++) KV.set(`txt_${doc.id}_${n}`, { t: text.slice(n * CH, (n + 1) * CH) });
}
async function getFich(doc) {
  if (S.fich[doc.id] != null) return S.fich[doc.id];
  if (!doc.fichOk) return "";
  const r = await KV.get("fich_" + doc.id); S.fich[doc.id] = r?.t || ""; return S.fich[doc.id];
}
function putFich(doc, t) { S.fich[doc.id] = t; doc.fichOk = true; doc.fichAt = Date.now(); KV.set("fich_" + doc.id, { t }); }
const saveOut = () => KV.set("out_" + S.cur.id, S.out);
const htmlKey = () => (S.doc === "comp" ? "chtml_" : "html_") + S.cur.id;
const saveHtml = debounce(() => { if (S.cur) KV.set(htmlKey(), { html: S.html || "" }); }, 1200);

async function deleteCase(id) {
  const c = S.cur?.id === id ? S.cur : await KV.get("case_" + id);
  if (c) for (const d of c.docs || []) { for (let n = 0; n < (d.parts || 0); n++) KV.del(`txt_${d.id}_${n}`); KV.del("fich_" + d.id); KV.del("img_" + d.id); }
  ["case_", "out_", "html_", "chtml_"].forEach(p => KV.del(p + id));
  S.index.cases = S.index.cases.filter(x => x.id !== id); KV.set("index", S.index);
  if (S.cur?.id === id) S.cur = null;
}
