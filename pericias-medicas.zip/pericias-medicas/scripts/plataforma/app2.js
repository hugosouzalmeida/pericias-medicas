/* ===================== ÍCONES ===================== */
const I = {
  mic: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/></svg>',
  spark: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z"/><path d="M19 16l.7 1.8 1.8.7-1.8.7L19 21l-.7-1.8-1.8-.7 1.8-.7z"/></svg>',
  up: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 16V4M7 9l5-5 5 5M4 20h16"/></svg>',
  play: '<svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor"><path d="M7 4v16l13-8z"/></svg>',
  stop: '<svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor"><rect x="6" y="6" width="12" height="12" rx="2"/></svg>',
  doc: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M6 3h8l4 4v14H6z"/><path d="M14 3v4h4M9 12h6M9 16h6"/></svg>',
  trash: '<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/></svg>',
  check: '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12l5 5 9-10"/></svg>',
  arrowU: '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 19V5M6 11l6-6 6 6"/></svg>',
  arrowD: '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 5v14M6 13l6 6 6-6"/></svg>'
};
const SPIN = '<span class="spin"></span>';

/* ===================== CAMPOS ===================== */
function fieldHTML(group, [key, label, type, opts]) {
  const path = group + "." + key, v = getPath(S.cur, path) ?? "";
  const ai = S.aiFilled.has(path) ? " ai" : "";
  const mic = `<button type="button" class="mic" data-mic="${path}" data-miclabel="${esc(label)}" title="Ditar este campo">${I.mic}</button>`;
  if (type === "area") return `<label class="f wide${ai}"><span class="lbl">${esc(label)}</span><div class="iw"><textarea data-bind="${path}" rows="2">${esc(v)}</textarea>${mic}</div></label>`;
  if (type === "date" || type === "time") return `<label class="f${ai}"><span class="lbl">${esc(label)}</span><input type="${type}" data-bind="${path}" value="${esc(v)}"></label>`;
  if (type === "sel") return `<label class="f${ai}"><span class="lbl">${esc(label)}</span><select data-bind="${path}">${opts.map(([o, l]) => `<option value="${esc(o)}" ${o === v ? "selected" : ""}>${esc(l)}</option>`).join("")}${v && !opts.some(o => o[0] === v) ? `<option selected>${esc(v)}</option>` : ""}</select></label>`;
  if (type === "yn") return `<div class="f${ai}"><span class="lbl">${esc(label)}</span><div class="seg" data-seg="${path}">${["Sim", "Não"].map(o => `<button type="button" data-val="${o}" class="${v === o ? "on" : ""}">${o}</button>`).join("")}</div></div>`;
  if (type === "func") return `<label class="f${ai}"><span class="lbl">${esc(label)}</span><div class="iw"><input list="funcopts" data-bind="${path}" value="${esc(v)}" placeholder="Escolha ou descreva">${mic}</div></label>`;
  return `<label class="f${ai}"><span class="lbl">${esc(label)}</span><div class="iw"><input data-bind="${path}" value="${esc(v)}" ${key === "idade" ? 'readonly class="ro"' : ""}>${key === "idade" ? "" : mic}</div></label>`;
}
function formHTML(group, defs) {
  let html = "", open = false;
  for (const d of defs) {
    if (d[0] === "#") { if (open) html += "</div>"; html += `<h4 class="sub">${esc(d[1])}</h4><div class="grid">`; open = true; continue; }
    if (!open) { html += '<div class="grid">'; open = true; }
    html += fieldHTML(group, d);
  }
  return html + (open ? "</div>" : "");
}
function fill(group, defs) {
  const ks = defs.filter(d => d[0] !== "#" && d[2] !== "yn"); if (!ks.length) return 0;
  return Math.round(100 * ks.filter(d => String(getPath(S.cur, group + "." + d[0]) ?? "").trim()).length / ks.length);
}

/* ===================== ABAS DA PERÍCIA ===================== */
const TABS = [
  ["documentos", "Documentos"], ["processo", "Processo"], ["periciando", "Periciando"], ["entrevista", "Entrevista"],
  ["anamnese", "Anamnese"], ["exame", "Exame físico"], ["testes", "Testes especiais"], ["complementares", "Exames compl."], ["quesitos", "Quesitos"], ["avaliacao", "Avaliação do perito"], ["laudo", "Laudo"]
];

const svgI = d => `<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">${d}</svg>`;
const TAB_ICONS = {
  processo: svgI('<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>'),
  periciando: svgI('<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4.4 3.6-7 8-7s8 2.6 8 7"/>'),
  documentos: svgI('<path d="M6 3h8l4 4v14H6z"/><path d="M14 3v4h4M9 12h6M9 16h6"/>'),
  entrevista: svgI('<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/>'),
  anamnese: svgI('<rect x="5" y="4" width="14" height="17" rx="2"/><path d="M9 4h6v3H9zM9 12h6M9 16h4"/>'),
  exame: svgI('<path d="M6 3v6a4 4 0 0 0 8 0V3"/><path d="M10 13v2a5 5 0 0 0 10 0v-2"/><circle cx="20" cy="11" r="2"/>'),
  testes: svgI('<path d="M3 12h4l3-8 4 16 3-8h4"/>'),
  complementares: svgI('<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10" r="2"/><path d="M21 16l-5-5-9 9"/>'),
  quesitos: svgI('<path d="M21 12a8 8 0 0 1-11.6 7.1L4 20l1.1-4.6A8 8 0 1 1 21 12z"/><path d="M9.8 9.5a2.3 2.3 0 0 1 4.4 1c0 1.5-2.2 2-2.2 3M12 16.5h.01"/>'),
  avaliacao: svgI('<path d="M12 3l7 3v5c0 4.5-3 8-7 10-4-2-7-5.5-7-10V6z"/><path d="M9 12l2 2 4-4"/>'),
  laudo: svgI('<path d="M6 3h8l4 4v14H6z"/><path d="M14 3v4h4"/><path d="M9 17c1.5-2 2.5-2 3 0s1.5 1 3-1"/>')
};
const DICAS = {
  avaliacao: "Última etapa antes do laudo, com o exame, os testes e os quesitos já feitos. A decisão é sua: a IA só sugere, e nada entra nos campos sem você clicar em Aceitar. A conclusão (item 5), a conclusão simplificada e as respostas aos quesitos usam somente o que você marcar aqui.",
  processo: "Comece pelos dados da nomeação. Se você já tiver o PDF do processo, envie-o na aba Documentos e use “Preencher com IA”: a IA preenche apenas os campos vazios, e você confere.",
  periciando: "Identificação conforme o item 1 do laudo. A idade é calculada automaticamente pela data de nascimento e pela data da perícia.",
  documentos: "Comece por aqui. Envie os documentos da Justiça, os pessoais e os de saúde (PDF, Word ou fotos do celular) e clique em “Ler documentos e preencher”. A IA preenche as outras abas e mostra só o que ficou faltando para você completar. Fotos clínicas e exames de imagem vão no quadro próprio: a IA descreve os achados e sugere hipóteses auxiliares.",
  entrevista: "Grave a entrevista enquanto fala: o ditado transcreve em tempo real. Ao final, “Organizar nos campos” distribui o relato pela anamnese e pelo exame físico. Os campos preenchidos ficam destacados em dourado para sua revisão.",
  anamnese: "Item 2 do laudo — História da moléstia atual. Marque no topo os módulos de anamnese e exame desta perícia (completa, menor ou parcial). Busque o diagnóstico pelo código ou pelo nome na caixa de CID: ele entra no item 2.1 e nas tabelas de doença dos quesitos. Cada campo tem um microfone para ditar só aquele item.",
  testes: "Os segmentos sugeridos vêm da queixa e do CID. Marque o resultado de cada teste, meça a goniometria (a restrição é calculada sozinha) e registre a dor. Tudo vai automaticamente para os itens 3.2 i) e 3.2 j) do laudo.",
  exame: "Item 3 do laudo. O texto do exame físico é reproduzido fielmente no laudo, sem alteração de formato.",
  complementares: "Item 4 do laudo. Registre os exames com data e resultado. Exames encontrados nos documentos também são incluídos pela IA.",
  quesitos: "Selecione o(s) modelo(s) de quesitos do Juízo e cole os quesitos das partes. “Extrair dos autos” procura quesitos nos documentos já fichados.",
  laudo: "Marque as etapas que devem rodar nesta perícia (as que não valem para a modalidade já vêm desmarcadas). Os prompts são executados na ordem abaixo. Cada etapa usa o resultado das anteriores. Ao final, o laudo é montado na ordem correta das seções, com seu cabeçalho e rodapé, e pode ser editado e baixado em Word."
};
function tabProgress(t) {
  const c = S.cur;
  switch (t) {
    case "processo": return fill("processo", F_PROCESSO);
    case "periciando": return fill("periciando", F_PERICIANDO);
    case "anamnese": return fill("anamnese", F_ANAMNESE);
    case "exame": return fill("exame", F_EXAME);
    case "documentos": return c.docs.length ? Math.round(100 * c.docs.filter(d => d.fichOk).length / c.docs.length) : 0;
    case "entrevista": return c.entrevistas.some(e => (e.texto || "").trim()) ? 100 : 0;
    case "complementares": return c.complementares.length || c.outrosDocs ? 100 : 0;
    case "testes": return testesCount() ? 100 : 0;
    case "quesitos": return c.quesitos.templates.length || QUESITO_GRUPOS.some(g => (c.quesitos[g[0]] || "").trim()) ? 100 : 0;
    case "avaliacao": { const n = F_AVALIACAO.filter(([k]) => k !== "obs" && k !== "concausaGrau").length; return Math.round(100 * (n - avaliacaoPendentes(c).length) / n); }
    case "laudo": { const st = activeSteps(); return st.length ? Math.round(100 * st.filter(s => s.escopo === "documento" ? c.docs.length && c.docs.every(d => d.fichOk) : S.out.outputs[s.id]).length / st.length) : 0; }
  }
  return 0;
}
/* etapa marcada nesta perícia: escolha do perito ou, por padrão, se vale para a modalidade */
function stepDefault(s) { return !(s.modalidades || []).length || (s.modalidades || []).includes(S.cur?.processo?.beneficio); }
function stepOn(s) { const v = S.cur?.stepsOn?.[s.id]; return v != null ? v : stepDefault(s); }
const allSteps = () => S.prompts.steps.filter(s => s.ativo);
const activeSteps = () => allSteps().filter(stepOn);

function renderCase() {
  const c = S.cur, p = c.periciando;
  const tabs = TABS.map(([id, nome], i) => {
    const pr = tabProgress(id);
    return `<button class="tab ${S.tab === id ? "on" : ""}" data-tab="${id}"><span class="num ico ${pr === 100 ? "done" : ""}" title="${pr === 100 ? "Concluído" : nome}">${TAB_ICONS[id]}${pr === 100 ? `<b class="okb">${I.check}</b>` : ""}</span><span class="tl">${nome}</span>${pr > 0 && pr < 100 ? `<span class="pct">${pr}%</span>` : ""}</button>`;
  }).join("");
  const idx = TABS.findIndex(t => t[0] === S.tab);
  return `<div class="case-h">
      <div><div class="eyebrow">Perícia médica</div><h1>${esc(p.nome || "Nova perícia")}</h1>
      <div class="meta">${c.processo.numero ? `<span>Proc. ${esc(c.processo.numero)}</span>` : ""}${c.processo.beneficio ? `<span class="chip">${esc(benefLabel(c.processo.beneficio))}</span>` : ""}${c.processo.data ? `<span>${fmtDate(c.processo.data)}</span>` : ""}</div></div>
      <div class="case-actions"><button class="btn primary ai-btn" data-act="completar" title="Usa a entrevista e os documentos para responder todos os itens">${I.spark} Preencher tudo com IA</button><button class="btn ghost sm" data-act="delcase">${I.trash} Excluir</button></div>
    </div>
    <nav class="tabs" role="tablist">${tabs}</nav>
    <section class="tabbody">
      <div class="dica"><span class="dica-i">${TAB_ICONS[S.tab]}</span><b>${TABS[idx][1]}</b> — ${DICAS[S.tab]}</div>
      ${autoBanner()}
      ${tabHTML(S.tab)}
      <div class="tabnav">${idx > 0 ? `<button class="btn" data-tab="${TABS[idx - 1][0]}">← ${TABS[idx - 1][1]}</button>` : "<span></span>"}${idx < TABS.length - 1 ? `<button class="btn primary" data-tab="${TABS[idx + 1][0]}">${TABS[idx + 1][1]} →</button>` : ""}</div>
    </section>`;
}

function tabHTML(t) {
  const c = S.cur;
  switch (t) {
    case "processo": return `<div id="confbox"></div><div class="bar"><button class="btn ai-btn" data-act="aidados">${I.spark} Preencher com IA a partir dos documentos</button></div>${formHTML("processo", F_PROCESSO)}`;
    case "periciando": return `<div id="confbox"></div><div class="bar"><button class="btn ai-btn" data-act="aidados">${I.spark} Preencher com IA a partir dos documentos</button></div>${indiretaHTML()}${formHTML("periciando", F_PERICIANDO)}`;
    case "anamnese": return modulosCardHTML() + cidHTML() + formHTML("anamnese", F_ANAMNESE);
    case "avaliacao": return avaliacaoHTML();
    case "exame": return roteiroHTML() + formHTML("exame", F_EXAME) + (testesCount() ? `<div class="card fromtests"><h4>Da aba Testes especiais → 3.2 i) e j)</h4><pre class="pre">${esc(testesTexto().all)}</pre><button class="link" data-tab="testes">Editar testes</button></div>` : "");
    case "testes": return testesHTML();
    case "documentos": return docsHTML();
    case "entrevista": return entrevistaHTML();
    case "complementares": return complHTML();
    case "quesitos": return quesitosHTML();
    case "laudo": return laudoHTML();
  }
  return "";
}

/* ---------- Documentos ---------- */
const CATS = [
  ["processo", "Documentos da Justiça", "Autos do processo (PJe), petição, decisões, ofícios"],
  ["pessoais", "Documentos pessoais", "RG, CPF, CNH, comprovante de residência, CTPS"],
  ["saude", "Documentos de saúde", "Laudos, exames, atestados, receitas, prontuários"],
  ["imagens", "Imagens e exames de imagem", "Fotos clínicas, raio-X, ressonância, ultrassom"],
  ["outros", "Outros", "Qualquer outro arquivo relevante"],
  ["poslaudo", "Impugnação e documentos pós-laudo", "Impugnação, pedido de esclarecimentos, quesitos complementares e documentos novos"]
];
const IMG_TIPOS = ["Foto clínica", "Radiografia", "Ressonância magnética", "Ultrassonografia", "Tomografia", "Outro exame de imagem"];
const catLabel = id => (CATS.find(c => c[0] === id) || [, "Outros"])[1];
function docsHTML() {
  const c = S.cur;
  const zones = CATS.filter(z => z[0] !== "poslaudo").map(([id, nome, ex]) => `<label class="drop" data-drop="${id}">
      <input type="file" multiple accept=".pdf,.docx,.odt,.txt,.md,.jpg,.jpeg,.png,.webp" data-upload="${id}" hidden>
      <div class="drop-i">${I.up}</div><div class="drop-t">${nome}</div><div class="drop-s">${ex}</div>
      <div class="drop-n">${c.docs.filter(d => d.categoria === id).length} arquivo(s)</div></label>`).join("");
  const rows = c.docs.map(d => {
    let st;
    if (d.status === "extraindo") st = `<span class="st run">${SPIN} extraindo texto</span>`;
    else if (d.status === "erro") st = `<span class="st bad">erro: ${esc(d.erro || "")}</span>`;
    else if (d.status === "imagem") st = `<span class="st warn">aguardando análise da imagem pela IA</span>`;
    else if (d.analisando) st = `<span class="st run">${SPIN} analisando imagem</span>`;
    else if (d.categoria === "imagens" && d.analisado) st = `<span class="st ok">${I.check} imagem analisada</span>`;
    else if (d.status === "ocr") st = `<span class="st warn">${d.semTexto?.length ? d.semTexto.length + " pág. digitalizada(s)" : "imagem"} — precisa de leitura por IA</span>`;
    else if (d.fichando) st = `<span class="st run">${SPIN} fichando${d.fichProg ? " — parte " + d.fichProg : ""}</span>`;
    else if (d.fichOk) st = `<span class="st ok">${I.check} fichado</span>`;
    else st = `<span class="st">texto extraído — aguardando fichamento</span>`;
    const isImg = d.categoria === "imagens";
    return `<div class="docrow ${isImg ? "img" : ""}">
      ${isImg ? `<img class="thumb" data-thumb="${d.id}" alt="">` : `<div class="doc-i">${I.doc}</div>`}
      <div class="doc-m"><div class="doc-n">${esc(d.nome)}</div><div class="doc-s">${esc(catLabel(d.categoria))}${d.paginas ? " · " + d.paginas + " pág." : ""}${d.chars && !isImg ? " · " + pesoHTML(d) : ""}</div>${st}
        ${!isImg && d.tipo === "pdf" && d.paginas > 8 ? `<div class="pagsel"><span>Páginas para a IA:</span><input class="sm" data-pagsel="${d.id}" value="${esc(d.pagSel || "")}" placeholder="todas — ex.: 1-12, 40-55"></div>` : ""}
        ${isImg ? `<div class="imgmeta"><select class="sm" data-imgtipo="${d.id}">${IMG_TIPOS.map(t => `<option ${t === d.imgTipo ? "selected" : ""}>${t}</option>`).join("")}</select><input class="sm" data-imgdesc="${d.id}" value="${esc(d.imgDesc || "")}" placeholder="Região / observação (ex.: joelho direito, perfil)"></div>` : ""}</div>
      <div class="doc-a">
        <select data-doccat="${d.id}" class="sm" title="Categoria">${CATS.map(([id, n]) => `<option value="${id}" ${id === d.categoria ? "selected" : ""}>${n}</option>`).join("")}</select>
        ${isImg ? `<button class="btn sm ${d.analisado ? "" : "primary"} ai-btn" data-act="analisar" data-id="${d.id}" ${d.analisando ? "disabled" : ""}>${I.spark} ${d.analisado ? "Reanalisar" : "Analisar com IA"}</button>${d.fichOk ? `<button class="btn sm" data-act="verfich" data-id="${d.id}">Análise</button>` : ""}` : ""}
        ${!isImg && d.status === "ocr" ? `<button class="btn sm ai-btn" data-act="ocr" data-id="${d.id}">${I.spark} Ler com IA</button>` : ""}
        ${!isImg && d.chars ? `<button class="btn sm" data-act="vertexto" data-id="${d.id}">Texto</button>` : ""}
        ${!isImg && d.fichOk ? `<button class="btn sm" data-act="verfich" data-id="${d.id}">Ficha</button>` : ""}
        ${!isImg && d.chars && !d.fichando ? `<button class="btn sm ai-btn" data-act="fichar1" data-id="${d.id}" title="${d.fichOk ? "Refazer fichamento" : "Fichar"}">${I.spark}${d.fichOk ? " Refazer" : " Fichar"}</button>` : ""}
        <button class="icon-btn" data-act="deldoc" data-id="${d.id}" title="Remover">${I.trash}</button>
      </div></div>`;
  }).join("");
  const pend = c.docs.filter(d => d.chars && !d.fichOk && d.categoria !== "imagens").length;
  const ar = S.autoRun, ico = { pend: "○", run: SPIN, ok: I.check, skip: "–", err: "!" };
  const auto = `<div class="card autocard">
      <div class="auto-h"><div><h3>Ler documentos e preencher a perícia</h3><p class="note">A IA lê todos os documentos enviados (e a entrevista, se houver), preenche as abas Processo, Periciando, Anamnese, Exame físico, Exames complementares e Quesitos, e marca os modelos de quesitos da modalidade. Nada que você já escreveu é apagado.</p></div>
      <div class="auto-r">${velHTML()}<button class="btn primary lg ai-btn" data-act="tudo" ${ar?.on || !c.docs.length ? "disabled" : ""}>${ar?.on ? SPIN + " Trabalhando…" : I.spark + " Ler documentos e preencher"}</button></div></div>
      ${ar ? `<ol class="autosteps">${ar.labels.map(([k, l]) => `<li class="as-${ar.st[k]}"><span>${ico[ar.st[k]] || ""}</span>${esc(l)}</li>`).join("")}</ol>` : ""}
    </div>`;
  return `<div class="drops">${zones}</div>${auto}${c.autoAt ? pendenciasHTML() : ""}
    <div class="bar between"><h3 class="h3">Arquivos da perícia (${c.docs.length})</h3>
      <div class="row">${pend ? `<button class="btn primary ai-btn" data-act="ficharTodos">${I.spark} Fichar ${pend} documento(s)</button>` : ""}</div></div>
    ${rows || '<div class="empty">Nenhum documento ainda. Arraste os arquivos para os quadros acima ou clique para escolher.</div>'}
    <p class="note">PDFs digitalizados (sem texto) e fotos de documentos são lidos pela IA página a página. A leitura por IA exige o arquivo aberto nesta sessão: se recarregar a página antes, envie o arquivo de novo.</p>`;
}

/* ---------- Entrevista ---------- */
function entrevistaHTML() {
  const c = S.cur;
  if (!c.entrevistas.length) c.entrevistas.push({ id: uid(), titulo: "Entrevista com o(a) periciando(a)", participante: "Periciando(a)", data: today(), texto: "" });
  const list = c.entrevistas.map((e, i) => `<div class="card intv" data-intv="${e.id}">
      <div class="intv-h">
        <input class="title-in" data-ibind="${e.id}.titulo" value="${esc(e.titulo)}">
        <div class="row"><input class="sm" data-ibind="${e.id}.participante" value="${esc(e.participante)}" placeholder="Quem fala (periciando, acompanhante…)"><input type="date" class="sm" data-ibind="${e.id}.data" value="${esc(e.data)}">
        ${c.entrevistas.length > 1 ? `<button class="icon-btn" data-act="delintv" data-id="${e.id}" title="Excluir">${I.trash}</button>` : ""}</div>
      </div>
      <div class="rec-row">
        <button class="rec mic-big" data-rec="${e.id}">${I.mic}<span>Gravar e transcrever</span></button>
        <span class="rec-hint">Fale normalmente; o texto aparece abaixo. Clique de novo para parar.</span>
      </div>
      <textarea class="transcript" data-ibind="${e.id}.texto" rows="12" placeholder="A transcrição aparece aqui. Você também pode digitar ou colar.">${esc(e.texto)}</textarea>
      <div class="bar"><button class="btn primary ai-btn" data-act="organizar" data-id="${e.id}">${I.spark} Organizar nos campos da anamnese e do exame</button></div>
    </div>`).join("");
  return `<div class="no-mic-note">O ditado por voz funciona no Chrome ou no app do Claude para computador. Aqui você pode digitar ou colar a transcrição.</div>
    ${list}<button class="btn" data-act="addintv">+ Nova entrevista (acompanhante, familiar, assistente técnico)</button>`;
}

/* ---------- Exames complementares ---------- */
function complHTML() {
  const c = S.cur;
  const rows = c.complementares.map((x, i) => `<div class="card ex ${x.ia ? "ex-ai" : ""}">
      <div class="ex-h"><b>4.${i + 1}. Exame complementar ${i + 1}${x.ia ? ' <span class="chip sm">trazido dos documentos pela IA — confira</span>' : ""}</b><button class="icon-btn" data-act="delex" data-i="${i}">${I.trash}</button></div>
      <div class="grid">
        <label class="f"><span class="lbl">a) Tipo de exame</span><div class="iw"><input data-bind="complementares.${i}.tipo" value="${esc(x.tipo || "")}"><button type="button" class="mic" data-mic="complementares.${i}.tipo" data-miclabel="Tipo de exame">${I.mic}</button></div></label>
        <label class="f"><span class="lbl">b) Data</span><input type="date" data-bind="complementares.${i}.data" value="${esc(x.data || "")}"></label>
        <label class="f wide"><span class="lbl">c) Resultado / conclusão</span><div class="iw"><textarea data-bind="complementares.${i}.resultado" rows="2">${esc(x.resultado || "")}</textarea><button type="button" class="mic" data-mic="complementares.${i}.resultado" data-miclabel="Resultado">${I.mic}</button></div></label>
      </div></div>`).join("");
  return `${rows}<button class="btn" data-act="addex">+ Adicionar exame complementar</button>
    <div class="grid" style="margin-top:20px"><label class="f wide"><span class="lbl">4.${c.complementares.length + 1}. Outros documentos médicos apresentados</span><div class="iw"><textarea data-bind="outrosDocs" rows="3">${esc(c.outrosDocs || "")}</textarea><button type="button" class="mic" data-mic="outrosDocs" data-miclabel="Outros documentos">${I.mic}</button></div></label></div>`;
}

/* ---------- Quesitos ---------- */
function quesitosHTML() {
  const q = S.cur.quesitos, b = S.cur.processo.beneficio;
  const sug = S.qt.filter(t => (t.tags || []).includes(b)).map(t => t.id);
  const tpl = S.qt.map(t => `<label class="qt ${q.templates.includes(t.id) ? "on" : ""}"><input type="checkbox" data-qtpl="${t.id}" ${q.templates.includes(t.id) ? "checked" : ""}>
      <span><b>${esc(t.nome)}</b>${sug.includes(t.id) ? '<span class="chip sm">sugerido</span>' : ""}${t.base ? '<span class="chip sm warn">modelo base</span>' : ""}</span>
      <button type="button" class="link" data-act="verqt" data-id="${t.id}">ver</button></label>`).join("");
  const groups = QUESITO_GRUPOS.map(([k, l, h]) => `<label class="f wide${S.aiFilled.has("quesitos." + k) ? " ai" : ""}"><span class="lbl">${esc(l)}</span>${h ? `<span class="hint">${esc(h)}</span>` : ""}<textarea data-bind="quesitos.${k}" rows="4" placeholder="Cole aqui os quesitos, um por linha, com a numeração original.">${esc(q[k] || "")}</textarea></label>`).join("");
  return `<h3 class="h3">Quesitos do Juízo — modelos</h3><div class="qts">${tpl}</div>
    ${S.admin ? '<p class="note">Modelos editáveis em <a href="#quesitos">Modelos de quesitos</a>.</p>' : '<p class="note">Os modelos são mantidos pelo administrador da plataforma.</p>'}
    <div class="bar between"><h3 class="h3">Quesitos das partes</h3><button class="btn ai-btn" data-act="aiquesitos">${I.spark} Extrair quesitos dos autos</button></div>
    <div class="grid">${groups}</div>`;
}

/* ---------- Laudo ---------- */
function checklist() {
  const c = S.cur, pr = S.profile;
  const items = [
    [!!(pr.nome && pr.crm), "Perfil do perito (cabeçalho e rodapé)", "#perfil"],
    [fill("processo", F_PROCESSO) >= 40, "Dados do processo", "processo"],
    [fill("periciando", F_PERICIANDO) >= 30, "Identificação do periciando", "periciando"],
    [c.docs.length > 0 && c.docs.every(d => d.fichOk), `Documentos fichados (${c.docs.filter(d => d.fichOk).length}/${c.docs.length})`, "documentos"],
    [fill("anamnese", F_ANAMNESE) >= 40, "Anamnese", "anamnese"],
    [fill("exame", F_EXAME) >= 30, "Exame físico", "exame"],
    [!avaliacaoPendentes(c).length, "Avaliação do perito (incapacidade, nexo, concausa)", "avaliacao"],
    [c.conf?.numero === "ok" && c.conf?.nome === "ok", "Nº do processo e nome conferidos com os autos", "processo"],
    [c.quesitos.templates.length > 0 || !!c.quesitos.juizoExtra.trim(), "Quesitos do Juízo", "quesitos"],
    [!!S.assinatura, "Assinatura do perito", "#perfil"]
  ];
  return `<ul class="check">${items.map(([ok, l, go]) => `<li class="${ok ? "ok" : ""}"><span class="ck">${ok ? I.check : ""}</span>${go.startsWith("#") ? `<a href="${go}">${esc(l)}</a>` : `<button class="link" data-tab="${go}">${esc(l)}</button>`}</li>`).join("")}</ul>`;
}
function laudoHTML() {
  const steps = allSteps(), c = S.cur, run = S.running;
  const list = steps.map((s, i) => {
    let st = "", done;
    if (s.escopo === "documento") { const n = c.docs.filter(d => d.fichOk).length; done = c.docs.length && n === c.docs.length; st = c.docs.length ? `${n}/${c.docs.length} documentos` : "sem documentos"; }
    else { const o = S.out.outputs[s.id]; done = !!o; st = o ? "executada " + new Date(o.at).toLocaleString("pt-BR", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" }) : "pendente"; }
    const isRun = !!run?.steps?.has(s.id);
    const on = stepOn(s);
    return `<li class="step ${done ? "done" : ""} ${isRun ? "running" : ""} ${on ? "" : "off"}"><input type="checkbox" class="stepck" data-stepon="${s.id}" ${on ? "checked" : ""} ${run ? "disabled" : ""} title="Rodar esta etapa nesta perícia"><span class="sn">${isRun ? SPIN : done ? I.check : i + 1}</span>
      <div class="sm-m"><div class="st-n">${esc(s.nome)}</div><div class="st-s">${st}${s.ordemLaudo ? ` · posição no laudo: ${s.ordemLaudo}` : ""}</div></div>
      <div class="row">${S.out.outputs[s.id] ? `<button class="btn sm" data-act="verout" data-id="${s.id}">Ver</button>` : ""}<button class="btn sm" data-act="runstep" data-id="${s.id}" ${run ? "disabled" : ""}>${I.play}</button></div></li>`;
  }).join("");
  const comp = S.doc === "comp";
  const docseg = (S.htmlP || S.html || c.complementar) ? `<div class="docseg">${[["principal", "Laudo pericial"], ["comp", "Laudo complementar (impugnação)"]].map(([v, l]) => `<button type="button" data-docmode="${v}" class="${(comp ? "comp" : "principal") === v ? "on" : ""}">${l}</button>`).join("")}</div>` : "";
  return docseg + `<div class="laudo-grid">
    <aside class="lside">${comp ? compAsideHTML() : `
      <div class="card"><h4>Antes de gerar</h4>${checklist()}</div>
      <div class="card"><h4>Tipo de laudo</h4>${tipoLaudoHTML()}</div>
      <div class="card"><h4>Prompts — ordem de execução</h4><ol class="steps">${list}</ol>
        ${velHTML()}
        <div class="bar">${run ? `<button class="btn danger" data-act="stop">${I.stop} Parar</button>` : `<button class="btn primary ai-btn" data-act="runall">${I.play} Executar todos na ordem</button>`}${S.admin ? '<a class="btn ghost sm" href="#prompts">Editar prompts</a>' : ""}</div>
        <div class="stream ${run ? "" : "hidden"}" id="stream"><div class="stream-h" id="stream-h">${run ? esc(run.label || "") : ""}</div><div class="stream-b" id="stream-b">${run ? esc(run.text || "Pensando…") : ""}</div></div>
      </div>`}
    </aside>
    <div class="lmain">
      <div id="confbox"></div>
      <div class="bar between"><div class="seg viewseg">${[["conf", "Laudo de conferência"], ["final", "Laudo final (exportação)"]].map(([v, l]) => `<button type="button" data-lview="${v}" class="${(S.laudoView || "conf") === v ? "on" : ""}">${l}</button>`).join("")}</div>
        <div class="row">${comp ? "" : '<button class="btn" data-act="montar">Montar laudo</button>'}<button class="btn" data-act="copiar">Copiar laudo final</button></div></div>
      <div class="legend">${(S.laudoView || "conf") === "conf" ? reviewBarHTML() : '<b>Final:</b> é o que vai para o Word e o PDF — texto corrigido, na voz do perito, sem nenhum comentário da IA, sem marcações, sem pontos a investigar, sem trechos desnecessários não confirmados, sem resumo de inconsistências e sem itens “não informado”. Os quesitos ficam todos.'}</div>
      <div class="exportbar">
        <div class="ex-step"><span class="ex-n">1</span><div><b>Baixe o Word</b><small>Arquivo editável para correções</small></div><button class="btn primary" data-act="docx">${I.doc} Baixar Word</button></div>
        <div class="ex-arrow">→</div>
        <div class="ex-step"><span class="ex-n">2</span><div><b>Corrija no Word</b><small>Salve o arquivo no seu computador</small></div></div>
        <div class="ex-arrow">→</div>
        <div class="ex-step"><span class="ex-n">3</span><div><b>Gere o PDF final</b><small>Envie o Word conferido</small></div><label class="btn primary">${I.up} Enviar Word corrigido<input type="file" accept=".docx" data-wordfix hidden></label></div>
      </div>
      <div class="bar"><span class="note">Sem correções no Word?</span><button class="btn sm" data-act="pdf">Baixar PDF final</button><span class="note">·</span><button class="btn sm ghost" data-act="pdfconf">PDF de conferência (uso interno)</button></div>
      ${(S.laudoView || "conf") === "conf" && S.html ? correcoesHTML() : ""}
      ${paperHTML()}
      ${S.html ? `<div class="exportbar exfim"><b>Terminou de revisar?</b>
        <button class="btn" data-act="docx">${I.doc} Baixar Word</button>
        <button class="btn primary" data-act="pdf">Baixar PDF final</button>
        <label class="btn">${I.up} Enviar Word corrigido<input type="file" accept=".docx" data-wordfix hidden></label></div>` : ""}
    </div></div>`;
}
function correcoesHTML() {
  const comp = S.doc === "comp", path = comp ? "complementar.correcoes" : "correcoes", v = comp ? S.cur.complementar?.correcoes : S.cur.correcoes;
  return `<div class="card corrcard"><div class="cid-h"><h4>Correções do perito</h4><span class="note">Dite ou escreva as correções; a IA altera só esses trechos na folha.</span></div>
    <div class="iw"><textarea data-bind="${path}" rows="3" placeholder="Ex.: no item 1.6, a profissão é pedreiro desde 1990, não 1980. Na conclusão, o percentual é 25%. Acrescente no exame físico que a marcha é normal.">${esc(v || "")}</textarea><button type="button" class="mic" data-mic="${path}" data-miclabel="Correções do perito" title="Ditar as correções">${I.mic}</button></div>
    <div class="bar">${S.corrBusy ? `<button class="btn" disabled>${SPIN} Aplicando correções…</button>` : `<button class="btn primary ai-btn" data-act="aplicarcorr">${I.spark} Aplicar correções</button>`}${S.corrMsg ? `<span class="note">${S.corrMsg}</span>` : ""}</div></div>`;
}
function headerHTML() {
  const p = S.profile;
  return `<div class="ph"><img src="${p.logo || LOGO}" alt=""><div class="ph-t"><div class="ph-1">${esc(S.padrao.titulo)}</div><div class="ph-2">${esc(p.nome) || '<i class="ph-ph">Seu nome</i>'}</div><div class="ph-3">${esc(p.linha2) || '<i class="ph-ph">Médico | CRM</i>'}</div></div></div>`;
}
function footerHTML() {
  const p = S.profile;
  return `<div class="pf"><div><div>${esc(p.qualificacoes) || '<i class="ph-ph">Suas qualificações</i>'}</div><div>${esc(p.contato) || '<i class="ph-ph">Seu contato</i>'}</div></div><div class="pf-n">Página 1 de N</div></div>`;
}
function paperHTML() {
  const body = S.html ?? "";
  if ((S.laudoView || "conf") === "final" && body) return `<div class="paper final">${headerHTML()}<div class="paper-b" id="paperfinal">${buildFinal(body).innerHTML}</div>${footerHTML()}</div>`;
  return `<div class="paper">${headerHTML()}
    <div class="paper-b" id="paper" contenteditable="true" spellcheck="true">${body || '<p class="ph-empty">${S.doc === "comp" ? "O laudo complementar aparece aqui depois de clicar em “Gerar laudo complementar”. Você pode editar o texto diretamente nesta folha." : "O laudo aparece aqui depois de executar os prompts e clicar em “Montar laudo”. Você pode editar o texto diretamente nesta folha."}</p>'}</div>
    ${footerHTML()}</div>`;
}

/* ===================== PÁGINAS ===================== */
function renderHome() {
  const cs = [...S.index.cases].sort((a, b) => (b.updated || 0) - (a.updated || 0));
  const q = (S.homeQ || "").toLowerCase();
  const list = cs.filter(c => !q || (c.nome + " " + c.numero).toLowerCase().includes(q));
  const stLabel = { rascunho: "Rascunho", gerado: "Laudo gerado" };
  const nG = cs.filter(c => c.status === "gerado").length;
  const first = (S.profile.nome || "").replace(/^(dra?\.?\s+)/i, "").split(" ")[0];
  return `<div class="page-h"><div><div class="eyebrow">Painel do perito</div><h1>${first ? "Olá, " + esc(first) : "Perícias"}</h1></div><button class="btn primary lg" data-act="newcase">+ Nova perícia</button><button class="btn lg" data-act="newcomp" title="Para impugnação de laudo feito fora da plataforma: envie os autos com o laudo anterior">Só laudo complementar</button></div>
    <div class="stats"><div class="stat"><b>${cs.length}</b><span>perícias</span></div><div class="stat"><b>${cs.length - nG}</b><span>em andamento</span></div><div class="stat ok"><b>${nG}</b><span>laudos gerados</span></div>${S.profile.nome ? "" : '<a class="stat warn" href="#perfil"><b>!</b><span>complete seu perfil</span></a>'}</div>
    <ol class="how">
      <li><b>1</b><span>Dados do processo e do periciando</span></li>
      <li><b>2</b><span>Documentos: processo, pessoais e de saúde</span></li>
      <li><b>3</b><span>Entrevista ditada, anamnese e exame físico</span></li>
      <li><b>4</b><span>Quesitos do juízo e das partes</span></li>
      <li><b>5</b><span>Prompts executados em ordem → laudo em Word</span></li>
    </ol>
    ${cs.length ? `<div class="homebar"><input class="search" placeholder="Buscar por nome ou nº do processo" value="${esc(S.homeQ || "")}" data-homeq><button class="btn ghost sm danger" data-act="delall">${I.trash} Excluir todas as perícias</button></div>` : ""}
    <div class="cases">${list.map(c => `<a class="case-card" href="#caso-${c.id}">
        <div class="cc-n">${esc(c.nome || "Periciando não informado")}</div>
        <div class="cc-s">${c.numero ? "Proc. " + esc(c.numero) : "Sem nº de processo"}</div>
        <div class="cc-f"><span class="chip">${esc(benefLabel(c.beneficio) || "—")}</span><span>${fmtDate(c.data)}</span><span class="badge ${c.status}">${stLabel[c.status] || "Em andamento"}</span></div></a>`).join("") ||
    `<div class="empty big">Nenhuma perícia ainda. Clique em <b>Nova perícia</b> para começar.</div>`}</div>`;
}

function renderPerfil() {
  const p = S.profile;
  const f = (k, l, h = "") => `<label class="f wide"><span class="lbl">${l}</span>${h ? `<span class="hint">${h}</span>` : ""}<input data-pbind="${k}" value="${esc(p[k] || "")}"></label>`;
  return `<div class="page-h"><div><div class="eyebrow">Configuração</div><h1>Perfil do perito</h1></div></div>
    <p class="lead">Seus dados entram no cabeçalho e no rodapé de todos os seus laudos. O layout, as cores e as fontes são o padrão da plataforma e não mudam; o logotipo pode ser trocado.</p>
    <div class="two"><div class="grid one">
      <div class="f wide"><span class="lbl">Cabeçalho — título</span><div class="locked">${esc(S.padrao.titulo)} <span class="chip sm">padrão da plataforma</span>${S.admin ? ' <a class="link" href="#admin">alterar no Painel do administrador</a>' : ""}</div></div>
      ${f("nome", "Cabeçalho — nome do perito")}${f("linha2", "Cabeçalho — linha de qualificação", "Ex.: Médico | CRM-MT 8566")}
      ${f("crm", "CRM (para assinatura)")}${f("especialidade", "Especialidade (para assinatura)")}
      ${f("qualificacoes", "Rodapé — qualificações")}${f("contato", "Rodapé — contato")}${f("cidade", "Cidade para data e assinatura")}
      <div class="f wide"><span class="lbl">Logotipo</span><div class="row"><label class="btn">${I.up} Trocar logotipo<input type="file" accept="image/png,image/jpeg" data-logo hidden></label>${p.logo ? '<button class="btn ghost" data-act="logoreset">Usar o original</button>' : ""}</div></div>
    </div>
    <div><div class="lbl" style="margin-bottom:8px">Pré-visualização</div><div class="paper mini">${headerHTML()}<div class="paper-b"><p style="color:#999">…corpo do laudo…</p></div>${footerHTML()}</div></div></div>${sigCardHTML()}`;
}
function sigCardHTML() {
  return `<div class="card sigcard"><h4>Assinatura do perito</h4>
    <p class="note">Desenhe sua assinatura no quadro com o mouse, o dedo ou uma caneta, ou envie a foto da sua assinatura em papel branco. Ela entra no final do laudo, acima do seu nome e CRM.</p>
    <div class="sigwrap"><canvas id="sigpad" width="1000" height="300"></canvas><div class="sigbase"></div><span class="sighint">assine aqui</span></div>
    <div class="row"><button class="btn" data-act="sigclear">Limpar</button><button class="btn primary" data-act="sigsave">Salvar assinatura</button><label class="btn">${I.up} Enviar imagem da assinatura<input type="file" accept="image/png,image/jpeg" data-sigimg hidden></label></div>
    ${S.assinatura ? `<div class="sigsaved"><span class="lbl">Assinatura salva</span><img src="${S.assinatura}" alt="Assinatura"><button class="btn sm danger" data-act="sigdel">Remover</button></div>` : ""}</div>`;
}

function renderQuesitosPage() {
  return `<div class="page-h"><div><div class="eyebrow">Área do administrador</div><h1>Modelos de quesitos</h1></div><div class="row"><button class="btn" data-act="qtreset">Restaurar originais</button><button class="btn primary" data-act="qtadd">+ Novo modelo</button></div></div>
    <p class="lead">Modelos do Juízo carregados dos seus arquivos. Na aba Quesitos de cada perícia você marca quais usar. As tags ligam o modelo ao tipo de benefício para sugerir automaticamente.</p>
    ${S.qt.map((t, i) => `<details class="card qt-ed" ${S.openQt === t.id ? "open" : ""}><summary><b>${esc(t.nome)}</b>${t.base ? '<span class="chip sm warn">modelo base — revise</span>' : ""}<span class="tags">${(t.tags || []).map(x => `<span class="chip sm">${esc(benefLabel(x) || x)}</span>`).join("")}</span></summary>
      <label class="f wide"><span class="lbl">Nome</span><input data-qtbind="${i}.nome" value="${esc(t.nome)}"></label>
      <div class="f wide"><span class="lbl">Sugerir para</span><div class="tagpick">${BENEFICIOS.map(([id, l]) => `<label><input type="checkbox" data-qttag="${i}" value="${id}" ${(t.tags || []).includes(id) ? "checked" : ""}> ${esc(l)}</label>`).join("")}</div></div>
      <label class="f wide"><span class="lbl">Texto dos quesitos</span><textarea data-qtbind="${i}.texto" rows="14">${esc(t.texto)}</textarea></label>
      <div class="bar"><button class="btn danger sm" data-act="qtdel" data-i="${i}">${I.trash} Excluir modelo</button></div></details>`).join("")}`;
}

function renderPrompts() {
  const P = S.prompts;
  const steps = P.steps.map((s, i) => `<details class="card step-ed" ${S.openStep === s.id ? "open" : ""}>
      <summary><span class="sn">${i + 1}</span><b>${esc(s.nome)}</b><span class="chip sm">${s.escopo === "documento" ? "por documento" : "caso"}</span>${s.ordemLaudo ? `<span class="chip sm">laudo: ${s.ordemLaudo}</span>` : ""}${s.ativo ? "" : '<span class="chip sm warn">desativado</span>'}
        <span class="row right"><button class="icon-btn" data-act="stepup" data-i="${i}" title="Subir">${I.arrowU}</button><button class="icon-btn" data-act="stepdown" data-i="${i}" title="Descer">${I.arrowD}</button></span></summary>
      <div class="grid">
        <label class="f"><span class="lbl">Nome da etapa</span><input data-sbind="${i}.nome" value="${esc(s.nome)}"></label>
        <label class="f"><span class="lbl">Executar</span><select data-sbind="${i}.escopo"><option value="caso" ${s.escopo === "caso" ? "selected" : ""}>Uma vez por perícia</option><option value="documento" ${s.escopo === "documento" ? "selected" : ""}>Uma vez por documento (fichamento)</option></select></label>
        <label class="f"><span class="lbl">Posição da seção no laudo</span><input type="number" data-sbind="${i}.ordemLaudo" value="${s.ordemLaudo}"><span class="hint">0 = não entra no laudo</span></label>
        <label class="f"><span class="lbl">Profundidade da IA</span><select data-sbind="${i}.tier"><option value="quick" ${s.tier === "quick" ? "selected" : ""}>Rápida</option><option value="default" ${s.tier === "default" ? "selected" : ""}>Padrão</option><option value="complex" ${s.tier === "complex" ? "selected" : ""}>Máxima (mais lenta)</option></select></label>
        <label class="f"><span class="lbl">Ativa</span><select data-sbind="${i}.ativo"><option value="1" ${s.ativo ? "selected" : ""}>Sim</option><option value="0" ${!s.ativo ? "selected" : ""}>Não</option></select></label>
        <div class="f wide"><span class="lbl">Vale para as modalidades</span><span class="hint">Nenhuma marcada = vale para todas. Nas demais modalidades a etapa vem desmarcada na perícia (o perito pode marcar).</span><div class="tagpick">${BENEFICIOS.map(([id, l]) => `<label><input type="checkbox" data-smod="${i}" value="${id}" ${(s.modalidades || []).includes(id) ? "checked" : ""}> ${esc(l)}</label>`).join("")}</div></div>
        <label class="f wide"><span class="lbl">Prompt</span><textarea data-sbind="${i}.prompt" rows="16" class="mono">${esc(s.prompt)}</textarea></label>
      </div>
      <div class="bar"><button class="btn danger sm" data-act="stepdel" data-i="${i}">${I.trash} Excluir etapa</button></div></details>`).join("");
  const aux = [["organizar", "Organizar entrevista nos campos"], ["dados", "Preencher dados com IA"], ["quesitos", "Extrair quesitos dos autos"], ["ocr", "Ler documento digitalizado (OCR)"], ["imagem", "Analisar imagens clínicas e exames de imagem"], ["cid11", "Sugerir correspondência CID-11"], ["avaliacao", "Sugerir a avaliação do perito (incapacidade, nexo, concausa)"], ["complementar", "Laudo complementar (impugnação / esclarecimentos)"], ["completar", "Preencher tudo com IA (entrevista + documentos)"]];
  const vars = ["PERITO", "PROCESSO", "BENEFICIO", "PERICIANDO", "CIDS", "ANAMNESE", "EXAME", "EXAMES_COMPLEMENTARES", "ENTREVISTAS", "FICHAMENTOS", "QUESITOS_JUIZO", "QUESITOS_PARTES", "LISTA_ARQUIVOS", "LAUDO_ATE_AGORA", "MODELO_ANAMNESE_1_4", "MODELO_ANAMNESE_5", "TIPO_LAUDO", "MODULOS_ANAMNESE", "AVALIACAO_PERITO", "LAUDO_ORIGINAL", "IMPUGNACAO", "FICHAMENTOS_NOVOS", "DECISAO", "SECAO:id-da-etapa", "DOCUMENTO", "DOC_NOME", "DOC_CATEGORIA", "PARTE"];
  return `<div class="page-h"><div><div class="eyebrow">Área do administrador</div><h1>Prompts</h1></div><div class="row"><button class="btn" data-act="promptsreset">Restaurar padrão</button><button class="btn primary" data-act="stepadd">+ Nova etapa</button></div></div>
    <div class="admin-note">Só você, administrador, vê esta tela. Ao salvar, todos os peritos passam a usar esta versão dos prompts.</div>
    <p class="lead">Toda etapa recebe primeiro as <b>Diretrizes gerais</b> (seu Prompt Perícia TRT) e o <b>Formato</b>, depois o prompt da etapa. As etapas rodam de cima para baixo; a “posição no laudo” define onde cada resultado entra no documento final. Assim a conclusão é escrita antes dos quesitos (para as respostas ficarem coerentes) mas aparece depois deles no laudo.</p>
    <details class="card" open><summary><b>Diretrizes gerais — aplicadas a todas as etapas</b></summary><textarea data-pr="rules" rows="14" class="mono">${esc(P.rules)}</textarea></details>
    <details class="card"><summary><b>Formato de saída</b></summary><textarea data-pr="format" rows="9" class="mono">${esc(P.format)}</textarea></details>
    <h3 class="h3">Modelos de anamnese — laudo completo e simplificado</h3>
    <p class="note">A variável {{MODELO_ANAMNESE_1_4}} recebe o modelo completo ou o simplificado conforme o tipo de laudo escolhido em cada perícia. Os módulos de anamnese funcionam nos dois.</p>
    <details class="card"><summary><b>Modelo completo</b> — perícias complexas</summary><textarea data-pmod="completo" rows="16" class="mono">${esc(P.modelos?.completo || "")}</textarea></details>
    <details class="card"><summary><b>Modelo simplificado</b> — perícias simples</summary><textarea data-pmod="simplificado" rows="14" class="mono">${esc(P.modelos?.simplificado || "")}</textarea></details>
    <details class="card"><summary><b>Tipo de laudo padrão por modalidade</b></summary><p class="note">É o tipo que vem marcado ao criar a perícia. O perito pode trocar em cada perícia.</p>
      <div class="tpad">${BENEFICIOS.map(([id, l]) => `<label class="f"><span class="lbl">${esc(l)}</span><select data-tpad="${id}"><option value="completo" ${(P.tipoPadrao?.[id] || "completo") === "completo" ? "selected" : ""}>Completo</option><option value="simplificado" ${P.tipoPadrao?.[id] === "simplificado" ? "selected" : ""}>Simplificado</option></select></label>`).join("")}</div></details>
    <h3 class="h3">Etapas do laudo (ordem de execução)</h3>${steps}
    <h3 class="h3">Prompts auxiliares (botões de IA nas telas)</h3>
    ${aux.map(([k, l]) => `<details class="card"><summary><b>${l}</b></summary><textarea data-aux="${k}" rows="10" class="mono">${esc(P.aux[k])}</textarea></details>`).join("")}
    <div class="card"><b>Variáveis disponíveis</b><p class="note">Escreva entre chaves duplas, por exemplo {{FICHAMENTOS}}. São substituídas pelos dados da perícia na hora da execução.</p><div class="vars">${vars.map(v => `<code>{{${v}}}</code>`).join(" ")}</div></div>`;
}

function renderAjuda() {
  return `<div class="page-h"><div><div class="eyebrow">Guia</div><h1>Como usar</h1></div></div>
  <div class="guide">
    <section><h3>1. Seu perfil</h3><p>Em <a href="#perfil">Meu perfil</a>, preencha nome, CRM, especialidade, qualificações e contato, e troque o logotipo se quiser. O layout do cabeçalho e do rodapé é o padrão da plataforma.</p></section>
    <section><h3>2. Documentos</h3><p>Crie a perícia e envie o processo, os documentos pessoais e os de saúde (PDF, Word ou foto). Clique em <b>Fichar documentos</b>. Em <b>Imagens e exames de imagem</b>, a IA descreve fotos clínicas, raio-X, ressonância e ultrassom e sugere hipóteses auxiliares para você confirmar.</p></section>
    <section><h3>3. Entrevista e anamnese</h3><p>Grave a entrevista por voz e use <b>Organizar nos campos</b>. Na Anamnese, busque o <b>CID-10 ou CID-11</b> pelo código ou pelo nome: ele entra no item 2.1 e nos quesitos.</p></section>
    <section><h3>4. Exame e testes especiais</h3><p>A aba <b>Testes especiais</b> sugere os testes pela queixa e pelo CID. Marque positivo/negativo, meça a goniometria (a restrição em % é calculada) e registre a dor. Tudo entra nos itens 3.2 i) e j).</p></section>
    <section><h3>5. Quesitos e laudo</h3><p>Marque os modelos do Juízo, cole os quesitos das partes e, na aba Laudo, clique em <b>Executar todos na ordem</b>. Revise os pontos em vermelho e baixe em Word.</p></section>
    <section><h3>Administrador e perito</h3><p>O administrador mantém os prompts, os modelos de quesitos e o padrão do laudo; o que ele publica vale para todos. O perito usa o fluxo completo e vê só as próprias perícias.</p></section>
    <section><h3>Privacidade</h3><p>As perícias ficam na área privada de cada perito: nem o administrador as lê. O laudo é uma minuta; a responsabilidade técnica e a revisão final são do perito.</p></section>
  </div>`;
}

/* ===================== NAVEGAÇÃO POR PERFIL ===================== */
function renderNav() {
  const items = [["inicio", "Perícias"], ["modulos", "Módulos de anamnese"], ["perfil", "Meu perfil"], ["ajuda", "Como usar"]];
  const admin = [["admin", "Painel do administrador"], ["prompts", "Prompts"], ["quesitos", "Modelos de quesitos"]];
  const a = (h, l) => `<a href="#${h}" ${h === "inicio" ? 'data-nav="inicio"' : ""}><i></i>${l}</a>`;
  $("#nav").innerHTML = items.map(x => a(...x)).join("") + (S.admin ? `<div class="nav-sec">Administrador</div>` + admin.map(x => a(...x)).join("") : "");
  $("#role").innerHTML = S.admin ? '<span class="role admin">Administrador</span>' : '<span class="role">Perito</span>';
}

/* ===================== CID ===================== */
function cidLine(x) { return x.c10 ? `${x.d10} — CID-10 ${x.c10}${x.c11 ? ` / CID-11 ${x.c11}` : ""}` : `${x.d11} — CID-11 ${x.c11}`; }
function cidHTML() {
  const sel = (S.cur.cids || []).map((x, i) => `<div class="cidchip">
      <div class="cc-main">${x.c10 ? `<b class="code">${esc(x.c10)}</b> ${esc(x.d10)}${x.origem === "docs" ? ' <span class="chip sm">dos documentos</span>' : x.origem === "perito" ? ' <span class="chip sm">ditado pelo perito</span>' : ""}` : ""}${x.c11 ? `<div class="c11"><b class="code c11c">${esc(x.c11)}</b> ${esc(x.d11 || "")} ${x.ia11 ? '<span class="chip sm warn">CID-11 sugerido por IA — confira</span>' : ""}</div>` : ""}</div>
      <div class="row">${x.c10 && !x.c11 ? `<button class="btn sm ai-btn" data-act="cid11ia" data-i="${i}">${I.spark} Sugerir CID-11</button>` : ""}<button class="icon-btn" data-act="ciddel" data-i="${i}" title="Remover">${I.trash}</button></div></div>`).join("");
  return `<div class="card cidbox">
    <div class="cid-h"><h4>Diagnósticos — busca de CID</h4><div class="row"><button class="btn sm" data-act="cidsdocs" title="Procura códigos CID-10 nos documentos, na anamnese e nas entrevistas">${I.search || I.spark} Buscar CIDs nos documentos</button><div class="seg sm">${[["10", "CID-10"], ["11", "CID-11"]].map(([m, l]) => `<button type="button" data-cidmode="${m}" class="${S.cidMode === m ? "on" : ""}">${l}</button>`).join("")}</div></div></div>
    <div class="cidsearch"><input id="cidq" autocomplete="off" placeholder="${S.cidMode === "10" ? "Digite o código ou o nome — ex.: M54.5 ou lombalgia" : "Código ou termo em inglês — ex.: 2C77 ou low back pain"}"><div id="cidres" class="cidres"></div></div>
    ${sel ? `<div class="cidsel">${sel}</div>` : ""}
    <p class="note">CID-10: tabela oficial do DATASUS (revisão 2008). CID-11: lista oficial da OMS, com títulos em inglês. O diagnóstico escolhido entra no item 2.1 e nas tabelas de doença dos quesitos. Os CIDs citados nos documentos e os que você digitar ou ditar (ex.: “CID F10.2”) são adicionados sozinhos ao executar o laudo ou o “Preencher tudo com IA”.</p></div>`;
}

/* ===================== TESTES ESPECIAIS ===================== */
function suggestSegs() {
  const c = S.cur, txt = [c.anamnese.cid, c.anamnese.localizacao, c.anamnese.sintomas, c.exame.segmento, ...(c.cids || []).map(x => x.d10 || x.d11)].join(" ").toLowerCase();
  const codes = (c.cids || []).map(x => x.c10).filter(Boolean);
  return Object.entries(TESTES).filter(([, s]) => s.kw.some(k => txt.includes(k)) || codes.some(cd => s.cid.some(p => cd.startsWith(p)))).map(([k]) => k);
}
function testesCount() {
  const t = S.cur?.testes; if (!t) return 0;
  return Object.values(t.res).filter(r => r.r).length + Object.values(t.gonio).flatMap(o => Object.values(o || {})).filter(g => g && (g.d || g.e)).length + Object.values(t.med).filter(m => m.d || m.e).length + (t.dor.valor !== "" ? 1 : 0);
}
const restr = (ref, v) => (v === "" || v == null || isNaN(+v)) ? "" : Math.max(0, Math.round((ref - +v) / ref * 100));
function testesTexto() {
  const t = S.cur.testes, feitos = [], res = [];
  for (const [sk, seg] of Object.entries(TESTES)) for (const [id, nome] of seg.testes) {
    const r = t.res[id]; if (!r?.r || r.r === "Não realizado") continue;
    feitos.push(`${nome}${r.lado ? " (" + r.lado + ")" : ""}`);
    res.push(`${nome}${r.lado ? " — " + r.lado : ""}: ${r.r}${r.obs ? " (" + r.obs + ")" : ""}`);
  }
  const g = [];
  for (const [gk, j] of Object.entries(GONIO)) for (const [mid, mn, ref, ax] of j.mov) {
    const v = (t.gonio[gk] || {})[mid]; if (!v || (v.d === "" && v.e === "") || (!v.d && !v.e)) continue;
    const parts = [];
    if (v.d !== "" && v.d != null) parts.push(`${ax ? "" : "D "}${v.d}° (restrição ${restr(ref, v.d)}%)`);
    if (!ax && v.e !== "" && v.e != null) parts.push(`E ${v.e}° (restrição ${restr(ref, v.e)}%)`);
    if (parts.length) g.push(`${j.nome} — ${mn}: ${parts.join("; ")}; referência ${ref}°`);
  }
  if (g.length) { feitos.push("Goniometria"); res.push("Goniometria (referência AAOS): " + g.join(" | ")); }
  const m = [];
  for (const [id, nome, un, bil] of MEDIDAS) { const v = t.med[id]; if (!v || (!v.d && !v.e)) continue; m.push(`${nome}: ${bil ? [v.d ? `D ${v.d} ${un}` : "", v.e ? `E ${v.e} ${un}` : ""].filter(Boolean).join("; ") : `${v.d} ${un}`}${v.obs ? " (" + v.obs + ")" : ""}`); }
  if (m.length) { feitos.push(...m.map(x => x.split(":")[0])); res.push(...m); }
  if (t.dor.valor !== "") { feitos.push(t.dor.escala === "END" ? "Escala numérica de dor" : "Escala visual analógica de dor"); res.push(`Dor (${t.dor.escala}): ${t.dor.valor}/10${t.dor.local ? " — " + t.dor.local : ""}${t.dor.obs ? " (" + t.dor.obs + ")" : ""}`); }
  const i = feitos.join("; "), jj = res.map(x => "- " + x).join("\n");
  return { i, j: jj, all: feitos.length ? `3.2 i) ${i}\n3.2 j)\n${jj}` : "" };
}
function testesHTML() {
  const t = S.cur.testes, sug = suggestSegs();
  if (!t.segs) t.segs = sug.length ? [...sug] : [];
  const chips = Object.entries(TESTES).map(([k, s]) => `<button type="button" class="segchip ${t.segs.includes(k) ? "on" : ""} ${sug.includes(k) ? "sug" : ""}" data-tseg="${k}">${sug.includes(k) ? "★ " : ""}${esc(s.nome)}</button>`).join("");
  const cards = t.segs.map(k => {
    const s = TESTES[k]; if (!s) return "";
    const rows = s.testes.map(([id, nome, como, pos]) => {
      const r = t.res[id] || {};
      return `<div class="trow ${r.r === "Positivo" ? "pos" : r.r === "Negativo" ? "neg" : ""}">
        <div class="t-m"><div class="t-n">${esc(nome)}</div><div class="t-d"><b>Como:</b> ${esc(como)}<br><b>Positivo:</b> ${esc(pos)}</div></div>
        <div class="t-a"><div class="seg sm res">${TEST_RES.map(o => `<button type="button" data-tres="${id}" data-val="${o}" class="${r.r === o ? "on " + (o === "Positivo" ? "p" : o === "Negativo" ? "n" : "x") : ""}">${o === "Não realizado" ? "N/R" : o}</button>`).join("")}</div>
          <select class="sm" data-bind="testes.res.${id}.lado"><option value="">Lado</option>${["Direito", "Esquerdo", "Bilateral"].map(l => `<option ${r.lado === l ? "selected" : ""}>${l}</option>`).join("")}</select>
          <input class="sm obs" data-bind="testes.res.${id}.obs" value="${esc(r.obs || "")}" placeholder="Observação (ex.: 45°)"></div></div>`;
    }).join("");
    const gk = GONIO_SEG[k], gj = gk && GONIO[gk];
    const gon = gj ? `<div class="gonio"><div class="g-h">Goniometria — ${esc(gj.nome)} <span class="note">referência AAOS</span></div>
      <table><thead><tr><th>Movimento</th><th>Ref.</th><th>${gj.mov.some(m => !m[3]) ? "Direito" : "Medido"}</th><th>Restrição</th>${gj.mov.some(m => !m[3]) ? "<th>Esquerdo</th><th>Restrição</th>" : ""}</tr></thead><tbody>
      ${gj.mov.map(([mid, mn, ref, ax]) => { const v = (t.gonio[gk] || {})[mid] || {}; const rd = restr(ref, v.d), re = restr(ref, v.e);
        return `<tr><td>${esc(mn)}</td><td>${ref}°</td><td><input type="number" min="0" max="360" class="num" data-bind="testes.gonio.${gk}.${mid}.d" value="${esc(v.d ?? "")}">°</td><td class="pct ${rd >= 50 ? "hi" : rd > 0 ? "mid" : ""}" data-pct="${gk}.${mid}.d" data-ref="${ref}">${rd === "" ? "—" : rd + "%"}</td>${gj.mov.some(m => !m[3]) ? (ax ? "<td colspan=2 class='note'>movimento axial</td>" : `<td><input type="number" min="0" max="360" class="num" data-bind="testes.gonio.${gk}.${mid}.e" value="${esc(v.e ?? "")}">°</td><td class="pct ${re >= 50 ? "hi" : re > 0 ? "mid" : ""}" data-pct="${gk}.${mid}.e" data-ref="${ref}">${re === "" ? "—" : re + "%"}</td>`) : ""}</tr>`; }).join("")}
      </tbody></table></div>` : "";
    return `<div class="card tseg"><div class="tseg-h"><h3>${esc(s.nome)}</h3>${sug.includes(k) ? '<span class="chip sm">sugerido pela queixa/CID</span>' : ""}</div>${rows}${gon}</div>`;
  }).join("");
  const dor = t.dor, dv = dor.valor === "" ? null : +dor.valor;
  const med = MEDIDAS.map(([id, nome, un, bil, ref]) => { const v = t.med[id] || {};
    return `<div class="mrow"><div class="t-m"><div class="t-n">${esc(nome)}</div><div class="t-d">${esc(ref)}</div></div><div class="t-a">
      <label class="mlab">${bil ? "D" : ""}<input type="number" step="0.1" class="num" data-bind="testes.med.${id}.d" value="${esc(v.d || "")}"> ${un}</label>
      ${bil ? `<label class="mlab">E<input type="number" step="0.1" class="num" data-bind="testes.med.${id}.e" value="${esc(v.e || "")}"> ${un}</label>` : ""}
      <input class="sm obs" data-bind="testes.med.${id}.obs" value="${esc(v.obs || "")}" placeholder="Observação"></div></div>`; }).join("");
  return `<div class="card"><h4>Segmentos ${sug.length ? "— ★ sugeridos pela queixa e pelo CID" : "— nenhuma sugestão ainda: preencha a queixa ou o CID na Anamnese"}</h4><div class="segchips">${chips}</div></div>
    ${cards || '<div class="empty">Escolha um ou mais segmentos acima para abrir os testes.</div>'}
    <div class="two">
      <div class="card"><h4>Escala de dor</h4>
        <div class="row"><div class="seg sm">${["EVA", "END"].map(e => `<button type="button" data-tdor="${e}" class="${dor.escala === e ? "on" : ""}">${e === "EVA" ? "Visual analógica (EVA)" : "Numérica (END)"}</button>`).join("")}</div></div>
        <div class="dor"><input type="range" min="0" max="10" step="1" data-bind="testes.dor.valor" value="${dv ?? 0}" class="${dv == null ? "unset" : ""}"><div class="dor-n" id="dorn" style="--h:${dv == null ? 0 : 120 - dv * 12}">${dv == null ? "—" : dv}<small>/10</small></div></div>
        <div class="dor-l"><span>0 sem dor</span><span>5 moderada</span><span>10 pior dor</span></div>
        <div class="grid"><label class="f"><span class="lbl">Local</span><input data-bind="testes.dor.local" value="${esc(dor.local)}"></label><label class="f"><span class="lbl">Observação</span><input data-bind="testes.dor.obs" value="${esc(dor.obs)}" placeholder="ex.: comportamento doloroso compatível"></label></div>
        ${dv == null ? "" : '<button class="link" data-act="dorclear">limpar</button>'}
      </div>
      <div class="card"><h4>Medidas funcionais</h4>${med}</div>
    </div>
    <div class="card preview-laudo"><h4>Vai para o laudo — itens 3.2 i) e 3.2 j)</h4><pre class="pre" id="testes-prev">${esc(testesTexto().all || "Nenhum teste registrado ainda.")}</pre></div>`;
}

function autoBanner() {
  if (!["processo", "periciando", "anamnese", "exame", "complementares"].includes(S.tab) || !hasSources()) return "";
  const nAi = [...S.aiFilled].length;
  if (S.cur.autoAt) return nAi ? `<div class="autob done"><span>${I.spark}</span><div><b>${nAi} item(ns) foram preenchidos pela IA</b> a partir da entrevista e dos documentos. Os campos dourados aguardam sua revisão: ao editar, a marcação some.</div><button class="btn sm" data-act="completar">${I.spark} Preencher de novo</button></div>` : "";
  return `<div class="autob"><span>${I.spark}</span><div><b>A entrevista e os documentos já têm respostas para estes itens.</b> Deixe a IA preencher tudo; você só revisa e complementa. Nada que você já escreveu é apagado.</div><button class="btn primary ai-btn" data-act="completar">${I.spark} Preencher tudo com IA</button></div>`;
}

function confHTML(r) {
  if (!r) return "";
  if (r.semDoc) return `<div class="conf info"><b>Conferência com documento oficial</b><span>Anexe os autos ou outro documento oficial na categoria <b>Documentos da Justiça</b> (aba Documentos) para conferir automaticamente o nº do processo e o nome do periciando.</span></div>`;
  const st = { ok: ["ok", "confere com os autos"], divergente: ["bad", "NÃO confere com os autos"], nao_encontrado: ["warn", "não encontrado no texto dos autos"], parcial: ["warn", "confere parcialmente (grafia diferente ou abreviada) — confira"], vazio: ["", "não preenchido"] };
  const num = st[r.numero] || st.vazio, nom = st[r.nome] || st.vazio;
  const usar = (lista, attr) => (lista || []).map(x => `<button class="btn sm" ${attr}="${esc(x)}">Usar “${esc(x)}”</button>`).join("");
  return `<div class="conf ${r.numero === "ok" && r.nome === "ok" ? "good" : (r.numero === "divergente" || r.nome === "nao_encontrado") ? "bad" : "warn"}">
    <b>Conferência com documento oficial</b><span class="note">Base: ${esc((r.docs || []).join(", "))}</span>
    <div class="conf-row"><span class="st ${num[0]}">${num[0] === "ok" ? I.check : "●"} Nº do processo: ${num[1]}</span>${r.cnjValido === false ? '<span class="st bad">● dígito verificador inválido (padrão CNJ)</span>' : r.cnjValido ? '<span class="st ok">formato CNJ válido</span>' : ""}</div>
    ${r.numero !== "ok" && r.numerosAutos?.length ? `<div class="conf-sug">Números encontrados nos autos: ${usar(r.numerosAutos, "data-usenum")}</div>` : ""}
    <div class="conf-row"><span class="st ${nom[0]}">${nom[0] === "ok" ? I.check : "●"} Nome do periciando: ${nom[1]}</span></div>
    ${r.nome !== "ok" && r.nomesAutos?.length ? `<div class="conf-sug">Nomes de partes encontrados nos autos: ${usar(r.nomesAutos, "data-usenome")}</div>` : ""}
  </div>`;
}

/* ===================== PAINEL DO ADMINISTRADOR ===================== */
function renderAdminHome() {
  const ativos = S.prompts.steps.filter(s => s.ativo).length;
  const extra = window.API_MODE ? [["usuarios", "Usuários", "Cadastrar peritos, gerar senha temporária, desativar acesso"], ["ia", "IA e chaves de API", "Claude, OpenAI e OpenRouter; modelos e teste de conexão"], ["webhooks", "Webhooks", "Integrações de saída e de entrada"], ["uso", "Uso da IA", "Chamadas e tokens por perito e por mês"]] : [];
  const tiles = [["prompts", "Prompts", `${ativos} etapas ativas + prompts auxiliares`], ["quesitos", "Modelos de quesitos", `${S.qt.length} modelos`], ...extra];
  return `<div class="page-h"><div><div class="eyebrow">Área do administrador</div><h1>Painel do administrador</h1></div></div>
    <div class="admin-note">Só você vê esta área. O que for alterado aqui vale para todos os peritos. Os dados de cada perito (perfil, assinatura e perícias) continuam sendo de cada um.</div>
    <div class="two">
      <div class="card"><h4>Padrão do laudo — vale para todos</h4>
        <label class="f wide"><span class="lbl">Título do cabeçalho</span><input data-padrao="titulo" value="${esc(S.padrao.titulo)}"></label>
        <p class="note">O layout, as cores e as fontes do cabeçalho e do rodapé são fixos. Cada perito preenche nome, CRM, qualificações, contato, logotipo e assinatura em “Meu perfil”.</p>
        <div class="lbl" style="margin:10px 0 6px">Pré-visualização</div><div class="paper mini">${headerHTML()}<div class="paper-b"><p style="color:#999">…corpo do laudo…</p></div>${footerHTML()}</div>
      </div>
      <div class="admtiles">${tiles.map(([h, t, d]) => `<a class="admtile" href="#${h}"><b>${t}</b><span>${d}</span></a>`).join("")}</div>
    </div>`;
}

/* ===================== O QUE FALTA O PERITO COMPLETAR ===================== */
const PEND_SKIP = { processo: ["assistenteNome", "assistenteCRM", "assistenteEsp", "natureza"], periciando: ["nomeSocial", "genero", "raca", "email", "telefone", "orgao", "idade"] };
function pendencias() {
  const c = S.cur, out = [];
  const add = (tab, group, defs) => {
    const vazios = defs.filter(d => d[0] !== "#" && d[2] !== "yn" && !(PEND_SKIP[group] || []).includes(d[0]) && !String(getPath(c, group + "." + d[0]) ?? "").trim()).map(d => d[1]);
    const total = defs.filter(d => d[0] !== "#" && d[2] !== "yn" && !(PEND_SKIP[group] || []).includes(d[0])).length;
    out.push({ tab, nome: TABS.find(t => t[0] === tab)[1], vazios, total });
  };
  add("processo", "processo", F_PROCESSO); add("periciando", "periciando", F_PERICIANDO); add("anamnese", "anamnese", F_ANAMNESE); add("exame", "exame", F_EXAME);
  out.push({ tab: "complementares", nome: "Exames compl.", vazios: c.complementares.length ? [] : ["nenhum exame complementar encontrado"], total: 1 });
  const nsug = S.qt.filter(t => (t.tags || []).includes(c.processo.beneficio)).length;
  out.push({ tab: "quesitos", nome: "Quesitos", vazios: c.quesitos.templates.length || c.quesitos.juizoExtra.trim() ? [] : [nsug > 1 ? `escolha o modelo do Juízo (${nsug} sugeridos)` : "nenhum modelo de quesitos do Juízo marcado"], total: 1 });
  return out;
}
function pendenciasHTML() {
  const p = pendencias(), falta = p.reduce((a, x) => a + x.vazios.length, 0);
  return `<div class="card pendcard"><h4>${falta ? `O que falta você completar — ${falta} item(ns)` : "Tudo preenchido — revise os campos dourados"}</h4>
    <div class="pendgrid">${p.map(x => `<button class="pend ${x.vazios.length ? "" : "okp"}" data-tab="${x.tab}"><b>${esc(x.nome)}</b><span>${x.vazios.length ? x.vazios.length + " vazio(s): " + esc(x.vazios.slice(0, 4).join(", ")) + (x.vazios.length > 4 ? "…" : "") : "completo"}</span></button>`).join("")}</div>
    <p class="note">O exame físico depende do seu exame: ele só é preenchido a partir do que você ditar ou escrever, nunca dos documentos.</p></div>`;
}

/* ===================== VELOCIDADE E PESO DOS DOCUMENTOS ===================== */
function velHTML() {
  const v = VEL(), opts = [["rapido", "Rápido", "modelos mais leves; ideal para testes e casos simples"], ["equilibrado", "Equilibrado", "recomendado: profundidade máxima só na conclusão, nos quesitos do Juízo e nas imagens"], ["max", "Máxima qualidade", "mais lento: profundidade máxima em todas as etapas"]];
  return `<div class="velbox"><span class="lbl">Velocidade da IA</span><div class="seg sm">${opts.map(([k, l, d]) => `<button type="button" data-vel="${k}" class="${v === k ? "on" : ""}" title="${esc(d)}">${l}</button>`).join("")}</div><span class="note">${esc(opts.find(o => o[0] === v)[2])}</span></div>`;
}
function pesoHTML(d) {
  const ia = d.charsIA ?? d.chars, partes = Math.max(1, Math.ceil(ia / 90000));
  const red = d.chars && ia < d.chars ? ` (−${Math.round(100 - 100 * ia / d.chars)}% após limpeza${d.pagSel ? " e seleção" : ""})` : "";
  return `<span class="${partes > 2 ? "peso hi" : "peso"}">${(ia / 1000).toFixed(0)} mil caracteres para a IA${red}${partes > 1 ? ` · ${partes} partes` : ""}</span>`;
}

/* ===================== MÓDULOS DE ANAMNESE ===================== */
function modulosDaPericia() { const c = S.cur; return c.modulos ?? modulosSugeridos(c).filter(id => S.modulos.some(m => m.id === id)); }
function modulosCardHTML() {
  const sel = modulosDaPericia(), sug = modulosSugeridos(S.cur);
  return `<div class="card modcard"><div class="cid-h"><h4>Tipo de laudo e módulos desta perícia</h4><a class="link" href="#modulos">editar módulos</a></div>
    ${tipoLaudoHTML()}
    <div class="segchips">${S.modulos.map(m => `<button type="button" class="segchip ${sel.includes(m.id) ? "on" : ""} ${sug.includes(m.id) ? "sug" : ""}" data-modsel="${esc(m.id)}">${sug.includes(m.id) ? "★ " : ""}${esc(m.nome)}</button>`).join("")}</div>
    <p class="note">${sel.length} módulo(s) marcado(s). A IA segue só os roteiros marcados nas seções 2 e 3 do laudo. ★ = sugerido pela modalidade e pelos CIDs.${S.cur.modulos ? ' <button class="link" data-act="modauto">voltar às sugestões</button>' : ""}</p></div>`;
}
function roteiroHTML() {
  const sel = modulosDaPericia(), ms = S.modulos.filter(m => sel.includes(m.id));
  if (!ms.length) return "";
  return `<details class="card roteiro"><summary><b>Roteiro do exame</b> — ${ms.map(m => esc(m.nome)).join(" · ")}</summary>${ms.map(m => `<div class="rot"><b>${esc(m.nome)}</b><pre>${esc(m.texto)}</pre></div>`).join("")}</details>`;
}
function renderModulos() {
  return `<div class="page-h"><div><div class="eyebrow">Meus modelos</div><h1>Módulos de anamnese</h1></div><div class="row"><button class="btn" data-act="modreset">Restaurar originais</button><button class="btn primary" data-act="modadd">+ Novo módulo</button></div></div>
    <p class="lead">Cada módulo é um roteiro de anamnese e exame de um sistema. Em cada perícia você marca os módulos que vai usar (aba Anamnese) e a IA segue só esses roteiros. Edite o texto à vontade, crie os seus e exclua os que não usa. Estes módulos são só seus.</p>
    ${S.modulos.map((m, i) => `<details class="card" ${S.openMod === m.id ? "open" : ""}><summary><b>${esc(m.nome)}</b></summary>
      <label class="f wide"><span class="lbl">Nome</span><input data-modbind="${i}.nome" value="${esc(m.nome)}"></label>
      <label class="f wide"><span class="lbl">Roteiro (anamnese e exame)</span><textarea data-modbind="${i}.texto" rows="7">${esc(m.texto)}</textarea></label>
      <div class="bar"><button class="btn danger sm" data-act="moddel" data-i="${i}">${I.trash} Excluir módulo</button></div></details>`).join("")}`;
}

/* ===================== REVISÃO DA MINUTA ===================== */
function reviewBarHTML() {
  const d = document.createElement("div"); d.innerHTML = S.html || "";
  const n = c => d.querySelectorAll("span." + c).length, r = n("red"), x = n("excesso"), v = n("investigar"), g = n("sugestao");
  return `<div class="revbar"><b>Minuta de conferência</b> — clique num trecho marcado para resolver; ao corrigir o texto, a marcação some sozinha. <b>Depois de corrigir, não clique em “Montar laudo”</b>: isso apaga as correções (baixe direto o Word ou o PDF).
    <span class="revc"><span class="red">${r} erro/inconsistência</span><span class="excesso">${x} desnecessário</span><span class="investigar">${v} a investigar</span>${g ? `<span class="sugestao">${g} sugestão(ões) para decidir</span>` : ""}${r + x + v + g ? '<button class="btn sm" data-act="proxmarca">Próximo ponto ↓</button>' : '<span class="st ok">' + I.check + ' nenhuma pendência</span>'}</span></div>`;
}

/* ===================== TIPO DE LAUDO ===================== */
function tipoLaudo(c = S.cur) { return c?.tipoLaudo || S.prompts.tipoPadrao?.[c?.processo?.beneficio] || "completo"; }
function tipoLaudoHTML() {
  const t = tipoLaudo();
  return `<div class="seg tiposeg">${[["completo", "Completo"], ["simplificado", "Simplificado"]].map(([v, l]) => `<button type="button" data-tipolaudo="${v}" class="${t === v ? "on" : ""}">${l}</button>`).join("")}</div>
    <p class="note">${t === "simplificado" ? "Modelo simplificado: itens essenciais, texto objetivo — para perícias simples." : "Modelo completo: todos os itens da anamnese — para perícias complexas."}${S.cur?.tipoLaudo ? "" : " (padrão da modalidade)"}</p>`;
}

/* ===================== AVALIAÇÃO DO PERITO ===================== */
function avaliacaoHTML() {
  const c = S.cur; c.avaliacao = c.avaliacao || {};
  const sug = c.avaliacaoSug || {}, pend = avaliacaoPendentes(c), busy = S.avalBusy;
  const nT = (typeof testesCount === "function") ? testesCount(c.testes) : 0;
  const campo = f => {
    const [k] = f, sg = sug[k], v = String(c.avaliacao[k] ?? "");
    const sgv = sg && String(sg.valor ?? "").trim();
    const igual = sgv && sgv.toLowerCase() === v.toLowerCase();
    const sh = sg && (sgv || sg.faltam) ? `<div class="sug ${igual ? "ok" : ""}"><span class="sug-t">IA sugere:</span> ${sgv ? `<b>${esc(sgv)}</b>` : "<i>sem sugestão</i>"}${sg.justificativa ? ` — ${esc(sg.justificativa)}` : ""}${sg.faltam ? `<div class="falta">Falta para embasar: ${esc(sg.faltam)}</div>` : ""}${sgv && !igual ? `<button type="button" class="btn sm" data-aceitar="${k}">${I.check} Aceitar</button>` : igual ? '<span class="st ok">aceito</span>' : ""}</div>` : "";
    return `<div class="avf ${f[2] === "area" ? "wide" : ""}">${fieldHTML("avaliacao", f)}${sh}</div>`;
  };
  return `<div class="card avcard" id="avaliacao"><div class="cid-h"><h4>Avaliação do perito — decisão exclusiva do perito</h4>
      <div class="row"><button class="btn sm" data-tab="testes">${I.ruler || ""} Goniometria e testes especiais${nT ? ` (${nT})` : ""}</button>
      <button class="btn sm ai-btn" data-act="avalsug" ${busy ? "disabled" : ""}>${busy ? SPIN + " Analisando…" : "✦ Pedir sugestão à IA"}</button></div></div>
    <p class="note">Você examinou o periciando: a decisão é sua. A IA só sugere, com justificativa e o que falta para embasar; nada entra nos campos sem você clicar em <b>Aceitar</b>. A conclusão (item 5), a conclusão simplificada e os quesitos usam somente o que estiver marcado aqui.</p>
    ${sug.geral ? `<div class="sug geral"><span class="sug-t">Dados que faltam (IA):</span> ${esc(sug.geral)}</div>` : ""}
    <div class="avgrid">${F_AVALIACAO.filter(([k]) => avalCampoVisivel(c, k)).map(campo).join("")}</div>
    ${avalPendHTML(pend)}</div>`;
}
function avalPendHTML(pend = avaliacaoPendentes(S.cur)) {
  return pend.length ? `<p class="note warnline" id="avpend">Ainda sem decisão: ${pend.map(esc).join(", ")}. No laudo de conferência esses pontos aparecem em vermelho como pendentes.</p>` : '<p class="note okline" id="avpend">Avaliação completa.</p>';
}

/* ===================== LAUDO COMPLEMENTAR ===================== */
function compAsideHTML() {
  const c = S.cur, k = c.complementar || {}, run = S.running, docs = c.docs.filter(d => d.categoria === "poslaudo");
  const dec = k.decisao || "";
  const docRow = d => `<li>${I.doc} ${esc(d.nome)} — ${d.fichando ? SPIN + " fichando" + (d.fichProg ? " " + d.fichProg : "") : d.fichOk ? '<span class="st ok">fichado</span>' : d.status === "extraindo" ? SPIN + " lendo" : '<span class="st warn">a fichar</span>'}</li>`;
  const autos = !temLaudoPlataforma(), loc = k.loc;
  return `<div class="card compcard"><h4>Laudo complementar</h4>
    <p class="note">Para impugnação, pedido de esclarecimentos ou quesitos complementares. ${autos ? "Como o laudo anterior não foi feito na plataforma, a IA localiza o laudo nos autos e usa ele como base." : "Usa o laudo pericial desta perícia como base e gera só o complemento, sem refazer tudo."}</p>
    ${autos && loc ? (loc.ok ? `<div class="sug ok">Laudo anterior localizado nos autos: <b>${esc(loc.doc)}</b> (~${Math.max(1, Math.round(loc.chars / 3000))} pág.)${loc.conc ? "" : " — a conclusão não foi separada automaticamente; confira na folha."}</div>` : `<div class="sug bad"><span class="red">Laudo pericial anterior não localizado nos autos enviados.</span> Envie o laudo separado (PDF ou Word) abaixo e gere de novo.</div>`) : ""}
    <div class="cstep"><b>1. ${autos ? "Envie os autos completos (com o laudo anterior e a impugnação)" : "Envie a impugnação e os documentos novos"}</b>
      <label class="drop mini-drop" data-drop="poslaudo"><input type="file" multiple accept=".pdf,.docx,.odt,.txt,.md,.jpg,.jpeg,.png,.webp" data-upload="poslaudo" hidden>
        <div class="drop-i">${I.up}</div><div class="drop-t">Impugnação e documentos pós-laudo</div><div class="drop-s">Arraste ou clique — PDF, Word, imagens</div></label>
      ${docs.length ? `<ul class="clist">${docs.map(docRow).join("")}</ul>` : ""}</div>
    <div class="cstep"><b>2. Ou cole o texto da impugnação / quesitos complementares</b>
      <div class="iw"><textarea data-bind="complementar.texto" rows="4" placeholder="Opcional se a impugnação já foi enviada como arquivo">${esc(k.texto || "")}</textarea><button type="button" class="mic" data-mic="complementar.texto" data-miclabel="Impugnação">${I.mic}</button></div></div>
    <div class="cstep"><b>3. Repercussão na conclusão — decisão do perito</b>
      <div class="seg">${[["", "Ainda não decidi"], ["manter", "Mantém (ratifica)"], ["alterar", "Altera"]].map(([v, l]) => `<button type="button" data-compdec="${v}" class="${dec === v ? "on" : ""}">${l}</button>`).join("")}</div>
      ${k.sugestao ? `<div class="sug"><span class="sug-t">IA sugere:</span> <b>${k.sugestao === "ALTERAR" ? "alterar" : "manter"}</b>${k.sugMotivo ? " — " + esc(k.sugMotivo) : ""}</div>` : ""}
      <p class="note">${dec === "manter" ? "A conclusão e a conclusão simplificada do laudo pericial são repetidas como estão na folha (com as suas correções)." : dec === "alterar" ? 'Antes de gerar, ajuste a aba <button class="link" data-tab="avaliacao">Avaliação do perito</button>: a conclusão atualizada segue o que estiver marcado lá.' : "Gere primeiro para ver a análise e a sugestão da IA; depois decida e gere de novo."}</p></div>
    <div class="bar">${run ? `<button class="btn danger" data-act="stop">${I.stop} Parar</button>` : `<button class="btn primary ai-btn" data-act="compgerar">${I.play} ${k.at ? "Gerar de novo" : "Gerar laudo complementar"}</button>`}</div>
    <div class="stream ${run ? "" : "hidden"}" id="stream"><div class="stream-h" id="stream-h">${run ? esc(run.label || "") : ""}</div><div class="stream-b" id="stream-b">${run ? esc(run.text || "Pensando…") : ""}</div></div>
  </div>`;
}

/* ===================== PERÍCIA INDIRETA ===================== */
function indiretaHTML() {
  const x = S.cur.indireta || {};
  return `<div class="card indcard"><div class="cid-h"><h4>Perícia indireta (com informante)</h4>
    <div class="seg">${[["", "Não"], ["1", "Sim"]].map(([v, l]) => `<button type="button" data-indireta="${v}" class="${(x.sim ? "1" : "") === v ? "on" : ""}">${l}</button>`).join("")}</div></div>
    ${x.sim ? `<p class="note">O laudo informa no início que a perícia foi indireta, quem informou e por quê, e as respostas consideram essa limitação.</p>
    <div class="grid">
      <label class="f"><span class="lbl">Nome do(a) informante</span><input data-bind="indireta.nome" value="${esc(x.nome || "")}"></label>
      <label class="f"><span class="lbl">Parentesco / vínculo</span><input data-bind="indireta.parentesco" value="${esc(x.parentesco || "")}" placeholder="Ex.: filha"></label>
      <label class="f wide"><span class="lbl">Motivo do não comparecimento do(a) periciando(a)</span><div class="iw"><input data-bind="indireta.motivo" value="${esc(x.motivo || "")}" placeholder="Ex.: dependência de álcool, sem condições de comparecer"><button type="button" class="mic" data-mic="indireta.motivo" data-miclabel="Motivo do não comparecimento">${I.mic}</button></div></label>
    </div>` : ""}</div>`;
}
