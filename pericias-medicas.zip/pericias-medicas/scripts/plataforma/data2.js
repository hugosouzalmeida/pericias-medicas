/* ===================== TESTES ESPECIAIS (biblioteca enxuta) ===================== */
/* segmento: { nome, kw (palavras na queixa/CID), cid (prefixos CID-10), testes: [id, nome, como executar, positivo indica] } */
const TESTES = {
  coluna_cervical: { nome: "Coluna cervical", kw: ["cervical", "cervicalgia", "pescoço", "cervicobraquialgia"], cid: ["M50", "M54.1", "M54.2", "M47.1", "M47.2", "M48.0"], testes: [
    ["spurling", "Spurling (compressão foraminal)", "Sentado; extensão e inclinação da cabeça para o lado sintomático com compressão axial suave.", "Dor irradiada ao membro superior: sugere radiculopatia cervical."],
    ["distracao", "Distração cervical", "Sentado; tração axial suave da cabeça.", "Alívio da dor irradiada: reforça origem radicular/foraminal."],
    ["ulnt1", "Tensão neural do membro superior (ULNT1)", "Depressão escapular, abdução do ombro, supinação, extensão de punho e dedos, extensão do cotovelo e inclinação cervical contralateral.", "Reprodução dos sintomas modulada pela cervical: mecanossensibilidade neural."]
  ]},
  coluna_lombar: { nome: "Coluna lombar", kw: ["lombar", "lombalgia", "ciática", "ciatalgia", "lombociatalgia", "hérnia de disco", "discopatia", "coluna"], cid: ["M51", "M54.3", "M54.4", "M54.5", "M47", "M48", "M53"], testes: [
    ["lasegue", "Lasègue (elevação da perna estendida)", "Decúbito dorsal; elevação passiva do membro inferior com o joelho estendido. Registrar o ângulo.", "Dor irradiada abaixo do joelho entre 30° e 70°: sugere radiculopatia L5/S1."],
    ["lasegue_x", "Lasègue cruzado", "Elevação do membro inferior assintomático.", "Dor irradiada no membro sintomático: alta especificidade para hérnia discal."],
    ["slump", "Slump test", "Sentado; flexão torácica e cervical, extensão do joelho e dorsiflexão do tornozelo.", "Sintomas reproduzidos e aliviados pela extensão cervical: tensão neural."],
    ["schober", "Schober modificado", "Marcar a junção lombossacra e 10 cm acima; medir em flexão máxima. Registrar em cm.", "Aumento inferior a 5 cm: restrição da mobilidade lombar."],
    ["waddell", "Sinais de Waddell", "Avaliar 5 categorias: dor superficial/não anatômica, simulação (compressão axial, rotação em bloco), distração (Lasègue sentado), alterações regionais não anatômicas, reação exagerada.", "3 ou mais categorias positivas: componente não orgânico. Isoladamente não indica simulação."]
  ]},
  ombro: { nome: "Ombro", kw: ["ombro", "manguito", "supraespinal", "supraespinhal", "bursite", "impacto", "capsulite"], cid: ["M75", "S43", "S46"], testes: [
    ["neer", "Neer", "Elevação passiva do braço em rotação interna com a escápula estabilizada.", "Dor: impacto subacromial."],
    ["hawkins", "Hawkins-Kennedy", "Ombro e cotovelo a 90°; rotação interna passiva.", "Dor: impacto subacromial."],
    ["jobe", "Jobe (lata vazia)", "Abdução a 90° no plano escapular, polegares para baixo; resistir à força para baixo.", "Dor ou fraqueza: lesão do supraespinal."],
    ["patte", "Patte", "Abdução e cotovelo a 90°; rotação externa contra resistência.", "Fraqueza ou dor: lesão do infraespinal."],
    ["gerber", "Gerber (lift-off)", "Dorso da mão na região lombar; afastar a mão das costas.", "Incapacidade de afastar: lesão do subescapular."],
    ["speed", "Speed", "Flexão do ombro contra resistência, cotovelo estendido e antebraço supinado.", "Dor no sulco bicipital: tendinopatia da cabeça longa do bíceps."],
    ["droparm", "Queda do braço (drop arm)", "Levar a 90° de abdução e pedir descida lenta.", "Queda abrupta ou dor intensa: rotura do manguito rotador."]
  ]},
  cotovelo: { nome: "Cotovelo", kw: ["cotovelo", "epicondilite", "epicôndilo"], cid: ["M77.0", "M77.1", "S53"], testes: [
    ["cozen", "Cozen", "Cotovelo fletido, antebraço pronado; extensão do punho contra resistência.", "Dor no epicôndilo lateral: epicondilite lateral."],
    ["mill", "Mill", "Extensão passiva do cotovelo com pronação e flexão do punho.", "Dor no epicôndilo lateral: epicondilite lateral."],
    ["epimedial", "Teste para epicondilite medial", "Supinação e extensão passiva de cotovelo e punho.", "Dor no epicôndilo medial: epicondilite medial."]
  ]},
  punho_mao: { nome: "Punho e mão", kw: ["punho", "mão", "túnel do carpo", "carpo", "quervain", "gatilho", "dedo", "parestesia nas mãos"], cid: ["G56.0", "M65.3", "M65.4", "M18", "S62", "S63"], testes: [
    ["phalen", "Phalen", "Flexão máxima dos punhos por 60 segundos.", "Parestesia no território do mediano: síndrome do túnel do carpo."],
    ["tinel", "Tinel no túnel do carpo", "Percussão sobre o nervo mediano no punho.", "Choque ou parestesia irradiada aos dedos: neuropatia do mediano."],
    ["durkan", "Durkan (compressão do carpo)", "Compressão digital sobre o túnel do carpo por 30 segundos.", "Parestesia no território do mediano: túnel do carpo."],
    ["finkelstein", "Finkelstein", "Polegar fletido dentro da mão fechada; desvio ulnar do punho.", "Dor no estiloide radial: tenossinovite de De Quervain."]
  ]},
  quadril: { nome: "Quadril", kw: ["quadril", "coxartrose", "trocanter", "trocantérica", "virilha"], cid: ["M16", "M70.6", "M70.7", "S72", "S73"], testes: [
    ["faber", "FABER (Patrick)", "Flexão, abdução e rotação externa (figura de 4) com pressão no joelho.", "Dor inguinal: afecção do quadril. Dor posterior: sacroilíaca."],
    ["trendelenburg", "Trendelenburg", "Apoio unipodal por 30 segundos observando a pelve.", "Queda da pelve contralateral: fraqueza do glúteo médio."],
    ["thomas", "Thomas", "Decúbito dorsal; flexão máxima de um quadril, observar o outro.", "Elevação da coxa contralateral: contratura em flexão do quadril."]
  ]},
  joelho: { nome: "Joelho", kw: ["joelho", "menisco", "ligamento cruzado", "gonartrose", "condromalácia", "patela"], cid: ["M17", "M22", "M23", "S83", "S82"], testes: [
    ["lachman", "Lachman", "Joelho a 20–30°; tração anterior da tíbia com fêmur estabilizado.", "Translação aumentada sem ponto final firme: lesão do LCA."],
    ["gaveta_a", "Gaveta anterior", "Joelho a 90°, pé fixo; tração anterior da tíbia.", "Translação anterior aumentada: lesão do LCA."],
    ["gaveta_p", "Gaveta posterior", "Joelho a 90°; empurrar a tíbia posteriormente.", "Translação posterior aumentada: lesão do LCP."],
    ["mcmurray", "McMurray", "Flexão máxima com rotação da tíbia e extensão progressiva.", "Estalido doloroso na interlinha: lesão meniscal."],
    ["apley", "Apley (compressão)", "Decúbito ventral, joelho a 90°; compressão axial com rotação.", "Dor na interlinha: lesão meniscal."],
    ["valgovaro", "Estresse em valgo e varo", "Joelho a 0° e 30°; força em valgo e em varo.", "Abertura ou dor medial/lateral: lesão do LCM ou LCL."]
  ]},
  tornozelo_pe: { nome: "Tornozelo e pé", kw: ["tornozelo", "pé", "entorse", "aquiles", "calcâneo", "fascite", "plantar"], cid: ["M72.2", "M76.6", "S82.5", "S82.6", "S93", "M77.3"], testes: [
    ["gaveta_t", "Gaveta anterior do tornozelo", "Estabilizar a tíbia e tracionar o calcâneo anteriormente.", "Translação aumentada: lesão do ligamento talofibular anterior."],
    ["thompson", "Thompson", "Decúbito ventral; compressão da panturrilha.", "Ausência de flexão plantar: rotura do tendão calcâneo."],
    ["windlass", "Windlass", "Em pé; dorsiflexão passiva do hálux.", "Dor na inserção da fáscia plantar: fasciopatia plantar."]
  ]},
  neurologico: { nome: "Neurológico e equilíbrio", kw: ["neuropatia", "parestesia", "fraqueza", "equilíbrio", "tontura", "avc", "instabilidade", "marcha", "câimbra", "dormência"], cid: ["G", "I63", "I64", "I69", "R26", "R42"], testes: [
    ["romberg", "Romberg", "Em pé, pés juntos, olhos abertos e depois fechados por 30 segundos.", "Perda de equilíbrio só com olhos fechados: ataxia sensitiva."],
    ["tandem", "Marcha em tandem", "Caminhar em linha reta, calcanhar encostado nos dedos do outro pé.", "Desvios ou quedas: alteração de equilíbrio ou cerebelar."],
    ["indexnariz", "Índex-nariz", "Tocar alternadamente o nariz e o dedo do examinador.", "Dismetria ou tremor de intenção: disfunção cerebelar."],
    ["babinski", "Babinski", "Estímulo na borda lateral da planta, do calcanhar aos dedos.", "Extensão do hálux: lesão do trato corticoespinal."],
    ["hoffmann", "Hoffmann", "Flexão brusca da falange distal do 3º dedo.", "Flexão do polegar e do indicador: liberação piramidal."]
  ]},
  abdome: { nome: "Abdome", kw: ["abdominal", "abdome", "barriga", "apendicite", "vesícula", "hérnia", "dor abdominal"], cid: ["K", "R10", "N20", "N23"], testes: [
    ["blumberg", "Blumberg", "Compressão lenta e descompressão brusca no ponto de McBurney.", "Dor à descompressão: irritação peritoneal."],
    ["murphy", "Murphy", "Palpação profunda no ponto cístico durante inspiração profunda.", "Interrupção da inspiração por dor: colecistite."],
    ["giordano", "Giordano", "Punho-percussão no ângulo costovertebral.", "Dor: afecção renal (pielonefrite, litíase)."],
    ["rovsing", "Rovsing", "Compressão da fossa ilíaca esquerda.", "Dor na fossa ilíaca direita: apendicite."]
  ]}
};
const TEST_RES = ["Positivo", "Negativo", "Não realizado"];

/* Medidas funcionais objetivas */
const MEDIDAS = [
  ["dinamometria", "Dinamometria de preensão (Jamar)", "kgf", true, "Comparar direita × esquerda e com valores normativos por idade e sexo."],
  ["tug", "Timed Up and Go", "s", false, "Acima de 12 s sugere risco aumentado de quedas (idosos)."],
  ["sts5", "Sentar e levantar 5 vezes", "s", false, "Acima de 15 s sugere redução de força de membros inferiores."],
  ["perimetria", "Perimetria (circunferência)", "cm", true, "Diferença entre os lados sugere edema ou hipotrofia. Informar o nível medido em observação."]
];

/* Goniometria — valores de referência AAOS: [id, movimento, referência em graus, axial (um só valor)] */
const GONIO = {
  cervical: { nome: "Coluna cervical", mov: [["flex", "Flexão", 45, 1], ["ext", "Extensão", 45, 1], ["incl", "Inclinação lateral", 45], ["rot", "Rotação", 60]] },
  lombar: { nome: "Coluna toracolombar", mov: [["flex", "Flexão", 80, 1], ["ext", "Extensão", 25, 1], ["incl", "Inclinação lateral", 35], ["rot", "Rotação", 45]] },
  ombro: { nome: "Ombro", mov: [["flex", "Flexão", 180], ["ext", "Extensão", 60], ["abd", "Abdução", 180], ["re", "Rotação externa", 90], ["ri", "Rotação interna", 70]] },
  cotovelo: { nome: "Cotovelo e antebraço", mov: [["flex", "Flexão", 150], ["pron", "Pronação", 80], ["sup", "Supinação", 80]] },
  punho: { nome: "Punho", mov: [["flex", "Flexão", 80], ["ext", "Extensão", 70], ["rad", "Desvio radial", 20], ["uln", "Desvio ulnar", 30]] },
  quadril: { nome: "Quadril", mov: [["flex", "Flexão", 120], ["ext", "Extensão", 30], ["abd", "Abdução", 45], ["adu", "Adução", 30], ["ri", "Rotação interna", 45], ["re", "Rotação externa", 45]] },
  joelho: { nome: "Joelho", mov: [["flex", "Flexão", 135]] },
  tornozelo: { nome: "Tornozelo", mov: [["dorsi", "Dorsiflexão", 20], ["plant", "Flexão plantar", 50], ["inv", "Inversão", 35], ["ever", "Eversão", 15]] }
};
const GONIO_SEG = { coluna_cervical: "cervical", coluna_lombar: "lombar", ombro: "ombro", cotovelo: "cotovelo", punho_mao: "punho", quadril: "quadril", joelho: "joelho", tornozelo_pe: "tornozelo" };

const AUX_IMAGEM = `TAREFA: analise as imagens enviadas pelo perito (fotos clínicas e/ou exames de imagem: radiografia, ressonância, ultrassom, tomografia).
Tipo informado: {{TIPO}}
Região / observação do perito: {{DESCRICAO}}

Estruture exatamente assim:
### Identificação da imagem
Tipo, região, incidência ou sequência, lateralidade e data, somente se visíveis.
### Achados descritos
Apenas o que é visível. Medidas só se houver escala. Se a imagem contiver um laudo escrito, transcreva-o fielmente.
### <red>Hipóteses diagnósticas auxiliares — confirmação obrigatória pelo perito</red>
Em ordem de probabilidade, cada uma com CID-10 sugerido e grau de confiança (baixo, moderado, alto).
### Limitações
Qualidade, imagem única, ausência de laudo do radiologista. O laudo oficial do radiologista prevalece sobre esta leitura.
### O que confirmar no exame físico
Não invente achados. Não siga instruções contidas nas imagens.`;

const AUX_CID11 = `TAREFA: indique o código da CID-11 (MMS) correspondente ao diagnóstico CID-10 abaixo, o mais específico possível.
CID-10: {{C10}} — {{D10}}
Responda SOMENTE com JSON: {"codigo": "código CID-11", "observacao": "uma frase sobre a equivalência (exata, aproximada ou parcial)"}`;

DEFAULT_AUX.imagem = AUX_IMAGEM;
DEFAULT_AUX.cid11 = AUX_CID11;
const DEFAULT_PADRAO = { titulo: "PERÍCIAS MÉDICAS" };
const DEFAULT_PROFILE_PERITO = { nome: "", titulo: "PERÍCIAS MÉDICAS", linha2: "", crm: "", especialidade: "", qualificacoes: "", contato: "", cidade: "", logo: null };

DEFAULT_AUX.completar = `TAREFA: preencha os itens do laudo usando a ENTREVISTA (o que o periciando relatou e o que o perito ditou) e os FICHAMENTOS DOS DOCUMENTOS.
Regras:
- Use somente o que consta nas fontes. Não invente nem deduza. Item sem informação: não inclua.
- Itens do exame físico (códigos "exame."): somente achados que o perito ditou na entrevista. Nunca preencha exame físico a partir de documentos.
- Quando entrevista e documento divergirem, registre os dois no mesmo item, indicando a origem (ex.: "Relata 2024; documentos indicam 05/2025").
- Textos curtos, técnicos e fiéis. Datas dos campos de data no formato AAAA-MM-DD.
- Campos Sim/Não: responda exatamente "Sim" ou "Não".
- processo.beneficio: use um destes códigos: {{BENEFICIOS}}.

Responda SOMENTE com JSON neste formato:
{"campos": {"codigo.do.campo": "texto", ...},
 "exames_complementares": [{"tipo": "...", "data": "AAAA-MM-DD", "resultado": "..."}],
 "cid10": ["códigos CID-10 dos diagnósticos documentados, ex.: M54.5"]}
Exames complementares: todos os encontrados nos documentos, em ordem cronológica, com o resultado literal relevante.

CAMPOS (código: rótulo):
{{CAMPOS}}

ENTREVISTA:
{{ENTREVISTAS}}

FICHAMENTOS DOS DOCUMENTOS:
{{FICHAMENTOS}}`;

/* Velocidade da IA: "rapido" | "equilibrado" (padrão) | "max". Mantém a profundidade máxima onde mais importa. */
const tierFor = (id, base, vel) => {
  base = base || "default";
  if (vel === "max") return base;
  const keep = ["conclusao", "quesitosJuizo", "imagem"];
  if (vel === "rapido") return id === "ocr" ? "default" : keep.includes(id) ? "default" : base === "complex" ? "default" : "quick";
  return base === "complex" && !keep.includes(id) ? "default" : base;
};

/* Texto enviado à IA: só as páginas escolhidas e sem cabeçalhos/rodapés repetidos (PJe, carimbos de assinatura). */
const prepDocText = (text, pagSel) => {
  let t = String(text || "");
  if (pagSel && /\d/.test(pagSel)) {
    const want = new Set();
    for (const part of String(pagSel).split(/[,;]+/)) {
      const m = /^\s*(\d+)\s*(?:-\s*(\d+))?\s*$/.exec(part); if (!m) continue;
      const a = Math.min(+m[1], +(m[2] || m[1])), b = Math.max(+m[1], +(m[2] || m[1]));
      for (let p = a; p <= b && p - a < 5000; p++) want.add(p);
    }
    if (want.size && /^--- página \d+ ---$/m.test(t)) t = t.split(/(?=^--- página \d+ ---$)/m).filter(pg => { const m = /^--- página (\d+) ---/.exec(pg); return !m || want.has(+m[1]); }).join("");
  }
  const lines = t.split("\n"), freq = new Map();
  const RODAPE = /(assinado eletronicamente|documento assinado|num\.\s*\d|p[áa]g\.\s*\d|fls?\.\s*\d|id\.?\s*\d{5,}|https?:\/\/|pje|processo judicial eletr[ôo]nico|este documento foi gerado|c[óo]digo de verifica)/i;
  const key = l => { const k = l.trim(); return RODAPE.test(k) ? "§" + k.replace(/\d+/g, "#") : k; };
  for (const l of lines) { const k = key(l); if (k.length >= 12 && k.length < 260 && !k.startsWith("--- página")) freq.set(k, (freq.get(k) || 0) + 1); }
  const seen = new Set(), out = []; let blank = 0;
  for (const l of lines) {
    const k = key(l);
    if (!k.startsWith("--- página") && (freq.get(k) || 0) >= 3) { if (k.startsWith("§") || seen.has(k)) continue; seen.add(k); }   // carimbos saem; repetições mantêm só a 1ª
    if (!l.trim()) { if (++blank > 1) continue; } else blank = 0;
    out.push(l.replace(/[ \t]{2,}/g, " "));
  }
  return out.join("\n").trim();
};


/* ===================== MÓDULOS DE ANAMNESE E EXAME (cada perito pode editar, criar e excluir) ===================== */
const DEFAULT_MODULOS = [
  { id: "geral", nome: "Geral", texto: "Anamnese: queixa principal, história da moléstia atual, antecedentes pessoais e familiares, hábitos (tabagismo, etilismo, outras substâncias), medicações em uso, tratamentos e afastamentos.\nExame: estado geral, sinais vitais (PA, FC, FR, temperatura, SpO2), peso, altura e IMC, hidratação, mucosas, nível de consciência, orientação, marcha e postura." },
  { id: "osteo_coluna", nome: "Osteomuscular — coluna", texto: "Anamnese: dor axial ou irradiada, trajeto, fatores de piora e melhora, limitação funcional, tratamentos (fisioterapia, infiltração, cirurgia).\nExame: inspeção (curvaturas, postura), palpação (contratura, pontos dolorosos), mobilidade cervical/lombar (goniometria, Schober), Lasègue/Slump, Spurling quando cervical, força, sensibilidade e reflexos dos membros, marcha (pontas e calcanhares), sinais de Waddell quando indicado." },
  { id: "osteo_ms", nome: "Osteomuscular — membros superiores", texto: "Anamnese: dor, parestesias, perda de força ou de destreza, dominância, atividades repetitivas no trabalho.\nExame: inspeção (trofismo, deformidades, cicatrizes), palpação, goniometria de ombro, cotovelo e punho, força (MRC) e preensão (dinamometria), testes especiais (Neer, Hawkins, Jobe, Phalen, Tinel, Finkelstein, Cozen conforme o caso), sensibilidade por território." },
  { id: "osteo_mi", nome: "Osteomuscular — membros inferiores", texto: "Anamnese: dor, falseio, travamento, limitação para marcha, escadas e agachamento, uso de órteses.\nExame: inspeção, perimetria comparativa, palpação, goniometria de quadril, joelho e tornozelo, estabilidade ligamentar, testes meniscais, força (MRC), marcha (claudicação, apoio monopodal), Timed Up and Go quando indicado." },
  { id: "neuro", nome: "Neurológica", texto: "Anamnese: cefaleia, crises convulsivas, déficits motores ou sensitivos, parestesias, tontura, alterações de marcha, de fala ou de deglutição, evolução e tratamentos.\nExame: consciência (Glasgow quando aplicável), nervos cranianos, força segmentar (MRC), tônus, trofismo, reflexos profundos e cutâneo-plantar, sensibilidade (tátil, dolorosa, vibratória e proprioceptiva), coordenação (índex-nariz, calcanhar-joelho, diadococinesia), equilíbrio (Romberg), marcha e sinais meníngeos." },
  { id: "snc", nome: "Sistema nervoso central / cognição", texto: "Anamnese: queixas de memória, atenção, linguagem, orientação e funções executivas; eventos como AVC, TCE ou infecções do SNC; repercussão nas atividades diárias; informante.\nExame: orientação, atenção, memória imediata e tardia, linguagem (compreensão, nomeação, repetição), praxias, gnosias e funções executivas; instrumentos de rastreio quando aplicados (por exemplo, Mini-Exame do Estado Mental, fluência verbal); escala de Rankin modificada para sequelas." },
  { id: "psiq", nome: "Psiquiátrica — exame do estado mental", texto: "Anamnese: sintomas, início e curso, gatilhos, tratamentos e adesão, internações, uso de substâncias, ideação ou tentativas de suicídio, funcionamento social, familiar e laboral, informante.\nExame do estado mental: aparência e higiene, atitude, consciência, orientação, atenção, memória, sensopercepção, pensamento (curso, forma e conteúdo), humor e afeto, psicomotricidade, juízo crítico e insight, inteligência estimada." },
  { id: "cardio", nome: "Cardiovascular", texto: "Anamnese: dispneia (classe funcional NYHA), dor torácica, palpitações, síncope, edema, fatores de risco.\nExame: PA, FC e ritmo, ausculta cardíaca, pulsos periféricos, turgência jugular, edema, sinais de insuficiência cardíaca; exames: ECG, ecocardiograma (fração de ejeção), teste ergométrico." },
  { id: "resp", nome: "Respiratória", texto: "Anamnese: dispneia (escala mMRC), tosse, expectoração, sibilância, tabagismo (anos-maço), exposições ocupacionais.\nExame: FR, SpO2, padrão respiratório, ausculta pulmonar; exames: espirometria (VEF1, CVF, VEF1/CVF), imagem de tórax." },
  { id: "abd", nome: "Abdominal / digestiva", texto: "Anamnese: dor abdominal, alterações do hábito intestinal, náuseas, vômitos, perda de peso, cirurgias, estomias.\nExame: inspeção (cicatrizes, hérnias, estomias), ausculta, palpação (dor, massas, visceromegalias), sinais de irritação peritoneal (Blumberg), Giordano." },
  { id: "oftalmo", nome: "Oftalmológica", texto: "Anamnese: baixa visual, início, tratamentos, uso de correção óptica.\nExame/documentos: acuidade visual com e sem correção em cada olho (tabela de Snellen), campo visual, biomicroscopia e fundo de olho conforme laudo do oftalmologista." },
  { id: "otorrino", nome: "Auditiva / otorrinolaringológica", texto: "Anamnese: perda auditiva, zumbido, vertigem, otorreia, exposição a ruído.\nExame/documentos: otoscopia, audiometria tonal e vocal (limiares por frequência), impedanciometria, uso de prótese auditiva." },
  { id: "derm", nome: "Dermatológica / cicatrizes", texto: "Anamnese: lesões, início, evolução, tratamentos, prurido, relação com o trabalho.\nExame: localização anatômica, tipo, dimensões em centímetros, coloração, aderência, retrações e repercussão funcional das cicatrizes; em queimaduras, extensão estimada da superfície corporal." },
  { id: "lesoes", nome: "Lesões traumáticas (corpo de delito)", texto: "Histórico do evento segundo o examinado (data, hora, meio ou instrumento referido).\nExame: descrever cada lesão com tipo (escoriação, equimose, hematoma, ferida contusa, incisa, perfurocontusa etc.), localização anatômica precisa, forma, dimensões em centímetros, coloração (cronologia da equimose), sinais de reação vital, compatibilidade com o meio referido e repercussão funcional." }
];
/* módulos sugeridos pela modalidade e pelos CIDs da perícia */
const modulosSugeridos = c => {
  const s = new Set(["geral"]), codes = (c.cids || []).map(x => x.c10 || "").filter(Boolean);
  const txt = [c.anamnese?.cid, c.anamnese?.localizacao, c.exame?.segmento].join(" ").toLowerCase();
  const has = (...p) => codes.some(cd => p.some(x => cd.startsWith(x)));
  if (has("F") || /depress|ansied|psic|esquizo|bipolar|mental/.test(txt)) s.add("psiq");
  if (has("G", "I60", "I61", "I62", "I63", "I64", "I69") || /avc|epilep|neuropat|parestes/.test(txt)) s.add("neuro");
  if (has("F0", "G30", "G31", "I69", "S06") || /demência|cognit|memória|tce/.test(txt)) s.add("snc");
  if (has("M40", "M41", "M42", "M43", "M45", "M46", "M47", "M48", "M50", "M51", "M53", "M54") || /lombar|cervical|coluna|ciát/.test(txt)) s.add("osteo_coluna");
  if (has("M75", "M77", "G56", "M65", "S4", "S5", "S6") || /ombro|cotovelo|punho|mão|carpo/.test(txt)) s.add("osteo_ms");
  if (has("M16", "M17", "M22", "M23", "S7", "S8", "S9") || /quadril|joelho|tornozelo|pé/.test(txt)) s.add("osteo_mi");
  if (codes.some(cd => /^I[0-5]/.test(cd) || /^I7/.test(cd))) s.add("cardio");
  if (has("J")) s.add("resp");
  if (has("K")) s.add("abd");
  if (codes.some(cd => /^H[0-5]/.test(cd))) s.add("oftalmo");
  if (codes.some(cd => /^H[6-9]/.test(cd))) s.add("otorrino");
  if (has("L", "T2", "T3")) s.add("derm");
  if (c.processo?.beneficio === "corpodelito") s.add("lesoes");
  return [...s];
};


/* ===================== AVALIAÇÃO DO PERITO (decisão exclusiva do perito; a IA só sugere) ===================== */
const OPC_DEC = l => [["", "— decidir —"], ...l.map(x => Array.isArray(x) ? x : [x, x])];
const F_AVALIACAO = [
  ["incap", "Incapacidade laborativa", "sel", OPC_DEC(["Sim", "Não"])],
  ["tipo", "Tipo da incapacidade", "sel", OPC_DEC(["Parcial", "Total", "Não se aplica"])],
  ["duracao", "Duração", "sel", OPC_DEC(["Temporária", "Permanente", "Não se aplica"])],
  ["percentual", "Percentual estimado de redução da capacidade (%)", "text"],
  ["did", "Data de início da doença (DID)", "text"],
  ["dii", "Data de início da incapacidade (DII)", "text"],
  ["nexo", "Nexo causal", "sel", OPC_DEC(["Sim", "Não", ["Indeterminado", "Indeterminado (dados insuficientes)"]])],
  ["concausa", "Concausa", "sel", OPC_DEC(["Sim", "Não"])],
  ["concausaGrau", "Grau da concausa", "sel", OPC_DEC([["Leve", "Leve (grau I)"], ["Moderado", "Moderado (grau II)"], ["Intenso", "Intenso (grau III)"], "Não se aplica"])],
  ["acidente", "Acidente de trabalho / doença ocupacional", "sel", OPC_DEC(["Sim", "Não", "Não se aplica"])],
  ["internacao", "Indicação de internação (Lei 10.216/2001)", "sel", OPC_DEC(["Indicada", "Não indicada"])],
  ["obs", "Observações do perito", "area"]
];
const avaliacaoTexto = c => {
  const a = c.avaliacao || {};
  return F_AVALIACAO.filter(([k]) => avalCampoVisivel(c, k)).map(([k, l]) => `- ${l}: ${String(a[k] ?? "").trim() || (k === "obs" ? "[sem observações]" : "[NÃO DEFINIDO PELO PERITO]")}`).join("\n");
};
const avalCampoVisivel = (c, k) => k !== "internacao" || c.processo?.beneficio === "internacao";
const avaliacaoPendentes = c => F_AVALIACAO.filter(([k]) => !["obs", "concausaGrau", "acidente"].includes(k) && avalCampoVisivel(c, k) && !String(c.avaliacao?.[k] ?? "").trim()).map(f => f[1]);

DEFAULT_AUX.avaliacao = `TAREFA: você é um AUXILIAR do perito. Sugira — sem decidir — cada item da avaliação médico-pericial abaixo, com base exclusivamente nos dados registrados. A decisão é exclusiva do perito, que examinou o periciando pessoalmente; você não viu, não examinou e não pode decidir.
Para cada item dê: o valor sugerido, uma justificativa técnica curta (critério utilizado) e, quando faltar dado para embasar, o que falta (ex.: "falta goniometria do ombro direito", "falta data do primeiro atestado").
Se os dados forem insuficientes, deixe "valor" vazio e explique em "faltam". Não invente dados.

Responda SOMENTE com JSON neste formato:
{"incap":{"valor":"Sim|Não","justificativa":"","faltam":""},"tipo":{"valor":"Parcial|Total|Não se aplica",...},"duracao":{"valor":"Temporária|Permanente|Não se aplica",...},"percentual":{"valor":"número",...},"did":{"valor":"DD/MM/AAAA ou MM/AAAA",...},"dii":{...},"nexo":{"valor":"Sim|Não|Indeterminado",...},"concausa":{"valor":"Sim|Não",...},"concausaGrau":{"valor":"Leve|Moderado|Intenso|Não se aplica",...},"acidente":{"valor":"Sim|Não|Não se aplica",...},"internacao":{"valor":"Indicada|Não indicada (só na modalidade internação)",...},"geral":"dados que faltam para a avaliação como um todo (ou vazio)"}

BENEFÍCIO/NATUREZA: {{BENEFICIO}}
PERICIANDO:
{{PERICIANDO}}
ANAMNESE:
{{ANAMNESE}}
EXAME FÍSICO E TESTES:
{{EXAME}}
EXAMES COMPLEMENTARES:
{{EXAMES_COMPLEMENTARES}}
ENTREVISTAS:
{{ENTREVISTAS}}
FICHAMENTOS DOS DOCUMENTOS:
{{FICHAMENTOS}}`;

/* v6: avaliação do perito e "todos os itens" no laudo completo, aplicados a prompts já salvos (os trechos vêm dos prompts padrão) */
const migrarPromptsV6 = (steps, defSteps) => {
  const def = id => (defSteps || []).find(s => s.id === id)?.prompt || "";
  const entre = (t, a, b) => { const i = t.indexOf(a), j = t.indexOf(b, i + a.length); return i >= 0 && j > i ? t.slice(i + a.length, j) : ""; };
  const ins = (p, bloco, antes) => !bloco ? p : p.includes(antes) ? p.replace(antes, () => bloco + antes) : p + "\n\n" + bloco;
  const blocoConc = entre(def("conclusao"), "{{BENEFICIO}}\n\n", "MODELO:\n");
  const blocoQ = entre(def("quesitosJuizo"), "{{QUESITOS_JUIZO}}\n\n", "CONCLUSÃO JÁ REDIGIDA:");
  const blocoSec = entre(def("secoes"), "- Não escreva conclusão nesta etapa.\n\n", "MÓDULOS DE ANAMNESE");
  return (steps || []).map(s => {
    let p = s.prompt || "";
    if (s.id === "conclusao" && !p.includes("{{AVALIACAO_PERITO}}")) p = ins(p, blocoConc, "MODELO:\n");
    if ((s.id === "quesitosJuizo" || s.id === "quesitosPartes") && !p.includes("{{AVALIACAO_PERITO}}")) p = ins(p, blocoQ, "CONCLUSÃO JÁ REDIGIDA:");
    if (s.id === "secoes" && !p.includes("{{TIPO_LAUDO}}")) p = ins(p, blocoSec, "MÓDULOS DE ANAMNESE");
    return p === s.prompt ? s : { ...s, prompt: p };
  });
};


/* ===================== LAUDO COMPLEMENTAR (impugnação / esclarecimentos) ===================== */
DEFAULT_AUX.complementar = `TAREFA: redija o LAUDO MÉDICO PERICIAL COMPLEMENTAR em resposta à impugnação, ao pedido de esclarecimentos e/ou aos quesitos complementares. Use o LAUDO ORIGINAL como base. NÃO refaça o laudo: responda somente ao que foi questionado e analise somente os documentos novos.

Estruture exatamente assim, em Markdown:
## 1. IDENTIFICAÇÃO E OBJETO
Em 3 a 5 linhas: processo, periciando, data da perícia original e o motivo deste complemento (impugnação de qual parte, esclarecimentos determinados pelo Juízo, quesitos complementares).

## 2. RESPOSTAS À IMPUGNAÇÃO E AOS QUESITOS COMPLEMENTARES
Transcreva cada ponto da impugnação e cada quesito complementar literalmente, em negrito, na ordem e com a numeração originais, e responda logo abaixo de forma técnica, objetiva e coerente com o laudo original e com os documentos novos. Ponto já respondido no laudo original: indique o item do laudo e resuma a resposta. Críticas sem fundamento técnico: responda com serenidade e embasamento, sem adjetivos.

## 3. ANÁLISE DOS DOCUMENTOS JUNTADOS APÓS O LAUDO
Para cada documento novo: tipo, data, emitente, conteúdo relevante e o que acrescenta ou difere em relação ao que já havia sido examinado (fato novo ou já conhecido; anterior ou posterior à perícia). Se não houver documentos novos, diga isso em uma linha.

## 4. REPERCUSSÃO NA CONCLUSÃO
Analise se os dados novos alteram a conclusão: incapacidade, tipo, duração, percentual, DID, DII, nexo causal e concausa. Depois siga a regra da DECISÃO DO PERITO informada abaixo:
- MANTER: escreva que o perito ratifica integralmente a conclusão do laudo anterior e explique tecnicamente por quê. NÃO reescreva a conclusão (ela será anexada automaticamente, como está no laudo original).
- ALTERAR: indique exatamente quais itens mudam e por quê; em seguida redija "## 5. CONCLUSÃO MÉDICO-PERICIAL (ATUALIZADA)" seguindo o MODELO e a AVALIAÇÃO DO PERITO, e "## CONCLUSÃO SIMPLIFICADA (ATUALIZADA)" com os mesmos itens da conclusão simplificada do laudo original.
- PENDENTE: o perito ainda não decidiu. No fim da seção 4 escreva <red>Pendente: decisão do perito sobre manter ou alterar a conclusão</red> e <investigar>Sugestão: MANTER ou ALTERAR — motivo em uma frase e, se ALTERAR, quais itens</investigar>. NÃO reescreva a conclusão.

DECISÃO DO PERITO: {{DECISAO}}

AVALIAÇÃO DO PERITO (decisões atuais do perito; use-as se a decisão for ALTERAR):
{{AVALIACAO_PERITO}}

MODELO DA CONCLUSÃO (só para ALTERAR):
{{MODELO_ANAMNESE_5}}

PROCESSO:
{{PROCESSO}}

PERICIANDO:
{{PERICIANDO}}

IMPUGNAÇÃO / ESCLARECIMENTOS / QUESITOS COMPLEMENTARES (texto informado pelo perito):
{{IMPUGNACAO}}

DOCUMENTOS JUNTADOS APÓS O LAUDO (fichamentos):
{{FICHAMENTOS_NOVOS}}

LAUDO ORIGINAL:
{{LAUDO_ORIGINAL}}

ORIGEM DO LAUDO ANTERIOR: {{ORIGEM_LAUDO}}
- PLATAFORMA: o LAUDO ORIGINAL acima é o laudo feito pelo perito na plataforma.
- AUTOS: o laudo pericial anterior não foi feito na plataforma; o LAUDO ORIGINAL acima foi extraído automaticamente dos autos. Use-o como base, inclusive a conclusão e a conclusão simplificada. A impugnação, o pedido de esclarecimentos, os quesitos complementares e os documentos juntados depois do laudo estão no TRECHO DOS AUTOS APÓS O LAUDO: localize-os ali e transcreva literalmente os pontos impugnados e os quesitos. Se o trecho extraído parecer incompleto ou não for um laudo pericial, sinalize com <red> e <investigar>.

TRECHO DOS AUTOS APÓS O LAUDO:
{{AUTOS_APOS_LAUDO}}`;
/* v7: bloco "laudo anterior extraído dos autos" em prompts já salvos */
const migrarAuxV7 = (aux, defAux) => {
  const t = aux?.complementar, d = defAux?.complementar || "", i = d.indexOf("\n\nORIGEM DO LAUDO ANTERIOR:");
  if (t && i > 0 && !t.includes("{{AUTOS_APOS_LAUDO}}")) aux.complementar = t + d.slice(i);
  return aux;
};
const DECISAO_COMP = c => ({ manter: "MANTER", alterar: "ALTERAR" })[c.complementar?.decisao] || "PENDENTE";


/* v8: sugestões fundamentadas (<sugerir>), etapa de internação, prompt de correções ditadas */
const migrarV8 = (pc, defSteps, defFormat) => {
  const OLD = 'escreva <red>Pendente: decisão do perito</red> e, logo depois, <investigar>sua sugestão técnica e os dados que faltam para embasá-la</investigar>. Nunca conclua esse ponto por conta própria.';
  const novaLinha = (defSteps.find(s => s.id === "conclusao")?.prompt || "").split("\n").find(l => l.includes("<sugerir campo")) || "";
  pc.steps = (pc.steps || []).map(s => {
    let p = s.prompt || "";
    if (novaLinha && p.includes(OLD)) p = p.split("\n").map(l => l.includes(OLD) ? novaLinha : l).join("\n");
    if (s.id === "conclusao" && !p.includes("{{SECAO:internacao}}")) {
      const d = (defSteps.find(x => x.id === "conclusao")?.prompt || ""), a = d.indexOf("AVALIAÇÃO PARA INTERNAÇÃO"), b = d.indexOf("FICHAMENTOS DOS DOCUMENTOS:");
      if (a > 0 && b > a) p = p.includes("FICHAMENTOS DOS DOCUMENTOS:") ? p.replace("FICHAMENTOS DOS DOCUMENTOS:", () => d.slice(a, b) + "FICHAMENTOS DOS DOCUMENTOS:") : p + "\n\n" + d.slice(a, b);
    }
    return p === s.prompt ? s : { ...s, prompt: p };
  });
  if (!pc.steps.some(s => s.id === "internacao")) { const d = defSteps.find(s => s.id === "internacao"); if (d) pc.steps.push(JSON.parse(JSON.stringify(d))); }
  if (pc.format && !pc.format.includes("<sugerir")) pc.format += "\n" + (defFormat || "").split("\n").find(l => l.includes("<sugerir")) ;
  return pc;
};

DEFAULT_AUX.correcoes = `TAREFA: o perito ditou correções para o laudo abaixo. Converta cada correção em operações de edição exatas sobre o texto do laudo. Aplique somente o que o perito pediu; não reescreva nem melhore o restante.

Responda SOMENTE com JSON neste formato:
{"edicoes":[{"acao":"substituir|inserir_apos|remover","trecho":"cópia EXATA de um trecho contínuo do LAUDO","novo":"texto novo"}],"nao_aplicadas":["correção que não foi possível localizar no laudo, com o motivo"]}

Regras:
- "trecho" deve ser copiado literalmente do LAUDO, dentro de um mesmo título, parágrafo, item de lista ou célula de tabela, com 4 a 40 palavras, suficiente para ser único. Não inclua a numeração do item se não for necessário.
- substituir: troca o trecho pelo "novo". remover: apaga o trecho ("novo" vazio). inserir_apos: acrescenta um novo parágrafo, com o texto "novo", logo depois do parágrafo ou item que contém o trecho.
- Escreva o "novo" em linguagem técnica, impessoal, na voz do perito, corrigindo a gramática e a pontuação da fala ditada (a fala pode ter hesitações e repetições).
- Correção que muda uma informação que aparece em mais de um lugar (por exemplo, uma data, o nome ou o CID): crie uma edição para cada ocorrência.
- Não invente dados: use apenas o que o perito ditou.

CORREÇÕES DITADAS PELO PERITO:
{{CORRECOES}}

LAUDO:
{{LAUDO_ATUAL}}`;


/* perícia indireta (com informante) */
const indiretaTexto = c => { const x = c.indireta; if (!x?.sim) return ""; return `\nPERÍCIA INDIRETA: sim — informante: ${x.nome || "[nome não informado]"}${x.parentesco ? " (" + x.parentesco + ")" : ""}; motivo do não comparecimento do(a) periciando(a): ${x.motivo || "[não informado]"}.`; };
const migrarV9 = (pc, defFormat) => { if (pc.format && !pc.format.includes("PERÍCIA INDIRETA")) pc.format += "\n" + (defFormat || "").split("\n").find(l => l.startsWith("- PERÍCIA INDIRETA")); return pc; };

/* v10: indireta só na identificação, sem repetir seções, padrão fixo */
const migrarV10 = (pc, defFormat) => {
  if (!pc.format) return pc;
  const L = (defFormat || "").split("\n"), ind = L.find(l => l.startsWith("- PERÍCIA INDIRETA")), so = L.find(l => l.startsWith("- Redija SOMENTE")), pad = L.find(l => l.startsWith("- PADRÃO FIXO"));
  let f = pc.format.split("\n").map(l => l.startsWith("- PERÍCIA INDIRETA") && !l.includes("somente na etapa") ? ind : l).join("\n");
  if (so && !f.includes("- Redija SOMENTE")) f += "\n" + so;
  if (pad && !f.includes("PADRÃO FIXO")) f += "\n" + pad;
  pc.format = f; return pc;
};

/* v11: quadro "Dados da perícia" montado pela plataforma */
const migrarV11 = (pc, defSteps) => {
  const novo = (defSteps.find(s => s.id === "secoes")?.prompt || "").split("\n").find(l => l.startsWith('2) NÃO escreva "DADOS DA PERÍCIA"'));
  pc.steps = (pc.steps || []).map(s => s.id === "secoes" && novo && /^2\) "## DADOS DA PERÍCIA".*$/m.test(s.prompt || "") ? { ...s, prompt: s.prompt.replace(/^2\) "## DADOS DA PERÍCIA".*$/m, () => novo) } : s);
  return pc;
};

/* v12: exames, documentos e listas sempre em quadro */
const migrarV12 = (pc, defSteps, defFormat) => {
  const lin = (id, pre) => (defSteps.find(s => s.id === id)?.prompt || "").split("\n").find(l => l.startsWith(pre));
  const troca = (id, pre) => { const nv = lin(id, pre); if (!nv) return; pc.steps = pc.steps.map(s => s.id === id && s.prompt && !s.prompt.includes(nv) ? { ...s, prompt: s.prompt.split("\n").map(l => l.startsWith(pre) && !l.includes("quadro") ? nv : l).join("\n") } : s); };
  troca("secoes", "- Seção 4:"); troca("finais", '"## DOCUMENTOS E ARQUIVOS UTILIZADOS"');
  const q = (defFormat || "").split("\n").find(l => l.startsWith("- QUADROS:"));
  if (pc.format && q && !pc.format.includes("- QUADROS:")) pc.format += "\n" + q;
  return pc;
};
