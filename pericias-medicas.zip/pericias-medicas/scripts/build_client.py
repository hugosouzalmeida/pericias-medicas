"""Gera public/index.html e public/login.html a partir do código da plataforma (scripts/plataforma/).
Só é preciso rodar ao alterar as telas:  python3 scripts/build_client.py"""
import base64, sys, os, shutil
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE)
SRC = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, 'plataforma')
ASSETS = sys.argv[2] if len(sys.argv) > 2 else os.path.join(HERE, 'plataforma')

def R(s, old, new, cnt=1):
    assert s.count(old) == cnt, (old[:90], s.count(old)); return s.replace(old, new)

a1 = open(f'{SRC}/app1.js').read(); a2 = open(f'{SRC}/app2.js').read(); a3 = open(f'{SRC}/app3.js').read()

# ---------- app1: fila de gravação, mensagens ----------
a1 = R(a1, '  if (ix && Array.isArray(ix.cases)) S.index = ix;\n', '  if (ix && Array.isArray(ix.cases)) S.index = ix;\n  if (!S.profile.nome && ME.user?.nome) S.profile.nome = ME.user.nome;\n')
a1 = R(a1, '  ref(k) {', '  async flush() { if (S.cur) await saveCaseNow(); await Promise.all(Object.values(this.running)); },\n  ref(k) {')
a1 = R(a1, '  cancelled: "Execução interrompida."', '  cancelled: "Execução interrompida.", not_configured: "A IA ainda não foi configurada pelo administrador (chave de API).", bad_key: "A chave de API foi recusada pelo provedor. Avise o administrador.", bad_request: "O provedor recusou a solicitação. Verifique o nome do modelo na área do administrador.", unauthenticated: "Sua sessão expirou. Entre novamente."')
a1 = R(a1, 'const aiMsg = e => AI_ERR[e?.code] || "Falha na comunicação com o Claude. Tente novamente.";', 'const aiMsg = e => AI_ERR[e?.code] || (e?.message ? "Falha na IA: " + e.message : "Falha na comunicação com a IA. Tente novamente.");')
a1 = R(a1, 'toast("Os recursos de IA funcionam quando a página é aberta no Claude (claude.ai ou app).", "err")', 'toast(S.admin ? "Configure a chave de API em “IA e chaves de API”." : "A IA ainda não foi configurada pelo administrador.", "err")')

# ---------- app2: navegação, perfil, textos ----------
a2 = R(a2, 'O ditado por voz funciona no Chrome ou no app do Claude para computador.', 'O ditado por voz funciona no Google Chrome e no Microsoft Edge.')
a2 = R(a2, '''  const admin = [["admin", "Painel do administrador"], ["prompts", "Prompts"], ["quesitos", "Modelos de quesitos"]];''', '''  const admin = [["admin", "Painel do administrador"], ["usuarios", "Usuários"], ["ia", "IA e chaves de API"], ["webhooks", "Webhooks"], ["uso", "Uso da IA"], ["prompts", "Prompts"], ["quesitos", "Modelos de quesitos"]];''')
a2 = R(a2, '''  $("#role").innerHTML = S.admin ? '<span class="role admin">Administrador</span>' : '<span class="role">Perito</span>';''',
       '''  $("#role").innerHTML = `<div class="userbox"><b>${esc(ME.user.nome || ME.user.email)}</b><small>${esc(ME.user.email)}</small></div>` + (S.admin ? '<span class="role admin">Administrador</span>' : '<span class="role">Perito</span>') + ' <button class="link" data-adm="logout">Sair</button>';''')
a2 = R(a2, '''${footerHTML()}</div></div></div>${sigCardHTML()}`;''', '''${footerHTML()}</div></div></div>${sigCardHTML()}${senhaCard()}`;''')
a2 = R(a2, 'As perícias ficam na área privada de cada perito: nem o administrador as lê.', 'Cada perito só acessa as próprias perícias; nem o administrador as vê pelas telas da plataforma. Os dados ficam no servidor da plataforma: quem administra o servidor é responsável por protegê-lo (LGPD).')

# ---------- app3: rotas, IA pelo servidor ----------
a3 = R(a3, 'if (!S.admin && ["prompts", "quesitos", "admin"].includes(h))', 'if (!S.admin && ADMIN_PAGES.includes(h))')
a3 = R(a3, '  else if (h === "ajuda") m.innerHTML = renderAjuda();', '  else if (h === "ajuda") m.innerHTML = renderAjuda();\n  else if (["usuarios", "ia", "webhooks", "uso"].includes(h)) { renderAdminPage(h); return; }')
a3 = R(a3, '''S.prompts = { rules: DEFAULT_RULES, format: DEFAULT_FORMAT, steps: clone(DEFAULT_STEPS), aux: clone(DEFAULT_AUX), modelos: { completo: MODELO_ANAMNESE_1_4, simplificado: MODELO_ANAMNESE_SIMPLES }, tipoPadrao: clone(TIPO_PADRAO), v: 12 }; savePrompts(); render(); }''', '''await API.post("/api/admin/prompts/reset"); location.reload(); }''')
a3 = R(a3, '''await ask(S.prompts.aux.ocr + `\\n\\nAs imagens são, em ordem, as páginas ${batch.join(", ")}.`, { images: blobs, tier: "default" })''', '''await askAction("aux", { name: "ocr", vars: { PAGINAS: batch.join(", ") } }, { images: blobs })''')
a3 = R(a3, '''await ask(S.prompts.aux.ocr, { images: [f], tier: "default" })''', '''await askAction("aux", { name: "ocr" }, { images: [f] })''')
a3 = R(a3, '''await ask(fullPrompt(await fillVars(step.prompt, vars)), { tier: tierFor("fichamento", step.tier, VEL()), signal, onText: ({ text }) => streamSet(label, text) })''', '''await askAction("step", { caseId: S.cur.id, stepId: step.id, docId: d.id, part: k, vel: VEL() }, { signal, onText: ({ text }) => streamSet(label, text) })''')
a3 = R(a3, '''await ask(fullPrompt(await fillVars(S.prompts.aux.dados, { CAMPOS: campos })), { json: true, tier: tierFor("dados", "default", VEL()) })''', '''await askAction("aux", { name: "dados", caseId: S.cur.id, vel: VEL(), vars: { CAMPOS: campos } }, { json: true })''')
a3 = R(a3, '''await ask(fullPrompt(await fillVars(S.prompts.aux.quesitos)), { json: true, tier: tierFor("quesitos", "default", VEL()) })''', '''await askAction("aux", { name: "quesitos", caseId: S.cur.id, vel: VEL() }, { json: true })''')
a3 = R(a3, '''      const tpl = S.prompts.aux.organizar.replace("{{TRANSCRICAO}}", () => `(${iv.titulo} — ${iv.participante || ""})\\n${iv.texto}`);
      const obj = await ask(fullPrompt(await fillVars(tpl, { CAMPOS: campos })), { json: true, tier: tierFor("organizar", "default", VEL()) });''',
'''      const obj = await askAction("aux", { name: "organizar", caseId: S.cur.id, vel: VEL(), vars: { CAMPOS: campos, TRANSCRICAO: `(${iv.titulo} — ${iv.participante || ""})\\n${iv.texto}` } }, { json: true });''')
a3 = R(a3, '''  const text = await ask(fullPrompt(await fillVars(s.prompt, {}, s.id)), { tier: tierFor(s.id, s.tier, VEL()), signal: ctl.signal, onText });''',
'''  const text = await askAction("step", { caseId: S.cur.id, stepId: s.id, vel: VEL() }, { signal: ctl.signal, onText });''')
a3 = R(a3, '''    const tpl = S.prompts.aux.imagem.replace("{{TIPO}}", () => d.imgTipo || "não informado").replace("{{DESCRICAO}}", () => d.imgDesc || "não informada");
    const out = await ask(fullPrompt(tpl), { images, tier: tierFor("imagem", "complex", VEL()) });''',
'''    const out = await askAction("aux", { name: "imagem", vars: { TIPO: d.imgTipo || "", DESCRICAO: d.imgDesc || "" } }, { images });''')
a3 = R(a3, '''ask(S.prompts.aux.cid11.replace("{{C10}}", () => x.c10).replace("{{D10}}", () => x.d10), { json: true, tier: "default" })''', '''askAction("aux", { name: "cid11", vars: { C10: x.c10, D10: x.d10 } }, { json: true })''')
a3 = R(a3, '''    const tpl = S.prompts.aux.completar || DEFAULT_AUX.completar;
    const o = await ask(fullPrompt(await fillVars(tpl, { CAMPOS: defs.map(([k, l]) => `${k}: ${l}`).join("\\n"), BENEFICIOS: BENEFICIOS.map(b => b[0]).join(", ") })), { json: true, tier: tierFor("completar", "complex", VEL()) });''',
'''    const o = await askAction("aux", { name: "completar", caseId: S.cur.id, vel: VEL(), vars: { CAMPOS: defs.map(([k, l]) => `${k}: ${l}`).join("\\n"), BENEFICIOS: BENEFICIOS.map(b => b[0]).join(", ") } }, { json: true });''')
a3 = R(a3, 'Download indisponível nesta visualização. Abra a página no claude.ai ou use “Copiar”.', 'Download indisponível neste navegador.')
a3 = R(a3, 'Download indisponível nesta visualização. Abra a página no claude.ai.', 'Download indisponível neste navegador.')
a3 = R(a3, 'O ditado funciona no Chrome ou no app do Claude para computador. Você pode digitar normalmente.', 'O ditado por voz funciona no Google Chrome e no Microsoft Edge. Você pode digitar normalmente.')
a3 = R(a3, '"Dados salvos só neste navegador. Abra no Claude para salvar na sua conta."', '"Sem conexão com o servidor."')
a3 = R(a3, '''await ask(fullPrompt(await fillVars(S.prompts.aux.avaliacao)), { json: true, tier: tierFor("avaliacao", "complex", VEL()) })''', '''await askAction("aux", { name: "avaliacao", caseId: S.cur.id, vel: VEL() }, { json: true })''')
a3 = R(a3, '''await ask(fullPrompt(await fillVars(S.prompts.aux.complementar)), { tier: tierFor("complementar", "complex", VEL()), signal: ctl.signal, onText: ({ text }) => streamSet(label, text) })''', '''await askAction("aux", { name: "complementar", caseId: S.cur.id, vel: VEL(), vars: temLaudoPlataforma() ? { LAUDO_ORIGINAL: laudoOriginalTexto(), ORIGEM_LAUDO: "PLATAFORMA", AUTOS_APOS_LAUDO: "[não aplicável: laudo feito na plataforma]" } : { LAUDO_ORIGINAL: S.locAutos?.laudo || "[LAUDO NÃO LOCALIZADO NOS AUTOS]", ORIGEM_LAUDO: "AUTOS", AUTOS_APOS_LAUDO: S.locAutos?.depois || "[nenhum texto após o laudo]" } }, { signal: ctl.signal, onText: ({ text }) => streamSet(label, text) })''')
a3 = R(a3, '''await ask(fullPrompt(await fillVars(S.prompts.aux.correcoes, { CORRECOES: texto, LAUDO_ATUAL: htmlParaTexto($("#paper") || paper) })), { json: true, tier: tierFor("correcoes", "complex", VEL()) })''', '''await askAction("aux", { name: "correcoes", caseId: S.cur.id, vel: VEL(), vars: { CORRECOES: texto, LAUDO_ATUAL: htmlParaTexto($("#paper") || paper) } }, { json: true })''')
for bad in ['await ask(', 'S.prompts.aux.', 'fillVars(']:
    rest = [l for l in a3.split('\n') if bad in l and 'function' not in l and 'S.prompts.aux[' not in l]
    rest = [l for l in rest if not l.strip().startswith('else if (t.dataset.aux)')]
    assert not rest, (bad, rest[:3])

app = open(f'{HERE}/client/platform.js').read() + '\n' + a1 + '\n' + a2 + '\n' + a3 + '\n' + open(f'{HERE}/client/admin.js').read()
assert '</script' not in app.lower()

shell = open(f'{SRC}/shell.html').read()
css_extra = open(f'{HERE}/client/extra.css').read()
shell = shell.replace('</style>', css_extra + '\n</style>', 1)
shell = shell.replace('<title>Perícias Médicas — Plataforma do Perito</title>', '<title>Perícias Médicas — Plataforma do Perito</title>\n<link rel="icon" href="/favicon.png">')
logo = 'data:image/png;base64,' + base64.b64encode(open(f'{ASSETS}/logo_small.png', 'rb').read()).decode()
tpl = base64.b64encode(open(f'{ASSETS}/template.docx', 'rb').read()).decode()
head = 'const LOGO = "__LOGO__";\nconst TEMPLATE_DOCX = "__TEMPLATE__";\n__APP__'
assert head in shell
shell = shell.replace(head, 'const LOGO = "' + logo + '";\nconst TEMPLATE_DOCX = "' + tpl + '";\nconst DEFAULT_RULES = "", DEFAULT_FORMAT = "", DEFAULT_STEPS = [], DEFAULT_AUX = {}, MODELO_ANAMNESE_1_4 = "", MODELO_ANAMNESE_SIMPLES = "";\n' + app)
shell = shell.replace('<script src="https://cdnjs.cloudflare.com/ajax/libs/pdf.js', '<script src="/shared/defs.js"></script>\n<script src="https://cdnjs.cloudflare.com/ajax/libs/pdf.js', 1)
shell = shell.replace('__LOGO__', logo)
os.makedirs(f'{ROOT}/public', exist_ok=True)
open(f'{ROOT}/public/index.html', 'w').write(shell)
open(f'{ROOT}/public/favicon.png', 'wb').write(open(f'{ASSETS}/logo_small.png', 'rb').read())
lg = open(f'{HERE}/client/login.html').read().replace('__LOGO__', logo)
open(f'{ROOT}/public/login.html', 'w').write(lg)
print('ok', len(shell))
