/* Webhooks de SAÍDA (a plataforma avisa outros sistemas) e de ENTRADA (outros sistemas criam perícias). */
const crypto = require("crypto");
const { db, kv, now, J } = require("./db");
const D = require("../shared/defs.js");

const EVENTOS = {
  "pericia.criada": "Nova perícia criada (pelo perito ou por webhook de entrada)",
  "laudo.gerado": "Laudo montado pelo perito",
  "usuario.criado": "Novo perito cadastrado",
  "teste": "Evento de teste (botão Testar)"
};

function logHook(webhookId, direcao, evento, status, detalhe) {
  db.prepare("INSERT INTO webhook_log(webhook_id,direcao,evento,status,detalhe,created_at) VALUES(?,?,?,?,?,?)").run(webhookId ?? null, direcao, evento, status ?? null, String(detalhe || "").slice(0, 500), now());
  db.prepare("DELETE FROM webhook_log WHERE id NOT IN (SELECT id FROM webhook_log ORDER BY id DESC LIMIT 1000)").run();
}

async function deliver(h, evento, data) {
  const body = JSON.stringify({ evento, enviado_em: new Date().toISOString(), dados: data });
  const sig = "sha256=" + crypto.createHmac("sha256", h.secret).update(body).digest("hex");
  const ctl = new AbortController(), t = setTimeout(() => ctl.abort(), 10000);
  try {
    const r = await fetch(h.url, { method: "POST", signal: ctl.signal, headers: { "content-type": "application/json", "user-agent": "PericiasMedicas-Webhook/1.0", "x-pericias-evento": evento, "x-pericias-assinatura": sig }, body });
    logHook(h.id, "saida", evento, r.status, r.ok ? "entregue" : (await r.text()).slice(0, 300));
    return { ok: r.ok, status: r.status };
  } catch (e) { logHook(h.id, "saida", evento, 0, e.name === "AbortError" ? "tempo esgotado (10 s)" : e.message); return { ok: false, status: 0, erro: e.message }; }
  finally { clearTimeout(t); }
}

/* dispara para todos os webhooks ativos inscritos no evento (sem travar a resposta ao usuário) */
function emit(evento, base, sensivel = {}) {
  const hooks = db.prepare("SELECT * FROM webhooks WHERE ativo=1").all().filter(h => (J(h.events) || []).includes(evento));
  for (const h of hooks) deliver(h, evento, h.incluir_dados ? { ...base, ...sensivel } : base);
}

/* webhook de ENTRADA: cria uma perícia para o perito indicado */
function inbound(body) {
  const email = String(body?.perito_email || "").trim();
  const u = db.prepare("SELECT id,nome,email FROM users WHERE email=? COLLATE NOCASE AND ativo=1").get(email);
  if (!u) { const e = new Error("perito_email não corresponde a um usuário ativo."); e.status = 422; throw e; }
  const pick = (src, defs) => { const o = {}; for (const [k, , type] of defs) if (k !== "#" && src && src[k] != null && typeof src[k] !== "object") o[k] = String(src[k]).slice(0, 2000); return o; };
  const id = Date.now().toString(36) + crypto.randomBytes(3).toString("hex");
  const c = {
    id, created: now(), updated: now(), status: "rascunho", origem: "webhook",
    processo: { data: "", beneficio: "", local: "", ...pick(body.processo, D.F_PROCESSO) }, stepsOn: {},
    periciando: pick(body.periciando, D.F_PERICIANDO), anamnese: {}, exame: {}, complementares: [], outrosDocs: "", entrevistas: [], docs: [], cids: [],
    testes: { res: {}, gonio: {}, med: {}, dor: { escala: "EVA", valor: "", local: "", obs: "" }, segs: null },
    quesitos: { templates: Array.isArray(body.quesitos?.modelos) ? body.quesitos.modelos.map(String).slice(0, 10) : [], juizoExtra: "", assistente: "", mp: "", autor: "", reu: "", outros: "" }
  };
  for (const g of D.QUESITO_GRUPOS) if (typeof body.quesitos?.[g[0]] === "string") c.quesitos[g[0]] = body.quesitos[g[0]].slice(0, 50000);
  kv.set(u.id, "case_" + id, c);
  const ix = kv.get(u.id, "index") || { cases: [] };
  ix.cases.unshift({ id, nome: c.periciando.nome || "", numero: c.processo.numero || "", beneficio: c.processo.beneficio || "", data: c.processo.data || "", status: "rascunho", updated: now() });
  kv.set(u.id, "index", ix);
  emit("pericia.criada", { pericia_id: id, origem: "webhook", perito: { id: u.id, nome: u.nome, email: u.email } }, { processo_numero: c.processo.numero || "", beneficio: c.processo.beneficio || "" });
  return { pericia_id: id, perito: u.email };
}

module.exports = { EVENTOS, emit, deliver, inbound, logHook };
