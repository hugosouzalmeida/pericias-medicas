/* Conexão com os provedores de IA: Claude (Anthropic), OpenAI e OpenRouter.
   As chaves ficam criptografadas no banco e só são lidas aqui, no servidor. */
const { db, config, now } = require("./db");
const { decrypt } = require("./security");

const PROVIDERS = {
  anthropic: { nome: "Claude (Anthropic)", url: (process.env.ANTHROPIC_BASE_URL || "https://api.anthropic.com") + "/v1/messages" },
  openai: { nome: "OpenAI", url: (process.env.OPENAI_BASE_URL || "https://api.openai.com/v1") + "/chat/completions" },
  openrouter: { nome: "OpenRouter", url: (process.env.OPENROUTER_BASE_URL || "https://openrouter.ai/api/v1") + "/chat/completions" }
};
const DEFAULT_AI = {
  provider: "anthropic",
  maxTokens: 16000,
  models: {
    anthropic: { quick: "claude-haiku-5-5", default: "claude-sonnet-5-5", complex: "claude-opus-5-5" },
    openai: { quick: "", default: "", complex: "" },
    openrouter: { quick: "", default: "", complex: "" }
  }
};
function aiConfig() {
  const c = config.get("ai") || {};
  return { ...DEFAULT_AI, ...c, models: { ...DEFAULT_AI.models, ...(c.models || {}) } };
}
function getKey(provider) {
  const r = db.prepare("SELECT enc FROM secrets WHERE provider=?").get(provider);
  return r ? decrypt(r.enc) : null;
}
function status() {
  const c = aiConfig();
  if (process.env.AI_MOCK === "1") return { configured: true, provider: "mock", images: true };
  const ok = !!getKey(c.provider) && !!c.models[c.provider]?.default;
  return { configured: ok, provider: c.provider, images: true };
}

/* ---------- leitura de streams SSE ---------- */
async function* sseLines(body) {
  const dec = new TextDecoder(); let buf = "";
  for await (const chunk of body) {
    buf += dec.decode(chunk, { stream: true });
    let i; while ((i = buf.indexOf("\n")) >= 0) { const line = buf.slice(0, i).replace(/\r$/, ""); buf = buf.slice(i + 1); yield line; }
  }
  if (buf) yield buf;
}
function parseJSONLoose(text) {
  const t = String(text || "").trim();
  try { return JSON.parse(t); } catch {}
  const f = /```(?:json)?\s*([\s\S]*?)```/i.exec(t); if (f) { try { return JSON.parse(f[1]); } catch {} }
  const a = Math.min(...["{", "["].map(c => (t.indexOf(c) < 0 ? Infinity : t.indexOf(c)))), b = Math.max(t.lastIndexOf("}"), t.lastIndexOf("]"));
  if (a < Infinity && b > a) { try { return JSON.parse(t.slice(a, b + 1)); } catch {} }
  const e = new Error("A resposta não veio no formato esperado."); e.code = "invalid_json"; e.text = t; throw e;
}
function httpError(status, body) {
  let msg = body; try { const j = JSON.parse(body); msg = j.error?.message || j.message || body; } catch {}
  const e = new Error(`Provedor respondeu ${status}: ${String(msg).slice(0, 300)}`);
  e.code = status === 401 || status === 403 ? "bad_key" : status === 429 ? "rate_limited" : status === 413 ? "prompt_too_large" : status === 400 ? "bad_request" : "upstream_error";
  return e;
}

/* ---------- chamada principal ---------- */
async function callAI({ prompt, images = [], tier = "default", onText, signal, json = false, provider: forced }) {
  const c = aiConfig();
  if (process.env.AI_MOCK === "1" && !forced) return mock({ prompt, json, onText });
  const provider = forced || c.provider, key = getKey(provider), model = c.models[provider]?.[tier] || c.models[provider]?.default;
  if (!key || !model) { const e = new Error("IA não configurada pelo administrador."); e.code = "not_configured"; throw e; }
  const maxTokens = +c.maxTokens || 16000;
  const instr = json ? "\n\nResponda somente com o JSON pedido, sem texto antes ou depois." : "";
  let text = "", usage = { in: 0, out: 0 }, truncated = false;
  const emit = d => { if (d) { text += d; onText?.(text); } };

  if (provider === "anthropic") {
    const content = [...images.map(im => ({ type: "image", source: { type: "base64", media_type: im.mime, data: im.data } })), { type: "text", text: prompt + instr }];
    const r = await fetch(PROVIDERS.anthropic.url, {
      method: "POST", signal,
      headers: { "content-type": "application/json", "x-api-key": key, "anthropic-version": "2023-06-01" },
      body: JSON.stringify({ model, max_tokens: maxTokens, stream: true, messages: [{ role: "user", content }] })
    });
    if (!r.ok) throw httpError(r.status, await r.text());
    for await (const line of sseLines(r.body)) {
      if (!line.startsWith("data:")) continue;
      let ev; try { ev = JSON.parse(line.slice(5)); } catch { continue; }
      if (ev.type === "message_start") usage.in = ev.message?.usage?.input_tokens || 0;
      else if (ev.type === "content_block_delta" && ev.delta?.type === "text_delta") emit(ev.delta.text);
      else if (ev.type === "message_delta") { usage.out = ev.usage?.output_tokens || usage.out; if (ev.delta?.stop_reason === "max_tokens") truncated = true; }
      else if (ev.type === "error") throw httpError(500, JSON.stringify(ev));
    }
  } else {
    const content = images.length ? [...images.map(im => ({ type: "image_url", image_url: { url: `data:${im.mime};base64,${im.data}` } })), { type: "text", text: prompt + instr }] : prompt + instr;
    const headers = { "content-type": "application/json", authorization: "Bearer " + key };
    if (provider === "openrouter") { headers["HTTP-Referer"] = process.env.PUBLIC_URL || "http://localhost"; headers["X-Title"] = "Pericias Medicas"; }
    const body = { model, stream: true, messages: [{ role: "user", content }] };
    if (provider === "openai") { body.max_completion_tokens = maxTokens; body.stream_options = { include_usage: true }; } else body.max_tokens = maxTokens;
    const r = await fetch(PROVIDERS[provider].url, { method: "POST", signal, headers, body: JSON.stringify(body) });
    if (!r.ok) throw httpError(r.status, await r.text());
    for await (const line of sseLines(r.body)) {
      if (!line.startsWith("data:")) continue;
      const d = line.slice(5).trim(); if (d === "[DONE]") break;
      let ev; try { ev = JSON.parse(d); } catch { continue; }
      if (ev.error) throw httpError(500, JSON.stringify(ev.error));
      const ch = ev.choices?.[0];
      emit(ch?.delta?.content);
      if (ch?.finish_reason === "length") truncated = true;
      if (ev.usage) usage = { in: ev.usage.prompt_tokens || 0, out: ev.usage.completion_tokens || 0 };
    }
  }
  if (!text.trim()) { const e = new Error("O provedor não retornou texto."); e.code = "empty_completion"; throw e; }
  return { text, truncated, usage, provider, model, json: json ? parseJSONLoose(text) : undefined };
}

async function testProvider(provider) {
  const c = aiConfig(), key = getKey(provider), model = c.models[provider]?.quick || c.models[provider]?.default;
  if (!key) return { ok: false, message: "Nenhuma chave cadastrada." };
  if (!model) return { ok: false, message: "Informe o nome do modelo." };
  try { const r = await callAI({ prompt: "Responda apenas: OK", tier: "quick", provider }); return { ok: true, message: `Conectado (${model}): ${r.text.trim().slice(0, 40)}` }; }
  catch (e) { return { ok: false, message: e.message }; }
}

function logUsage(userId, action, r, ok = true) {
  db.prepare("INSERT INTO ai_usage(user_id,provider,model,action,input_tokens,output_tokens,ok,created_at) VALUES(?,?,?,?,?,?,?,?)")
    .run(userId, r?.provider || aiConfig().provider, r?.model || "", action, r?.usage?.in || 0, r?.usage?.out || 0, ok ? 1 : 0, now());
}

/* modo de demonstração (AI_MOCK=1): respostas fixas, sem custo — só para testes */
async function mock({ prompt, json, onText }) {
  await new Promise(r => setTimeout(r, 60));
  let text;
  if (json) text = prompt.includes("agrupe-os por autor") ? '{"juizo":"","mp":"","autor":"","reu":"","assistente":"","outros":""}' : prompt.includes("CID-11 (MMS)") ? '{"codigo":"ME84.2","observacao":"demonstração"}' : '{"campos":{},"exames_complementares":[],"cid10":[]}';
  else { const m = /redija "## ([^"]+)"/.exec(prompt) || /"## ([^"]+)"/.exec(prompt); text = m ? `## ${m[1]}\nTexto de demonstração (modo AI_MOCK).` : "### Identificação do documento\nDemonstração (modo AI_MOCK)."; }
  onText?.(text);
  return { text, truncated: false, usage: { in: 0, out: 0 }, provider: "mock", model: "mock", json: json ? JSON.parse(text) : undefined };
}

module.exports = { PROVIDERS, DEFAULT_AI, aiConfig, getKey, status, callAI, testProvider, logUsage, parseJSONLoose };
