/* Senhas, sessões e criptografia das chaves de API. */
const crypto = require("crypto");
const bcrypt = require("bcryptjs");
const { db, now } = require("./db");

/* ---------- criptografia (AES-256-GCM) para as chaves de API ---------- */
function masterKey() {
  const k = process.env.MASTER_KEY;
  if (!k || k.length < 32) throw new Error("MASTER_KEY ausente ou curta (mínimo 32 caracteres). Veja o README.");
  return crypto.createHash("sha256").update(k).digest();
}
function encrypt(text) {
  const iv = crypto.randomBytes(12), c = crypto.createCipheriv("aes-256-gcm", masterKey(), iv);
  const ct = Buffer.concat([c.update(String(text), "utf8"), c.final()]);
  return Buffer.concat([iv, c.getAuthTag(), ct]).toString("base64");
}
function decrypt(b64) {
  const b = Buffer.from(b64, "base64"), iv = b.subarray(0, 12), tag = b.subarray(12, 28), ct = b.subarray(28);
  const d = crypto.createDecipheriv("aes-256-gcm", masterKey(), iv); d.setAuthTag(tag);
  return Buffer.concat([d.update(ct), d.final()]).toString("utf8");
}
const sha256 = s => crypto.createHash("sha256").update(String(s)).digest("hex");
const randomToken = (n = 32) => crypto.randomBytes(n).toString("hex");
function tempPassword() {
  const abc = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789";
  return Array.from(crypto.randomBytes(12), b => abc[b % abc.length]).join("");
}

/* ---------- senhas ---------- */
const hashPassword = p => bcrypt.hashSync(String(p), 12);
const checkPassword = (p, h) => bcrypt.compareSync(String(p), h);
function passwordProblem(p) {
  p = String(p || "");
  if (p.length < 10) return "A senha precisa ter pelo menos 10 caracteres.";
  if (!/[A-Za-z]/.test(p) || !/\d/.test(p)) return "Use letras e números na senha.";
  return null;
}

/* ---------- sessões (cookie httpOnly; no banco guardamos só o hash do token) ---------- */
const SESSION_DAYS = +(process.env.SESSION_DAYS || 7);
const COOKIE = "sid";
const secureCookie = () => process.env.COOKIE_SECURE === "1" || process.env.NODE_ENV === "production";
function createSession(res, userId) {
  const token = randomToken(32), exp = now() + SESSION_DAYS * 864e5;
  db.prepare("INSERT INTO sessions(token_hash,user_id,created_at,expires_at) VALUES(?,?,?,?)").run(sha256(token), userId, now(), exp);
  res.cookie(COOKIE, token, { httpOnly: true, sameSite: "lax", secure: secureCookie(), maxAge: SESSION_DAYS * 864e5, path: "/" });
}
function destroySession(req, res) {
  const t = req.cookies?.[COOKIE]; if (t) db.prepare("DELETE FROM sessions WHERE token_hash=?").run(sha256(t));
  res.clearCookie(COOKIE, { path: "/" });
}
function sessionUser(req) {
  const t = req.cookies?.[COOKIE]; if (!t) return null;
  const s = db.prepare("SELECT s.user_id, s.expires_at, u.* FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=?").get(sha256(t));
  if (!s || s.expires_at < now() || !s.ativo) return null;
  return { id: s.user_id, email: s.email, nome: s.nome, role: s.role, mustChange: !!s.must_change };
}
function requireAuth(req, res, next) {
  const u = sessionUser(req);
  if (!u) return res.status(401).json({ code: "unauthenticated", message: "Faça login novamente." });
  req.user = u;
  if (u.mustChange && !req.path.startsWith("/api/auth/")) return res.status(403).json({ code: "must_change", message: "Troque sua senha temporária." });
  next();
}
function requireAdmin(req, res, next) {
  if (req.user?.role !== "admin") return res.status(403).json({ code: "forbidden", message: "Acesso restrito ao administrador." });
  next();
}

/* ---------- limite de tentativas de login ---------- */
const attempts = new Map();
function loginBlocked(key) {
  const a = attempts.get(key); if (!a) return false;
  if (a.until && a.until > now()) return true;
  if (a.until && a.until <= now()) attempts.delete(key);
  return false;
}
function loginFailed(key) {
  const a = attempts.get(key) || { n: 0 }; a.n++;
  if (a.n >= 8) { a.until = now() + 15 * 60e3; a.n = 0; }
  attempts.set(key, a);
}
const loginOk = key => attempts.delete(key);

module.exports = { encrypt, decrypt, sha256, randomToken, tempPassword, hashPassword, checkPassword, passwordProblem, createSession, destroySession, sessionUser, requireAuth, requireAdmin, loginBlocked, loginFailed, loginOk };
