/* Montagem dos prompts NO SERVIDOR. O navegador só informa a ação (etapa, perícia, documento)
   e alguns dados não sigilosos; o texto dos prompts nunca sai daqui. */
const D = require("../shared/defs.js");
const P = require("./defaults.js");
const { kv, config } = require("./db");
const { SH } = D;

const bytes = s => Buffer.byteLength(String(s), "utf8");
const CH_DOC = 90000;                // mesmo tamanho de parte usado no navegador
const CLIENT_VARS = ["CORRECOES", "LAUDO_ATUAL", "LAUDO_ORIGINAL", "ORIGEM_LAUDO", "AUTOS_APOS_LAUDO", "CAMPOS", "TRANSCRICAO", "TIPO", "DESCRICAO", "C10", "D10", "BENEFICIOS", "PAGINAS"];

function promptsConfigRaw() {
  const c = config.get("prompts") || {};
  return {
    rules: c.rules ?? P.DEFAULT_RULES, format: c.format ?? P.DEFAULT_FORMAT,
    steps: Array.isArray(c.steps) && c.steps.length ? c.steps : P.DEFAULT_STEPS,
    aux: { ...P.DEFAULT_AUX, ...(c.aux || {}) }, v: c.v,
    modelos: { completo: P.MODELO_ANAMNESE_1_4, simplificado: P.MODELO_ANAMNESE_SIMPLES, ...(c.modelos || {}) },
    tipoPadrao: c.tipoPadrao || { ...D.TIPO_PADRAO }
  };
}
/* v4: marcações de revisão (<excesso>, <investigar>) e módulos de anamnese em prompts já salvos */
function promptsConfig() { return migrarV4(promptsConfigRaw()); }
function migrarV4(pc) {
  if (!pc.format.includes("<investigar>")) {
    const nl = P.DEFAULT_FORMAT.split("\n").filter(l => /<red>|<excesso>|<investigar>/.test(l)).join("\n");
    pc.format = /^- Para destacar EM VERMELHO.*$/m.test(pc.format) ? pc.format.replace(/^- Para destacar EM VERMELHO.*$/m, () => nl) : pc.format + "\n" + nl;
  }
  if (!pc.format.includes("VOZ DO PERITO")) pc.format += "\n" + P.DEFAULT_FORMAT.split("\n").find(l => l.startsWith("- VOZ DO PERITO"));
  pc.steps = pc.steps.map(s => {
    if (s.id !== "secoes" || !s.prompt || s.prompt.includes("{{MODULOS_ANAMNESE}}")) return s;
    const bloco = "MÓDULOS DE ANAMNESE E EXAME SELECIONADOS PELO PERITO (siga estes roteiros nas seções 2 e 3; não acrescente sistemas que não foram selecionados nem examinados):\n{{MODULOS_ANAMNESE}}\n\n";
    return { ...s, prompt: s.prompt.includes("\nMODELO:\n") ? s.prompt.replace("\nMODELO:\n", () => "\n" + bloco + "MODELO:\n") : s.prompt + "\n\n" + bloco };
  });
  pc.steps = D.migrarPromptsV6(pc.steps, P.DEFAULT_STEPS);
  D.migrarAuxV7(pc.aux, P.DEFAULT_AUX);
  D.migrarV8(pc, P.DEFAULT_STEPS, P.DEFAULT_FORMAT);
  D.migrarV9(pc, P.DEFAULT_FORMAT);
  D.migrarV10(pc, P.DEFAULT_FORMAT);
  D.migrarV11(pc, P.DEFAULT_STEPS);
  D.migrarV12(pc, P.DEFAULT_STEPS, P.DEFAULT_FORMAT);
  if (pc.modelos?.simplificado?.startsWith("LAUDO MÉDICO PERICIAL (SIMPLIFICADO")) pc.modelos.simplificado = pc.modelos.simplificado.replace(/^[^\n]*/, P.MODELO_ANAMNESE_SIMPLES.split("\n")[0]);
  pc.v = Math.max(pc.v || 0, 12);
  return pc;
}
function modulosTexto(uid, c) {
  const lista = kv.get(uid, "modulos")?.list || D.DEFAULT_MODULOS;
  const sel = Array.isArray(c.modulos) ? c.modulos : D.modulosSugeridos(c);
  return lista.filter(m => sel.includes(m.id)).map(m => `### ${m.nome}\n${m.texto}`).join("\n\n") || "[nenhum módulo selecionado: siga o modelo padrão]";
}
const fullPrompt = (pc, task) => `${pc.rules}\n\n${pc.format}\n\n${task}`;

function docText(uid, doc) {
  let t = ""; for (let n = 0; n < (doc.parts || 0); n++) t += kv.get(uid, `txt_${doc.id}_${n}`)?.t || ""; return D.prepDocText(t, doc.pagSel);
}
function lines(c, group, defs) {
  return defs.filter(d => d[0] !== "#").map(([k, l]) => { let v = SH.getPath(c, group + "." + k); if (k === "beneficio") v = SH.benefLabel(v); return `- ${l}: ${String(v ?? "").trim() || "[não preenchido]"}`; }).join("\n");
}
function cidsTexto(c) {
  const l = (c.cids || []).map(x => (x.c10 ? `${x.d10} — CID-10 ${x.c10}` : "") + (x.c11 ? `${x.c10 ? "; " : ""}CID-11 ${x.c11} (${x.d11})${x.ia11 ? " [correspondência sugerida por IA, a confirmar]" : ""}` : ""));
  return l.length ? l.join("; ") : "[nenhum CID codificado pelo perito]";
}
function confTexto(r) {
  if (!r) return "[conferência não realizada]";
  if (r.semDoc) return "[sem documento oficial da Justiça anexado para conferência]";
  const L = { ok: "confere com os autos", divergente: "NÃO confere com os autos", nao_encontrado: "não encontrado no texto dos autos", parcial: "confere parcialmente (grafia diferente)", vazio: "não preenchido" };
  return `nº do processo ${L[r.numero] || "-"}${r.cnjValido === false ? " (dígito verificador CNJ inválido)" : ""}${r.numero === "divergente" ? " — números nos autos: " + (r.numerosAutos || []).join(", ") : ""}; nome do periciando ${L[r.nome] || "-"}${r.nome !== "ok" && r.nomesAutos?.length ? " — nomes nos autos: " + r.nomesAutos.join(", ") : ""}`;
}
function fichamentos(uid, c) {
  const out = [];
  for (const d of c.docs || []) { if (!d.fichOk || d.categoria === "poslaudo") continue; const f = kv.get(uid, "fich_" + d.id)?.t; if (f) out.push(`### DOCUMENTO: ${d.nome} (${SH.catLabel(d.categoria)}${d.paginas ? ", " + d.paginas + " pág." : ""})\n${f}`); }
  return out.join("\n\n") || "[Nenhum documento fichado]";
}
function fichamentosNovos(uid, c) {
  const out = [];
  for (const d of c.docs || []) { if (!d.fichOk || d.categoria !== "poslaudo") continue; const f = kv.get(uid, "fich_" + d.id)?.t; if (f) out.push(`### DOCUMENTO: ${d.nome}${d.paginas ? " (" + d.paginas + " pág.)" : ""}\n${f}`); }
  return out.join("\n\n") || "[Nenhum documento novo juntado após o laudo]";
}
function quesitosJuizo(c) {
  const q = c.quesitos || {}, qt = config.get("qtemplates")?.list || D.DEFAULT_QTEMPLATES;
  const parts = (q.templates || []).map(id => qt.find(t => t.id === id)).filter(Boolean).map(t => `### ${t.nome}\n${t.texto}`);
  if ((q.juizoExtra || "").trim()) parts.push(`### Quesitos adicionais do Juízo\n${q.juizoExtra}`);
  return parts.join("\n\n") || "[Nenhum quesito do Juízo informado]";
}
function quesitosPartes(c) {
  const q = c.quesitos || {};
  return D.QUESITO_GRUPOS.filter(g => g[0] !== "juizoExtra" && (q[g[0]] || "").trim()).map(g => `### ${g[1]}\n${q[g[0]]}`).join("\n\n") || "[Nenhum quesito das partes informado]";
}
function stepOn(c, s) { const v = c.stepsOn?.[s.id]; return v != null ? v : !(s.modalidades || []).length || (s.modalidades || []).includes(c.processo?.beneficio); }
function laudoAteAgora(pc, outputs, exceptId, c) {
  return pc.steps.filter(s => s.ativo && stepOn(c, s) && s.ordemLaudo > 0 && s.id !== exceptId && outputs[s.id]).sort((a, b) => a.ordemLaudo - b.ordemLaudo).map(s => outputs[s.id].text).join("\n\n") || "[ainda vazio]";
}

function fillVars(tpl, ctx, extra = {}, exceptId) {
  const { uid, c, pc, outputs, profile } = ctx;
  const need = k => tpl.includes("{{" + k + "}}");
  const fich = need("FICHAMENTOS") ? fichamentos(uid, c) : "";
  const tt = SH.testesTexto(c.testes);
  const tipo = c.tipoLaudo || pc.tipoPadrao?.[c.processo?.beneficio] || "completo";
  const V = {
    PERITO: `${profile.nome || "[nome do perito não preenchido]"} — ${profile.crm || "[CRM não preenchido]"}${profile.especialidade ? " — " + profile.especialidade : ""}`,
    PROCESSO: lines(c, "processo", D.F_PROCESSO) + "\n- Conferência automática com documento oficial anexado: " + confTexto(c.conf),
    BENEFICIO: SH.benefLabel(c.processo?.beneficio) + (c.processo?.natureza ? " — " + c.processo.natureza : ""),
    PERICIANDO: lines(c, "periciando", D.F_PERICIANDO) + D.indiretaTexto(c), CIDS: cidsTexto(c),
    MODULOS_ANAMNESE: need("MODULOS_ANAMNESE") ? modulosTexto(uid, c) : "",
    ANAMNESE: lines(c, "anamnese", D.F_ANAMNESE) + "\n- Diagnósticos codificados pelo perito (usar no item 2.1 e nas tabelas DOENÇA / DATA / CID dos quesitos): " + cidsTexto(c),
    EXAME: lines(c, "exame", D.F_EXAME) + (SH.testesCount(c.testes) ? "\n- Testes especiais, goniometria, medidas e dor registrados pelo perito (incluir fielmente nos itens 3.2 i e 3.2 j):\n" + tt.all : ""),
    EXAMES_COMPLEMENTARES: ((c.complementares || []).map((x, i) => `- 4.${i + 1}: ${x.tipo || "[tipo não informado]"} — ${SH.fmtDate(x.data) || "[sem data]"} — ${x.resultado || "[sem resultado]"}`).join("\n") || "[nenhum registrado pelo perito]") + (c.outrosDocs ? `\n- Outros documentos: ${c.outrosDocs}` : ""),
    ENTREVISTAS: (c.entrevistas || []).filter(e => (e.texto || "").trim()).map(e => `### ${e.titulo} (${e.participante || "—"}, ${SH.fmtDate(e.data)})\n${e.texto}`).join("\n\n") || "[sem transcrição]",
    QUESITOS_JUIZO: quesitosJuizo(c), QUESITOS_PARTES: quesitosPartes(c),
    LISTA_ARQUIVOS: (c.docs || []).map(d => `- ${d.nome} — ${SH.catLabel(d.categoria)}${d.paginas ? " — " + d.paginas + " pág." : ""}`).join("\n") || "[nenhum arquivo]",
    LAUDO_ATE_AGORA: need("LAUDO_ATE_AGORA") ? laudoAteAgora(pc, outputs, exceptId, c) : "",
    MODELO_ANAMNESE_1_4: tipo === "simplificado" ? pc.modelos.simplificado : pc.modelos.completo, MODELO_ANAMNESE_5: P.MODELO_ANAMNESE_5,
    AVALIACAO_PERITO: D.avaliacaoTexto(c),
    FICHAMENTOS_NOVOS: need("FICHAMENTOS_NOVOS") ? fichamentosNovos(uid, c) : "",
    IMPUGNACAO: (c.complementar?.texto || "").trim() || "[não colado — ver os documentos juntados após o laudo]",
    DECISAO: D.DECISAO_COMP(c),
    TIPO_LAUDO: tipo === "simplificado" ? "SIMPLIFICADO (perícia simples: objetivo, só os itens do modelo)" : "COMPLETO",
    FICHAMENTOS: fich,
    ...extra
  };
  let s = tpl.replace(/\{\{SECAO:([\w-]+)\}\}/g, (_, id) => outputs[id]?.text || "[etapa ainda não executada]");
  s = s.replace(/\{\{([A-Z_0-9]+)\}\}/g, (m, k) => (k in V ? String(V[k]) : m));
  const LIM = 230000, base = bytes(fullPrompt(pc, s));
  if (base > LIM && fich) {
    const fb = bytes(fich), keep = Math.max(2000, Math.floor(fich.length * (1 - (base - LIM) / fb)) - 2000);
    s = s.replace(fich, () => fich.slice(0, keep) + "\n\n[FICHAMENTOS CORTADOS POR LIMITE DE TAMANHO — sinalize em <red> que parte dos documentos não pôde ser considerada nesta etapa]");
  }
  return s;
}

function badRequest(msg) { const e = new Error(msg); e.code = "bad_request"; return e; }

/* Monta { prompt, tier } para uma ação pedida pelo navegador. */
function buildAction(user, action, params = {}) {
  const uid = user.id, pc = promptsConfig();
  const extra = {};
  for (const [k, v] of Object.entries(params.vars || {})) if (CLIENT_VARS.includes(k)) extra[k] = String(v ?? "").slice(0, 200000);
  const loadCase = () => {
    const id = String(params.caseId || ""); if (!/^[\w-]{3,40}$/.test(id)) throw badRequest("Perícia inválida.");
    const c = kv.get(uid, "case_" + id); if (!c) throw badRequest("Perícia não encontrada.");
    const outputs = kv.get(uid, "out_" + id)?.outputs || {};
    const profile = { ...(user.role === "admin" ? D.DEFAULT_PROFILE : D.DEFAULT_PROFILE_PERITO), ...(kv.get(uid, "profile") || {}) };
    return { uid, c, pc, outputs, profile };
  };

  if (action === "step") {
    const step = pc.steps.find(s => s.id === params.stepId && s.ativo);
    if (!step) throw badRequest("Etapa não encontrada ou desativada.");
    const ctx = loadCase();
    if (step.escopo === "documento") {
      const d = (ctx.c.docs || []).find(x => x.id === params.docId); if (!d) throw badRequest("Documento não encontrado.");
      const text = docText(uid, d), n = Math.max(1, Math.ceil(text.length / CH_DOC)), k = Math.min(Math.max(0, +params.part || 0), n - 1);
      const vars = { DOC_NOME: d.nome, DOC_CATEGORIA: SH.catLabel(d.categoria), DOCUMENTO: text.slice(k * CH_DOC, (k + 1) * CH_DOC), PARTE: `${k + 1} de ${n}` };
      return { prompt: fullPrompt(pc, fillVars(step.prompt, ctx, vars)), tier: D.tierFor("fichamento", step.tier || "default", params.vel) };
    }
    return { prompt: fullPrompt(pc, fillVars(step.prompt, ctx, {}, step.id)), tier: D.tierFor(step.id, step.tier || "complex", params.vel) };
  }

  if (action === "aux") {
    const name = params.name, tpl = pc.aux[name];
    if (!tpl) throw badRequest("Ação desconhecida.");
    if (name === "ocr") return { prompt: tpl + (extra.PAGINAS ? `\n\nAs imagens são, em ordem, as páginas ${extra.PAGINAS}.` : ""), tier: "default" };
    if (name === "cid11") return { prompt: tpl.replace("{{C10}}", () => extra.C10 || "").replace("{{D10}}", () => extra.D10 || ""), tier: "default" };
    if (name === "imagem") return { prompt: fullPrompt(pc, tpl.replace("{{TIPO}}", () => extra.TIPO || "não informado").replace("{{DESCRICAO}}", () => extra.DESCRICAO || "não informada")), tier: D.tierFor("imagem", "complex", params.vel) };
    const ctx = loadCase();
    const t2 = tpl.replace("{{TRANSCRICAO}}", () => extra.TRANSCRICAO || "");
    return { prompt: fullPrompt(pc, fillVars(t2, ctx, extra)), tier: D.tierFor(name, ["completar", "avaliacao", "complementar", "correcoes"].includes(name) ? "complex" : "default", params.vel) };
  }
  throw badRequest("Ação desconhecida.");
}

/* Versão "sem prompts" da configuração, para os peritos (só nomes e ordem das etapas). */
function stripPrompts(pc) {
  return { rules: "", format: "", aux: {}, v: pc.v, modelos: {}, tipoPadrao: pc.tipoPadrao, steps: pc.steps.map(({ id, nome, escopo, tier, ordemLaudo, ativo, modalidades, prompt }) => ({ id, nome, escopo, tier, ordemLaudo, ativo, modalidades, prompt: "",
    deps: [...String(prompt || "").matchAll(/\{\{SECAO:([\w-]+)\}\}/g)].map(m => m[1]), usaLaudo: String(prompt || "").includes("{{LAUDO_ATE_AGORA}}") })) };
}

module.exports = { promptsConfig, buildAction, stripPrompts, fullPrompt };
