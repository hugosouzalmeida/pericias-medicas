/* Lê o arquivo .env (se existir) sem dependências externas. */
const fs = require("fs");
const path = require("path");
const f = path.join(__dirname, "..", ".env");
if (fs.existsSync(f)) {
  for (const line of fs.readFileSync(f, "utf8").split(/\r?\n/)) {
    const m = /^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/.exec(line);
    if (!m || line.trim().startsWith("#")) continue;
    let v = m[2]; if (/^(["']).*\1$/.test(v)) v = v.slice(1, -1);
    if (process.env[m[1]] === undefined) process.env[m[1]] = v;
  }
}
