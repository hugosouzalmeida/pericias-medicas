/* Perícias Médicas — servidor (Node.js + Express + SQLite). Veja o README para instalar. */
require("./env");
const path = require("path");
const express = require("express");
const cookieParser = require("cookie-parser");
const { db, kv, config, audit, now, J } = require("./db");
const S = require("./security");
const AI = require("./ai");
const PR = require("./prompts");
const WH = require("./webhooks");
const D = require("../shared/defs.js");

S.encrypt("teste");                 // falha cedo se MASTER_KEY não estiver configurada
const app = express();
app.disable("x-powered-by");
app.set("trust proxy", 1);
app.use(cookieParser());
app.use(express.json({ limit: "40mb" }));
app.use((req, res, next) => {
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("X-Frame-Options", "DENY");
  res.setHeader("Referrer-Policy", "same-origin");
  res.setHeader("Permissions-Policy", "camera=(), geolocation=(), microphone=(self)");
  res.setHeader("Content-Security-Policy", "default-src 'self'; script-src 'self' 'unsafe-inline' https://cdnjs.cloudflare.com https://cdn.jsdelivr.net; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; img-src 'self' data: blob:; connect-src 'self'; worker-src 'self' blob:; frame-ancestors 'none'");
  next();
});
const wrap = fn => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

/* ===================== primeira execução ===================== */
function seed() {
  if (!db.prepare("SELECT 1 FROM users WHERE role='admin'").get()) {
    const email = process.env.ADMIN_EMAIL || "admin@exemplo.com";
    const senha = process.env.ADMIN_PASSWORD || S.tempPassword();
    db.prepare("INSERT INTO users(email,nome,senha_hash,role,must_change,created_at) VALUES(?,?,?,?,?,?)").run(email, process.env.ADMIN_NOME || "Administrador", S.hashPassword(senha), "admin", 1, now());
    console.log(`\n>>> Administrador criado: ${email}  senha temporária: ${process.env.ADMIN_PASSWORD ? "(a definida em ADMIN_PASSWORD)" : senha}\n>>> No primeiro acesso a troca de senha é obrigatória.\n`);
  }
  if (!config.get("prompts")) config.set("prompts", PR.promptsConfig());
  if (!config.get("qtemplates")) config.set("qtemplates", { list: D.DEFAULT_QTEMPLATES });
  if (!config.get("padrao")) config.set("padrao", D.DEFAULT_PADRAO);
  if (!config.get("ai")) config.set("ai", AI.DEFAULT_AI);
}
seed();

/* ===================== login ===================== */
app.post("/api/auth/login", wrap(async (req, res) => {
  const email = String(req.body?.email || "").trim(), senha = String(req.body?.senha || "");
  const key = (req.ip || "") + "|" + email.toLowerCase();
  if (S.loginBlocked(key)) return res.status(429).json({ code: "blocked", message: "Muitas tentativas. Aguarde 15 minutos." });
  const u = db.prepare("SELECT * FROM users WHERE email=? COLLATE NOCASE").get(email);
  if (!u || !u.ativo || !S.checkPassword(senha, u.senha_hash)) { S.loginFailed(key); return res.status(401).json({ code: "invalid", message: "E-mail ou senha incorretos." }); }
  S.loginOk(key);
  db.prepare("UPDATE users SET last_login=? WHERE id=?").run(now(), u.id);
  S.createSession(res, u.id); audit(u.id, "login");
  res.json({ ok: true, mustChange: !!u.must_change, role: u.role });
}));
app.post("/api/auth/logout", (req, res) => { S.destroySession(req, res); res.json({ ok: true }); });
app.post("/api/auth/password", S.requireAuth, (req, res) => {
  const u = db.prepare("SELECT * FROM users WHERE id=?").get(req.user.id);
  if (!S.checkPassword(req.body?.atual || "", u.senha_hash)) return res.status(400).json({ code: "invalid", message: "Senha atual incorreta." });
  const prob = S.passwordProblem(req.body?.nova); if (prob) return res.status(400).json({ code: "weak", message: prob });
  if (req.body.nova === req.body.atual) return res.status(400).json({ code: "weak", message: "A nova senha precisa ser diferente da atual." });
  db.prepare("UPDATE users SET senha_hash=?, must_change=0 WHERE id=?").run(S.hashPassword(req.body.nova), u.id);
  db.prepare("DELETE FROM sessions WHERE user_id=?").run(u.id); S.createSession(res, u.id); audit(u.id, "senha alterada");
  res.json({ ok: true });
});
app.get("/api/me", S.requireAuth, (req, res) => res.json(req.user));

/* ===================== dados (cada perito só acessa o que é seu) ===================== */
function parsePath(p, user) {
  let m = /^data\/users\/(\d+)\/([A-Za-z0-9_\-.:@+~]{1,200})$/.exec(p || "");
  if (m) { if (+m[1] !== user.id) return { err: 403 }; return { kind: "user", key: m[2] }; }
  m = /^config\/(prompts|qtemplates|padrao)$/.exec(p || "");
  if (m) return { kind: "config", key: m[1] };
  return { err: 400 };
}
app.get("/api/kv", S.requireAuth, (req, res) => {
  const p = parsePath(req.query.path, req.user); if (p.err) return res.status(p.err).json({ code: "bad_path" });
  if (p.kind === "user") return res.json({ exists: true, value: kv.get(req.user.id, p.key) });
  let v = config.get(p.key);
  if (p.key === "prompts") v = req.user.role === "admin" ? PR.promptsConfig() : PR.stripPrompts(PR.promptsConfig());
  res.json({ value: v });
});
app.put("/api/kv", S.requireAuth, (req, res) => {
  const p = parsePath(req.query.path, req.user); if (p.err) return res.status(p.err).json({ code: "bad_path" });
  const val = req.body; if (!val || typeof val !== "object" || Array.isArray(val)) return res.status(400).json({ code: "invalid_argument" });
  if (p.kind === "config") {
    if (req.user.role !== "admin") return res.status(403).json({ code: "forbidden" });
    config.set(p.key, val); audit(req.user.id, "config " + p.key); return res.json({ ok: true });
  }
  if (p.key.startsWith("case_")) {             // eventos para webhooks
    const old = kv.get(req.user.id, p.key);
    const base = { pericia_id: val.id, perito: { id: req.user.id, nome: req.user.nome, email: req.user.email } };
    const sens = { processo_numero: val.processo?.numero || "", beneficio: val.processo?.beneficio || "" };
    kv.set(req.user.id, p.key, val);
    if (!old) WH.emit("pericia.criada", { ...base, origem: "plataforma" }, sens);
    else if (old.status !== "gerado" && val.status === "gerado") WH.emit("laudo.gerado", base, sens);
    return res.json({ ok: true });
  }
  kv.set(req.user.id, p.key, val); res.json({ ok: true });
});
app.delete("/api/kv", S.requireAuth, (req, res) => {
  const p = parsePath(req.query.path, req.user); if (p.err) return res.status(p.err).json({ code: "bad_path" });
  if (p.kind === "config") return res.status(403).json({ code: "forbidden" });
  kv.del(req.user.id, p.key); res.json({ ok: true });
});

/* ===================== IA ===================== */
app.get("/api/ai/status", S.requireAuth, (req, res) => res.json(AI.status()));
app.post("/api/ai/run", S.requireAuth, wrap(async (req, res) => {
  const { action, params, json } = req.body || {};
  let built;
  try { built = PR.buildAction(req.user, action, params); }
  catch (e) { return res.status(400).json({ code: e.code || "bad_request", message: e.message }); }
  const images = [];
  for (const u of (req.body.images || []).slice(0, 8)) {
    const m = /^data:(image\/(?:jpeg|png|webp|gif));base64,([A-Za-z0-9+/=]+)$/.exec(u || "");
    if (m) images.push({ mime: m[1], data: m[2] });
  }
  res.setHeader("Content-Type", "text/event-stream"); res.setHeader("Cache-Control", "no-cache"); res.setHeader("X-Accel-Buffering", "no");
  res.flushHeaders?.();
  const send = (ev, data) => res.write(`event: ${ev}\ndata: ${JSON.stringify(data)}\n\n`);
  const ctl = new AbortController(); res.on("close", () => { if (!res.writableFinished) ctl.abort(); });
  let last = 0, lastText = "";
  try {
    const r = await AI.callAI({ prompt: built.prompt, images, tier: built.tier, json: !!json, signal: ctl.signal,
      onText: t => { lastText = t; if (Date.now() - last > 150) { last = Date.now(); send("text", { text: t }); } } });
    AI.logUsage(req.user.id, action === "step" ? "etapa:" + params?.stepId : "aux:" + params?.name, r);
    send("done", { text: r.text, truncated: r.truncated, json: r.json });
  } catch (e) {
    AI.logUsage(req.user.id, String(action), null, false);
    if (e.name === "AbortError") return res.end();
    send("error", { code: e.code || "upstream_error", message: e.message, text: e.text || lastText || undefined });
  }
  res.end();
}));

/* ===================== administração ===================== */
const admin = express.Router();
admin.use(S.requireAuth, S.requireAdmin);

admin.get("/users", (req, res) => res.json(db.prepare("SELECT id,email,nome,role,ativo,must_change,created_at,last_login FROM users ORDER BY role, nome").all()));
admin.post("/users", (req, res) => {
  const email = String(req.body?.email || "").trim(), nome = String(req.body?.nome || "").trim(), role = req.body?.role === "admin" ? "admin" : "perito";
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return res.status(400).json({ message: "E-mail inválido." });
  if (db.prepare("SELECT 1 FROM users WHERE email=? COLLATE NOCASE").get(email)) return res.status(409).json({ message: "Já existe um usuário com este e-mail." });
  const senha = S.tempPassword();
  const r = db.prepare("INSERT INTO users(email,nome,senha_hash,role,must_change,created_at) VALUES(?,?,?,?,1,?)").run(email, nome, S.hashPassword(senha), role, now());
  audit(req.user.id, "usuário criado", email);
  WH.emit("usuario.criado", { usuario: { id: r.lastInsertRowid, nome, email, perfil: role } });
  res.json({ id: r.lastInsertRowid, senhaTemporaria: senha });
});
admin.patch("/users/:id", (req, res) => {
  const id = +req.params.id, u = db.prepare("SELECT * FROM users WHERE id=?").get(id); if (!u) return res.status(404).json({ message: "Usuário não encontrado." });
  const b = req.body || {}, self = id === req.user.id;
  if (self && (b.ativo === false || b.role === "perito")) return res.status(400).json({ message: "Você não pode desativar nem rebaixar a própria conta." });
  if (b.nome != null) db.prepare("UPDATE users SET nome=? WHERE id=?").run(String(b.nome).slice(0, 200), id);
  if (b.role === "admin" || b.role === "perito") db.prepare("UPDATE users SET role=? WHERE id=?").run(b.role, id);
  if (b.ativo != null) { db.prepare("UPDATE users SET ativo=? WHERE id=?").run(b.ativo ? 1 : 0, id); if (!b.ativo) db.prepare("DELETE FROM sessions WHERE user_id=?").run(id); }
  let senhaTemporaria;
  if (b.resetSenha) { senhaTemporaria = S.tempPassword(); db.prepare("UPDATE users SET senha_hash=?, must_change=1 WHERE id=?").run(S.hashPassword(senhaTemporaria), id); db.prepare("DELETE FROM sessions WHERE user_id=?").run(id); }
  audit(req.user.id, "usuário alterado", u.email + " " + JSON.stringify({ ...b, resetSenha: !!b.resetSenha }));
  res.json({ ok: true, senhaTemporaria });
});

admin.get("/ai", (req, res) => {
  const c = AI.aiConfig(), keys = {};
  for (const p of Object.keys(AI.PROVIDERS)) { const r = db.prepare("SELECT last4,updated_at FROM secrets WHERE provider=?").get(p); keys[p] = r ? { cadastrada: true, final: r.last4, atualizada: r.updated_at } : { cadastrada: false }; }
  res.json({ provider: c.provider, models: c.models, maxTokens: c.maxTokens, keys, providers: Object.fromEntries(Object.entries(AI.PROVIDERS).map(([k, v]) => [k, v.nome])), mock: process.env.AI_MOCK === "1" });
});
admin.put("/ai", (req, res) => {
  const b = req.body || {}, c = AI.aiConfig();
  if (b.provider && AI.PROVIDERS[b.provider]) c.provider = b.provider;
  if (b.models) for (const p of Object.keys(AI.PROVIDERS)) if (b.models[p]) for (const t of ["quick", "default", "complex"]) if (typeof b.models[p][t] === "string") c.models[p][t] = b.models[p][t].trim().slice(0, 120);
  if (b.maxTokens) c.maxTokens = Math.min(64000, Math.max(1000, +b.maxTokens || 16000));
  config.set("ai", c); audit(req.user.id, "configuração de IA", c.provider); res.json({ ok: true });
});
admin.put("/ai/key/:provider", (req, res) => {
  const p = req.params.provider; if (!AI.PROVIDERS[p]) return res.status(400).json({ message: "Provedor inválido." });
  const key = String(req.body?.key || "").trim();
  if (!key) { db.prepare("DELETE FROM secrets WHERE provider=?").run(p); audit(req.user.id, "chave removida", p); return res.json({ ok: true }); }
  if (key.length < 20 || /\s/.test(key)) return res.status(400).json({ message: "A chave parece inválida." });
  db.prepare("INSERT INTO secrets(provider,enc,last4,updated_at) VALUES(?,?,?,?) ON CONFLICT(provider) DO UPDATE SET enc=excluded.enc,last4=excluded.last4,updated_at=excluded.updated_at").run(p, S.encrypt(key), key.slice(-4), now());
  audit(req.user.id, "chave cadastrada", p); res.json({ ok: true });
});
admin.post("/ai/test/:provider", wrap(async (req, res) => { if (!AI.PROVIDERS[req.params.provider]) return res.status(400).json({ message: "Provedor inválido." }); res.json(await AI.testProvider(req.params.provider)); }));

admin.get("/webhooks", (req, res) => res.json({
  eventos: WH.EVENTOS,
  saida: db.prepare("SELECT id,nome,url,events,incluir_dados,ativo,created_at FROM webhooks ORDER BY id").all().map(h => ({ ...h, events: J(h.events) || [] })),
  entrada: db.prepare("SELECT id,nome,ativo,created_at FROM inbound_tokens ORDER BY id").all(),
  log: db.prepare("SELECT * FROM webhook_log ORDER BY id DESC LIMIT 50").all()
}));
admin.post("/webhooks", (req, res) => {
  const b = req.body || {}; let url;
  try { url = new URL(String(b.url)); } catch { return res.status(400).json({ message: "URL inválida." }); }
  if (url.protocol !== "https:" && !(process.env.ALLOW_HTTP_WEBHOOKS === "1")) return res.status(400).json({ message: "Use uma URL https://." });
  const events = (Array.isArray(b.events) ? b.events : []).filter(e => WH.EVENTOS[e]);
  if (!events.length) return res.status(400).json({ message: "Escolha pelo menos um evento." });
  const secret = S.randomToken(24);
  const r = db.prepare("INSERT INTO webhooks(nome,url,events,secret,incluir_dados,ativo,created_at) VALUES(?,?,?,?,?,1,?)").run(String(b.nome || "").slice(0, 100), url.href, JSON.stringify(events), secret, b.incluirDados ? 1 : 0, now());
  audit(req.user.id, "webhook criado", url.host); res.json({ id: r.lastInsertRowid, segredo: secret });
});
admin.patch("/webhooks/:id", (req, res) => {
  const b = req.body || {}, id = +req.params.id;
  if (b.ativo != null) db.prepare("UPDATE webhooks SET ativo=? WHERE id=?").run(b.ativo ? 1 : 0, id);
  if (Array.isArray(b.events)) db.prepare("UPDATE webhooks SET events=? WHERE id=?").run(JSON.stringify(b.events.filter(e => WH.EVENTOS[e])), id);
  if (b.incluirDados != null) db.prepare("UPDATE webhooks SET incluir_dados=? WHERE id=?").run(b.incluirDados ? 1 : 0, id);
  res.json({ ok: true });
});
admin.delete("/webhooks/:id", (req, res) => { db.prepare("DELETE FROM webhooks WHERE id=?").run(+req.params.id); audit(req.user.id, "webhook removido", req.params.id); res.json({ ok: true }); });
admin.post("/webhooks/:id/test", wrap(async (req, res) => {
  const h = db.prepare("SELECT * FROM webhooks WHERE id=?").get(+req.params.id); if (!h) return res.status(404).json({ message: "Webhook não encontrado." });
  res.json(await WH.deliver(h, "teste", { mensagem: "Teste da plataforma Perícias Médicas", por: req.user.email }));
}));
admin.post("/inbound", (req, res) => {
  const token = S.randomToken(24);
  const r = db.prepare("INSERT INTO inbound_tokens(nome,token_hash,created_at) VALUES(?,?,?)").run(String(req.body?.nome || "Entrada").slice(0, 100), S.sha256(token), now());
  audit(req.user.id, "token de entrada criado"); res.json({ id: r.lastInsertRowid, url: `/api/webhooks/entrada/${token}` });
});
admin.delete("/inbound/:id", (req, res) => { db.prepare("DELETE FROM inbound_tokens WHERE id=?").run(+req.params.id); res.json({ ok: true }); });

admin.get("/usage", (req, res) => res.json(db.prepare(`SELECT u.nome, u.email, strftime('%Y-%m', a.created_at/1000, 'unixepoch') AS mes, a.provider,
  COUNT(*) AS chamadas, SUM(a.input_tokens) AS entrada, SUM(a.output_tokens) AS saida, SUM(1-a.ok) AS falhas
  FROM ai_usage a LEFT JOIN users u ON u.id=a.user_id GROUP BY a.user_id, mes, a.provider ORDER BY mes DESC, u.nome`).all()));
admin.post("/prompts/reset", (req, res) => { const P = require("./defaults.js"); config.set("prompts", { rules: P.DEFAULT_RULES, format: P.DEFAULT_FORMAT, steps: P.DEFAULT_STEPS, aux: P.DEFAULT_AUX, modelos: { completo: P.MODELO_ANAMNESE_1_4, simplificado: P.MODELO_ANAMNESE_SIMPLES }, tipoPadrao: require("../shared/defs.js").TIPO_PADRAO, v: 12 }); audit(req.user.id, "prompts restaurados"); res.json({ ok: true }); });
app.use("/api/admin", admin);

/* ===================== webhook de entrada (público, protegido pelo token) ===================== */
app.post("/api/webhooks/entrada/:token", (req, res) => {
  const t = db.prepare("SELECT * FROM inbound_tokens WHERE token_hash=? AND ativo=1").get(S.sha256(req.params.token));
  if (!t) return res.status(404).json({ message: "Endereço inválido." });
  try { const r = WH.inbound(req.body); WH.logHook(null, "entrada", "pericia.criada", 200, `${t.nome}: ${r.perito}`); res.json({ ok: true, ...r }); }
  catch (e) { WH.logHook(null, "entrada", "pericia.criada", e.status || 400, e.message); res.status(e.status || 400).json({ message: e.message }); }
});

/* ===================== páginas ===================== */
const PUB = path.join(__dirname, "..", "public");
app.get(["/", "/index.html"], (req, res) => {
  const u = S.sessionUser(req);
  if (!u || u.mustChange) return res.redirect("/login.html");
  res.setHeader("Cache-Control", "no-store"); res.sendFile(path.join(PUB, "index.html"));
});
app.use("/shared", express.static(path.join(__dirname, "..", "shared"), { maxAge: "1h" }));
app.use(express.static(PUB, { index: false, maxAge: "1h" }));
app.use((err, req, res, next) => { console.error(err); res.status(err.status || 500).json({ code: "server_error", message: err.type === "entity.too.large" ? "Arquivo grande demais." : "Erro interno." }); });

const PORT = +process.env.PORT || 3000;
if (require.main === module) app.listen(PORT, () => console.log(`Perícias Médicas rodando em http://localhost:${PORT}`));
module.exports = app;
