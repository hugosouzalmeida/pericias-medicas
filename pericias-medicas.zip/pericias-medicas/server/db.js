/* Banco de dados SQLite (um único arquivo em DATA_DIR/pericias.db). */
const path = require("path");
const fs = require("fs");
const Database = require("better-sqlite3");

const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, "..", "data");
fs.mkdirSync(DATA_DIR, { recursive: true });
const db = new Database(path.join(DATA_DIR, "pericias.db"));
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT NOT NULL UNIQUE COLLATE NOCASE,
  nome TEXT NOT NULL DEFAULT '',
  senha_hash TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('admin','perito')),
  ativo INTEGER NOT NULL DEFAULT 1,
  must_change INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL,
  last_login INTEGER
);
CREATE TABLE IF NOT EXISTS sessions (
  token_hash TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS kv (
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  key TEXT NOT NULL,
  value TEXT NOT NULL,
  updated_at INTEGER NOT NULL,
  PRIMARY KEY (user_id, key)
);
CREATE TABLE IF NOT EXISTS config (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL,
  updated_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS secrets (
  provider TEXT PRIMARY KEY,
  enc TEXT NOT NULL,
  last4 TEXT NOT NULL,
  updated_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS webhooks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  nome TEXT NOT NULL DEFAULT '',
  url TEXT NOT NULL,
  events TEXT NOT NULL,
  secret TEXT NOT NULL,
  incluir_dados INTEGER NOT NULL DEFAULT 0,
  ativo INTEGER NOT NULL DEFAULT 1,
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS webhook_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  webhook_id INTEGER,
  direcao TEXT NOT NULL,
  evento TEXT NOT NULL,
  status INTEGER,
  detalhe TEXT,
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS inbound_tokens (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  nome TEXT NOT NULL,
  token_hash TEXT NOT NULL UNIQUE,
  ativo INTEGER NOT NULL DEFAULT 1,
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS ai_usage (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER,
  provider TEXT, model TEXT, action TEXT,
  input_tokens INTEGER DEFAULT 0, output_tokens INTEGER DEFAULT 0,
  ok INTEGER DEFAULT 1,
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS audit (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER, acao TEXT NOT NULL, detalhe TEXT,
  created_at INTEGER NOT NULL
);
`);

const now = () => Date.now();
const J = s => { try { return JSON.parse(s); } catch { return null; } };

const kv = {
  get: (uid, key) => { const r = db.prepare("SELECT value FROM kv WHERE user_id=? AND key=?").get(uid, key); return r ? J(r.value) : null; },
  set: (uid, key, val) => db.prepare("INSERT INTO kv(user_id,key,value,updated_at) VALUES(?,?,?,?) ON CONFLICT(user_id,key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at").run(uid, key, JSON.stringify(val), now()),
  del: (uid, key) => db.prepare("DELETE FROM kv WHERE user_id=? AND key=?").run(uid, key)
};
const config = {
  get: key => { const r = db.prepare("SELECT value FROM config WHERE key=?").get(key); return r ? J(r.value) : null; },
  set: (key, val) => db.prepare("INSERT INTO config(key,value,updated_at) VALUES(?,?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at").run(key, JSON.stringify(val), now())
};
const audit = (uid, acao, detalhe = "") => db.prepare("INSERT INTO audit(user_id,acao,detalhe,created_at) VALUES(?,?,?,?)").run(uid ?? null, acao, String(detalhe).slice(0, 500), now());

module.exports = { db, kv, config, audit, now, J, DATA_DIR };
