# Perícias Médicas — versão própria (com API)

Esta é a versão da plataforma de perícias que roda **no seu próprio servidor**, fora do Claude. Ela tem as mesmas telas e funções da versão que está no Claude e acrescenta:

- **Login com e-mail e senha.** Senhas guardadas com bcrypt, troca obrigatória no primeiro acesso e bloqueio após 8 tentativas erradas.
- **Área do administrador** separada da área do perito: usuários, IA e chaves de API, webhooks, uso da IA, prompts e modelos de quesitos.
- **Chaves de API do Claude (Anthropic), da OpenAI e da OpenRouter**, guardadas **criptografadas** (AES-256-GCM) e nunca enviadas ao navegador.
- **Prompts protegidos.** O servidor monta os prompts. O navegador do perito só pede "execute a etapa X da perícia Y" e nunca recebe o texto dos prompts.
- **Webhooks de saída**, em que a plataforma avisa outros sistemas, com assinatura HMAC.
- **Webhooks de entrada**, em que outro sistema cria uma perícia para um perito.
- **Registro de uso da IA** por perito e por mês.

> Os peritos **não precisam de conta no Claude**. A IA usa a chave de API cadastrada pelo administrador, e o custo é cobrado na conta do provedor dessa chave.

---

## 1. Como funciona

```
Navegador do perito ──(login, dados da perícia)──►  Servidor  ──(prompt + chave)──►  Claude / OpenAI / OpenRouter
        ▲                                             │  banco SQLite (data/pericias.db)
        └──────────── texto do laudo (streaming) ─────┘  chaves criptografadas · prompts · usuários
```

| | Versão no Claude (protótipo) | Versão própria (esta) |
|---|---|---|
| Login | conta do Claude | e-mail e senha da plataforma |
| IA | cota da conta Claude de cada perito | sua chave de API (Claude, OpenAI ou OpenRouter) |
| Prompts | escondidos da tela, mas presentes no código da página | **só no servidor** |
| Webhooks | não é possível | saída e entrada |
| Ditado por voz | Claude | reconhecimento de voz do Chrome/Edge |
| Dados | área privada do Claude | banco no seu servidor (você é o responsável) |

---

## 2. Testar no seu computador (10 minutos)

Pré-requisito: **Node.js 20 ou mais novo** (https://nodejs.org).

```bash
cd pericias-medicas
npm install
cp .env.example .env        # no Windows: copy .env.example .env
npm run chave               # copie o resultado para MASTER_KEY no arquivo .env
```

No arquivo `.env`, preencha `MASTER_KEY`, `ADMIN_EMAIL` e `ADMIN_PASSWORD` (uma senha temporária). Para testar sem HTTPS, deixe `COOKIE_SECURE=0`.

```bash
npm start
```

Abra **http://localhost:3000**, entre com o e-mail e a senha temporária e crie a sua senha definitiva.

Para testar **sem gastar créditos de IA**, use `npm run demo`. A IA passa a devolver respostas fixas de demonstração.

---

## 3. Colocar no ar (para os peritos usarem)

O servidor é um programa Node.js comum com um banco SQLite. Ele precisa de **um disco que não se apague**, onde fica o banco, e de **HTTPS**. Duas opções:

**A) Plataforma de hospedagem (Render, Railway, Fly.io e similares)**
1. Envie esta pasta para um repositório privado no GitHub.
2. Crie um serviço Web a partir do repositório (detecção automática de Node ou o `Dockerfile` incluído).
3. Comando de início: `npm start`. Adicione um **disco persistente** montado em `/data` e defina `DATA_DIR=/data`.
4. Cadastre as variáveis do `.env.example` no painel da hospedagem, com `COOKIE_SECURE=1`.
5. Aponte o seu domínio (por exemplo, `pericias.seudominio.com.br`). A hospedagem fornece o HTTPS.

**B) Servidor próprio (VPS) com Docker**
```bash
docker compose up -d --build
```
Coloque um proxy com HTTPS na frente, por exemplo o Caddy (`pericias.seudominio.com.br { reverse_proxy localhost:3000 }`). Os dados ficam no volume `pericias-dados`.

> Recomendação: peça a um desenvolvedor para fazer a primeira publicação e configurar backup automático. São poucas horas de trabalho.

---

## 4. Primeiros passos como administrador

1. **IA e chaves de API.** Cole a chave do provedor, confira os nomes dos modelos, clique em **Testar conexão** e marque o provedor **em uso**.
   - Claude: https://console.anthropic.com → API Keys. Os nomes de modelo já vêm preenchidos; confira se estão disponíveis na sua conta.
   - OpenAI: https://platform.openai.com/api-keys. Informe os modelos da sua conta.
   - OpenRouter: https://openrouter.ai/keys. Informe os modelos como aparecem em openrouter.ai/models.
   - Cada etapa usa uma "profundidade": **Rápido** (CID-11), **Padrão** (fichamento, preenchimento) ou **Máximo** (laudo, conclusão, quesitos, imagens).
2. **Usuários.** Cadastre cada perito pelo e-mail. A plataforma mostra uma **senha temporária**; entregue ao perito o endereço do site, o e-mail e essa senha. No primeiro acesso ele cria a própria senha. Esqueceu a senha? Use **Nova senha** na lista.
3. **Prompts e Modelos de quesitos.** Funcionam como na versão do Claude. O que você salva passa a valer para todos os peritos.
4. **Meu perfil.** Cabeçalho, rodapé, logotipo e troca de senha.

Cada perito vê **somente as próprias perícias**. O administrador gerencia usuários e configurações, mas não abre as perícias dos peritos pelas telas.

---

## 5. Webhooks

### Saída: a plataforma avisa outro sistema
Em **Webhooks → Saída**, informe uma URL `https://`, como as de Zapier, Make ou n8n, e escolha os eventos:

| Evento | Quando |
|---|---|
| `pericia.criada` | perícia criada pelo perito ou por webhook de entrada |
| `laudo.gerado` | perito clicou em "Montar laudo" / executou todas as etapas |
| `usuario.criado` | novo usuário cadastrado |
| `teste` | botão **Testar** |

Exemplo de envio (POST, JSON):
```json
{ "evento": "laudo.gerado", "enviado_em": "2026-11-15T18:00:00.000Z",
  "dados": { "pericia_id": "mwi5v8f1", "perito": { "id": 2, "nome": "Dra. Ana", "email": "ana@exemplo.com" } } }
```
Por padrão **não** vão dados do processo nem do periciando. A opção "Incluir nº do processo e benefício" acrescenta só esses dois campos. Avalie isso à luz da LGPD.

**Assinatura:** cada envio traz o cabeçalho `X-Pericias-Assinatura: sha256=<HMAC-SHA256 do corpo com o segredo>`. O segredo aparece uma única vez, na criação do webhook. Para conferir no destino (Node.js):
```js
const ok = req.headers["x-pericias-assinatura"] === "sha256=" + crypto.createHmac("sha256", SEGREDO).update(corpoBruto).digest("hex");
```

### Entrada: outro sistema cria uma perícia
Em **Webhooks → Entrada**, gere um endereço (`/api/webhooks/entrada/<token>`). O token funciona como uma senha: quem tiver o endereço consegue criar perícias.
```json
POST https://pericias.seudominio.com.br/api/webhooks/entrada/<token>
{
  "perito_email": "ana@exemplo.com",
  "processo":   { "numero": "0001234-55.2026.4.01.3600", "juizo": "JEF Cuiabá", "beneficio": "auxdoenca", "data": "2026-12-01", "horario": "09:30" },
  "periciando": { "nome": "Nome do periciando", "cpf": "000.000.000-00" },
  "quesitos":   { "modelos": ["auxdoenca"], "autor": "1. ...", "reu": "1. ..." }
}
```
Valores de `beneficio`: auxdoenca, aposentadoria, auxacidente, loas, pensao, acrescimo, ir, internacao, trabalhista, outro.

---

## 6. Backup — importante

Guarde **duas coisas**, com cópia diária fora do servidor:
1. o arquivo do banco: `DATA_DIR/pericias.db`, que tem perícias, usuários, configurações e chaves criptografadas;
2. a **`MASTER_KEY`**. Sem ela, as chaves de API salvas não podem ser lidas. Basta cadastrá-las de novo, mas guarde a MASTER_KEY assim mesmo.

Com o servidor ligado, para copiar o banco com segurança: `sqlite3 pericias.db ".backup copia.db"`.

---

## 7. LGPD, sigilo e termos de uso — leia antes de lançar

- O sistema guarda **dados pessoais sensíveis de saúde** (LGPD, art. 11). Você, como operador da plataforma, é responsável por: servidor seguro, HTTPS, backup, controle de acesso, contrato com os peritos e política de privacidade.
- Os textos das perícias são enviados ao provedor de IA escolhido. Verifique nos termos do provedor como ele trata os dados enviados pela API, e informe isso aos peritos.
- Sobre cobrar dos peritos pelo uso: conforme conversamos, confirme com a equipe comercial do provedor e com um advogado o modelo de cobrança. Por exemplo: assinatura do seu software e treinamento, e IA pela sua chave de API.
- O laudo gerado é uma **minuta**. A responsabilidade técnica e a revisão final são sempre do perito.

---

## 8. Limitações conhecidas

- **Senha esquecida:** não há "Esqueci minha senha" por e-mail. O administrador gera uma senha temporária. Pode ser acrescentado com um serviço de e-mail.
- **Ditado por voz:** usa o reconhecimento de voz do navegador, que funciona no Chrome e no Edge. Ele envia o áudio ao serviço de voz do próprio navegador.
- **Releitura de PDF digitalizado ou foto:** depois de recarregar a página, é preciso enviar o arquivo de novo. O original não é guardado; só o texto extraído, a ficha e a miniatura.
- **CID-11:** os títulos estão em inglês (lista oficial da OMS). A correspondência com a CID-10 é sugerida pela IA e conferida contra a lista oficial.
- **Servidor único:** um servidor com SQLite atende bem dezenas de peritos. Para centenas de usuários simultâneos, migrar para PostgreSQL.

---

## 9. Estrutura

```
server/index.js      rotas: login, dados, IA, administração, webhooks, páginas
server/prompts.js    monta os prompts no servidor (equivalente ao que a versão do Claude fazia no navegador)
server/defaults.js   prompts padrão (sigilosos)
server/ai.js         Claude, OpenAI e OpenRouter (streaming) + modo demonstração
server/security.js   senhas, sessões, criptografia das chaves, limite de tentativas
server/webhooks.js   webhooks de saída (HMAC) e de entrada
server/db.js         banco SQLite
shared/defs.js       campos, quesitos, testes especiais (público — sem prompts)
public/              telas (gerado por scripts/build_client.py), tabelas CID, fontes
scripts/plataforma/  código-fonte das telas (o mesmo da versão no Claude)
```

Para alterar as telas, edite `scripts/plataforma/` e rode `python3 scripts/build_client.py`.

Fontes Liberation Sans/Serif: licença SIL Open Font License (`public/fonts/LICENSE.txt`). Tabela CID-10: DATASUS. Lista CID-11: OMS.
