/* Definições compartilhadas entre o servidor e o navegador.
   NÃO coloque prompts aqui: este arquivo é público. Os prompts ficam em server/defaults.js.
   Arquivo gerado por scripts/split_defs.py */
(function (root) {
const DEFAULT_PROFILE = {
  nome: "Dr. Hugo Souza Almeida",
  titulo: "PERÍCIAS MÉDICAS",
  linha2: "Médico  |  CRM-MT 8566",
  crm: "CRM-MT 8566",
  especialidade: "",
  qualificacoes: "Medicina | Fisioterapia | Ciências Biológicas | Técnico em Edificações",
  contato: "(65) 99266-4423  |  hugosouzapericias@gmail.com",
  cidade: "Cuiabá-MT",
  logo: null
};

/* Prompt original do perito (Prompt Perícia TRT) — aplicado a TODAS as etapas */
const TIPO_PADRAO = { loas: "simplificado" };

const CAB_JEF = "SEÇÃO JUDICIÁRIA DE MATO GROSSO — JUIZADO ESPECIAL FEDERAL — GABEX/COJEF/MT\nNº do processo / Vara / Periciando / CPF / Grau de instrução / Data de nascimento / E-mail / Telefone";
const TAB_DOENCA = "[Tabela: DOENÇA | DATA DE INÍCIO | CID]";

const DEFAULT_QTEMPLATES = [
  {
    id: "sisperjud", nome: "Incapacidade — SISPERJUD 4.1", tags: ["auxdoenca", "aposentadoria", "outro"],
    texto: `LAUDO PERICIAL – MÉDICO DE INCAPACIDADE (SISPERJUD)

DADOS COMPLEMENTARES
- Ausência da parte pericianda? ( ) Sim ( ) Não
- A parte pericianda foi paciente do(a) perito(a)? ( ) Sim ( ) Não
- Houve comparecimento de assistente técnico? ( ) Sim ( ) Não — Nome completo / CRM / Especialidade
- A perícia foi realizada por telemedicina? ( ) Sim ( ) Não
- Atividade laboral atual declarada:
- Outras atividades já exercidas:
- A parte pericianda já foi submetida à reabilitação profissional? ( ) Sim ( ) Não — Se sim, para qual atividade:
- Em caso de recebimento prévio de benefício cujo restabelecimento esteja sendo discutido, o tratamento foi mantido durante a vigência do benefício? ( ) Sim ( ) Não

HISTÓRICO CLÍNICO
- Houve afastamento de atividades laborais? ( ) Sim ( ) Não — Datas declaradas do(s) afastamento(s):
- História clínica / Anamnese:
- Relato de doença, lesão física, mental e/ou comorbidades? ( ) Sim ( ) Não — Se sim, especificar:
- Encontra-se em tratamento atualmente? ( ) Sim ( ) Não — Qual tratamento / Data de início / Tempo de tratamento:
- Houve incapacidade pretérita além dos períodos em gozo de benefício previdenciário? ( ) Sim ( ) Não — Se sim, especificar período: Data inicial / Data final
- Documentos médicos/odontológicos analisados pelo(a) perito(a):

EXAME CLÍNICO
- Descrição do estado clínico atual da parte pericianda:

ANÁLISE PERICIAL
- A parte pericianda é ou foi portadora de doença ou lesão física ou mental? ( ) Sim ( ) Não
- A enfermidade se enquadra no rol da Portaria Interministerial MTP/MS nº 22, de 31/08/2022? ( ) Sim ( ) Não (Tuberculose ativa; hanseníase; transtorno mental grave com alienação mental; neoplasia maligna; cegueira; paralisia irreversível e incapacitante; cardiopatia grave; doença de Parkinson; espondiloartrose anquilosante; nefropatia grave; estado avançado da doença de Paget; AIDS; contaminação por radiação; hepatopatia grave; esclerose múltipla; AVE agudo; abdome agudo cirúrgico).
- Indicar a enfermidade diagnosticada:
- É possível atestar a data inicial da doença, lesão ou consolidação da sequela? ( ) Sim ( ) Não
- A doença ou lesão (ou o respectivo tratamento) incapacita ou incapacitou para o trabalho? ( ) Sim ( ) Não — Data de início da incapacidade (DII) / Justificativa e documentos comprobatórios:
- A doença ou lesão decorre de acidente de trabalho? ( ) Sim ( ) Não — Justificativa:
- A doença ou lesão decorre de acidente de qualquer natureza? ( ) Sim ( ) Não — Justificativa:

CLASSIFICAÇÃO DA INCAPACIDADE LABORATIVA
( ) Nenhuma ( ) Parcial e temporária ( ) Parcial e permanente ( ) Total e temporária ( ) Total e permanente ( ) Incapacidade atual ( ) Incapacidade pretérita
- Qual a data ou o prazo estimado para recuperação da capacidade laboral, conforme diretrizes médicas?
- A parte pericianda necessita de assistência permanente de outra pessoa para as atividades da vida diária? ( ) Sim ( ) Não
- A incapacidade decorreu de progressão ou agravamento de doença(s) ou lesão(ões) pré-existente(s)? ( ) Sim ( ) Não
- Apresenta lesões consolidadas com redução da capacidade para a atividade habitual em decorrência de acidente de qualquer natureza? ( ) Sim ( ) Não — Data da consolidação:

INFORMAÇÕES ADICIONAIS
- A parte pericianda respondeu sozinha aos quesitos? ( ) Sim ( ) Não — Se não, quem colaborou:
- É capaz de administrar os valores que venha a receber a título de atrasados? ( ) Sim ( ) Não
- Houve alteração do quadro incapacitante após a perícia administrativa? ( ) Sim ( ) Não — Se sim, quais alterações:
- Existe divergência em relação às conclusões do laudo administrativo? ( ) Sim ( ) Não — Se sim, fundamentar o dissenso:

QUESITOS COMPLEMENTARES (responder de forma objetiva e fundamentada, conforme quesitos apresentados nos autos)
CONSIDERAÇÕES FINAIS (síntese conclusiva da perícia, com fundamento técnico-médico)`
  },
  {
    id: "auxdoenca", nome: "Auxílio-doença / Aposentadoria por invalidez (JEF-MT)", tags: ["auxdoenca", "aposentadoria"],
    texto: `${CAB_JEF} — Auxílio-Doença / Aposentadoria por Invalidez

1. O(a) periciando(a) é portador(a) de doença, lesão ou seqüela? Em caso afirmativo, indicar na tabela abaixo: ${TAB_DOENCA}
1.1 Descrever o histórico da(s) patologia(s) do(a) periciando(a):
1.2 Exame físico do(a) periciando(a):
1.3 Descrever exame(s) ou outro(s) documento(s) constantes no processo e apresentados pessoalmente pelo(a) periciando(a), que comprove(m) a(s) doença(s) ou lesão(ões):
2. O(a) periciando(a) já desenvolveu atividades profissionais? Em caso positivo, qual(quais)? Se a profissão foi autônomo, especificar a ocupação preponderante.
2.1 Qual a atividade laboral habitual declarada pelo(a) periciando(a)? Se a profissão for autônomo, especificar a ocupação preponderante.
2.2 Há incapacidade para a atividade descrita no item 2.1 (atividade laboral habitual)? Em caso afirmativo, indicar qual(quais) da(s) moléstia(s) no quadro do item 1 acarreta(m) a incapacidade laboral.
2.3 Há incapacidade para a(s) atividade(s) descrita(s) no item 2 (atividades laborais exercidas anteriormente)? Em caso afirmativo, indicar qual(quais) da(s) moléstia(s) no quadro do item 1 acarreta(m) a incapacidade laboral.
2.4 Caso não seja constatada a incapacidade atual, é possível aferir se o autor já esteve, em período anterior, incapacitado para o trabalho? Em caso positivo, justifique (indicando o período em que houve tal incapacidade, início e fim, bem como em que o perito se embasou para chegar a esta conclusão).
2.5 Caso não tenha sido constatada incapacidade atual, mas - conforme quesito anterior - tenha sido identificada (ou ao menos vislumbrada, por inferência médica) que houve incapacidade anterior, responda o Douto Perito os itens abaixo, marcando logo em seguida a resposta que se melhor se adéqua dentre as opções:
a) essa incapacidade anterior decorreu de "acidente de qualquer natureza"?;
b) dessa incapacidade anterior resultou alguma "sequela" após a consolidação das lesões ocorridas?;
c) em havendo tais sequelas, pode-se falar que o periciando teve redução de sua capacidade quanto ao trabalho que habitualmente exercia antes daquela incapacidade e/ou para o trabalho que exerce atualmente (perda de força, diminuição da mobilidade, dificuldade, dor permanente ou eventual que incida de modo considerável podendo prejudicar a performance do labor, etc)?
Escolha o número do item abaixo que melhor responde as perguntas feitas acima:
1) Não se aplica, pois não houve incapacidade anterior.
2) A incapacidade anterior existiu, mas não decorreu de acidente de qualquer natureza.
3) Decorreu de acidente de qualquer natureza, mas não resultou sequela.
4) Decorreu de acidente de qualquer natureza, bem como resultou sequela, mas não importou redução da capacidade nos termos indagados.
5) Decorreu de incapacidade anterior, oriunda de acidente de qualquer natureza, resultando sequela consolidada, a qual implicou redução da capacidade nos termos indagados.
3. A incapacidade para o trabalho é parcial (impede o exercício da atividade habitual do segurado, sem risco de vida ou agravamento maior, mas permite o exercício em outra pela qual possa sobreviver) ou é total (para toda e qualquer atividade que possa garantir a sua subsistência)? Fundamente.
4. A incapacidade para o trabalho é permanente (definitiva, com quadro irreversível) ou é temporária (há prognóstico de recuperação)? Fundamente.
4.1 Em sendo temporária, qual o prazo estimado pelo perito para que o periciando seja submetido a uma nova avaliação médica acerca da sua capacidade laborativa? Fundamente.
4.2 Em sendo parcial e permanente, há possibilidade de reabilitação profissional, analisando-se, no caso concreto, a sua condição física? Fundamente.
4.3 O(a) periciando(a) já foi submetido(a) à reabilitação profissional pelo INSS? Sendo a resposta positiva, informe para qual função e esclareça se há impedimento para que exerça a profissão para a qual foi reabilitado(a).
5. A incapacidade do(a) periciando(a) é oriunda de acidente de trabalho ou de doença profissional ou do trabalho?
6. O diagnóstico atual foi estabelecido clinicamente ou existe alguma comprovação por exame complementar? Justifique.
7. É possível fixar ou estimar a DATA DE INÍCIO OU A DATA MÍNIMA DA INCAPACIDADE, considerando o histórico da doença e o seu atual estágio de desenvolvimento? Qual? Fundamente (indicando em que o perito judicial se embasou para chegar a esta conclusão).
8. Caso a incapacidade seja permanente e insusceptível de reabilitação para o exercício de outra atividade que lhe garanta a subsistência, o(a) periciando(a) necessita de permanentes cuidados de terceira pessoa para os atos da vida independente (necessita do auxílio permanente de outra pessoa para vestir-se, deslocar-se, alimentar-se, etc)?
9. O(a) periciando(a) está sendo submetido a algum tipo de tratamento e/ou toma algum medicamento? Se a(s) resposta(s) for positiva, qual? Tal medicamento possui efeitos colaterais? Quais?
10. O(a) periciando(a) sofreu acidente ou está acometido de tuberculose ativa, hanseníase, alienação mental, neoplasia maligna, cegueira, paralisia irreversível e incapacitante, cardiopatia grave, doença de Parkinson, espondiloartrose anquilosante, nefropatia grave, estágio avançado de doença de Paget (osteíte deformante), síndrome de deficiência imunológica adquirida (AIDS), contaminação por radiação ou hepatopatia grave?
11. Informe o perito se o(a) periciando(a) possui o necessário discernimento para a prática dos atos da vida civil, tais como a compra e venda e a celebração de contratos em geral.
12. Respostas quesitos autor/réu não contemplados nos itens anteriores:
13. Houve a participação de Assistente Técnico nomeado durante o ato pericial?
13.1 Se SIM, indicar: Nome / Registro
14. Outras anotações:`
  },
  {
    id: "auxacidente", nome: "Auxílio-acidente (JEF-MT)", tags: ["auxacidente", "trabalhista"],
    texto: `${CAB_JEF} — Auxílio-Acidente

1. O(a) periciando(a) é portador(a) de doença, lesão ou seqüelas de acidente? Em caso afirmativo, indicar na tabela abaixo: [Tabela: ESPECIFICAR | DATA DE INÍCIO | CID]
1.1 Se positiva a resposta anterior, esclarecer: o acidente sofrido foi acidente de trabalho?
2. Descrever o histórico da(s) patologia(s) do(a) periciando(a):
3. Exame físico do(a) periciando(a):
4. Descrever exame(s) ou outro(s) documento(s) constantes no processo e apresentados pessoalmente pelo(a) periciando(a), que comprove(m) a(s) doença(s) ou lesão(ões):
5. Houve consolidação das lesões decorrentes do acidente? Justificar.
6. Qual a atividade laboral habitual declarada pelo(a) periciando(a)? Se a profissão for autônomo, especificar a ocupação preponderante.
7. Pode o(a) periciando(a) continuar trabalhando na atividade exercida à época do acidente?
7.1 Em caso positivo, indicar se a realização de tal atividade demanda mais esforço após o acidente que vitimou o periciando, indicando o grau de intensidade.
7.2 O periciando é capaz de exercer atividade laboral diversa da que habitualmente exercia? Justificar.
8. É possível fixar ou estimar a DATA DE INÍCIO OU A DATA MÍNIMA em que houve a redução da capacidade laboral da parte autora, considerando o histórico da doença e o seu atual estágio de desenvolvimento? Qual? Fundamente (indicando em que o perito judicial se embasou para chegar a esta conclusão).
9. As sequelas do acidente são passíveis de cura, ou seja, há possibilidade de reversão do quadro? Fundamente (indicando em que o perito judicial se embasou para chegar a esta conclusão).
10. O(a) periciando(a) está sendo submetido a algum tipo de tratamento e/ou toma algum medicamento? Se a(s) resposta(s) for positiva, qual? Tal medicamento possui efeitos colaterais? Quais?
11. Informe o perito se o(a) periciando(a) possui o necessário discernimento para a prática dos atos da vida civil, tais como a compra e venda e a celebração de contratos em geral.
12. Respostas quesitos autor/réu não contemplados nos itens anteriores:
13. Houve a participação de Assistente Técnico nomeado durante o ato pericial?
13.1 Se SIM, indicar: Nome / Registro
14. Outras anotações:`
  },
  {
    id: "loas", nome: "BPC/LOAS — Pessoa com deficiência (JEF-MT)", tags: ["loas"],
    texto: `${CAB_JEF} — BENEFÍCIO ASSISTENCIAL AO DEFICIENTE

QUESITOS PARA BENEFÍCIO ASSISTENCIAL AO DEFICIENTE
A Lei n. 8.742/93 conceitua deficiência para fins de concessão de benefício assistencial ao deficiente, como o impedimento de longo prazo de natureza física, mental, intelectual ou sensorial, o qual, em interação com uma ou mais barreiras, pode obstruir sua participação plena e efetiva na sociedade em igualdade de condições com as demais pessoas. Como se observa, para a lei o conceito de deficiência e o de incapacidade laboral não se confundem, sendo o primeiro mais abrangente que o segundo. Considerando essas premissas, o perito deverá responder aos seguintes quesitos, de forma fundamentada, com explicação pormenorizada dos fatos observados que ensejaram uma conclusão positiva ou negativa de sua parte:

1. Descreva a história clínica e o exame físico do periciando:
2. O periciando possui impedimento (patologia, deficiência ou lesão) de natureza física, mental, intelectual ou sensorial?
2.1 Se a resposta ao item 1 for positiva, qual o impedimento e qual a sua natureza, indicando o CID?
3. Descreva exame(s) ou outro(s) documentos(s) constantes do processo e apresentados pessoalmente pelo(a) periciando(a) que comprove(m) o(s) impedimento(s) analisado(s):
4. O(a) periciando(a) está sendo atualmente tratado? Faz uso de medicamentos? Se a(s) resposta(s) for positiva, qual?
5. Tal medicamento possui efeitos colaterais? Pode-se aferir se houve melhora em seu quadro clínico desde o início do tratamento?
6. A respeito das condições pessoais e sociais do(a) periciando(a):
a) qual o local de sua residência (cidade e zona urbana ou rural)?
b) qual a sua idade?
c) qual a sua escolaridade?
d) qual(is) a(s) atividade(s) laboral(is) desempenhada(s) pelo(a) periciando(a) atualmente e no passado?
e) o(a) periciando(a) narra a existência de estigmatização social em razão de preconceito contra o impedimento de que ele(a) é portador(a)? Como se dá?
7. Quais as limitações intelectuais, mentais ou físicas a que a pessoa periciada está sujeita em razão do impedimento de que ela é portadora ou do seu tratamento (em relação à cognição, concentração, comunicação, relacionamento interpessoal, esforço físico geral ou de alguma parte do corpo, soerguimento de peso, permanência em determinada posição, exposição ao Sol, movimentos repetitivos, exposição ao ruído etc.)?
8. Essas limitações podem obstruir a sua participação plena e efetiva na sociedade em igualdade de condições com as demais pessoas? Fundamente.
9. A interação desse impedimento com eventuais barreiras relacionadas às condições pessoais e sociais do periciando (idade, escolaridade, qualificação profissional, local de residência, estigmatização social relacionada ao impedimento etc.) pode acarretar prejuízos para que o(a) periciando(a) obtenha trabalho pelo qual possa prover a sua própria manutenção? Fundamente.
10. O(a) periciando(a) possui o necessário discernimento para a prática dos atos da vida civil, tais como a compra e venda e a celebração de contratos em geral?
11. O(a) periciando(a) depende do auxílio de terceiros para a execução de tarefas básicas do cotidiano (como se alimentar, cuidar de sua higiene, vestir-se etc)?
12. Qual a data ou época do início do impedimento? Fundamente.
13. O impedimento é temporário ou permanente? Se for temporário, qual a estimativa de duração desse impedimento a contar da data da perícia?
14. Outras conclusões/anotações:`
  },
  {
    id: "pensao", nome: "Pensão por morte — filho maior inválido (JEF-MT)", tags: ["pensao"],
    texto: `${CAB_JEF} — Pensão por Morte de Filho Maior Inválido

1. O(a) periciando(a) é portador(a) de doença, lesão ou seqüelas de acidente? Em caso afirmativo, indicar na tabela abaixo: [Tabela: ESPECIFICAR | DATA DE INÍCIO | CID]
1.1 Descrever o histórico da(s) patologia(s) do(a) periciando(a):
1.2 Exame físico do(a) periciando(a):
1.3 Descrever exame(s) ou outro(s) documento(s) constantes no processo e apresentados pessoalmente pelo(a) periciando(a), que comprove(m) a(s) doença(s) ou lesão(ões):
2. O(a) periciando(a) já desenvolveu atividades profissionais? Em caso positivo, quais? Se a profissão foi autônomo, especificar a ocupação preponderante.
2.1 Qual a atividade laboral habitual declarada pelo(a) periciando(a)? Se a profissão for autônomo, especificar a ocupação preponderante.
2.2 A(s) enfermidades(s) diagnosticada(s) incapacita(m) o(a) periciando(a) para trabalhar? Fundamente.
3. A incapacidade para o trabalho é parcial (impede o exercício da atividade habitual, mas permite o exercício em outra pela qual possa sobreviver) ou é total (para toda e qualquer atividade que possa garantir a sua subsistência)? Fundamente.
4. A incapacidade para o trabalho é permanente (definitiva, com quadro irreversível) ou é temporária (há prognóstico de recuperação)? Fundamente.
4.1 Em sendo temporária, qual o prazo estimado pelo perito para que o periciando seja submetido a uma nova avaliação médica acerca da sua capacidade laborativa? Fundamente.
5. É possível fixar ou estimar a DATA DE INÍCIO OU A DATA MÍNIMA DA INCAPACIDADE, considerando o histórico da doença e o seu atual estágio de desenvolvimento? Qual? Fundamente.
5.1 Existindo incapacidade, é possível afirmar se ela surgiu antes de o(a) periciando(a) completar vinte e um anos?
6. O(a) periciando(a) está sendo submetido a algum tipo de tratamento e/ou toma algum medicamento? Se a(s) resposta(s) for positiva, qual? Tal medicamento possui efeitos colaterais? Quais?
7. Informe o perito se o(a) periciando(a) possui o necessário discernimento para a prática dos atos da vida civil, tais como a compra e venda e a celebração de contratos em geral.
8. Respostas quesitos autor/réu não contemplados nos itens anteriores:
9. Houve a participação de Assistente Técnico nomeado durante o ato pericial?
9.1 Se SIM, indicar: Nome / Registro
10. Outras anotações:`
  },
  {
    id: "acrescimo", nome: "Acréscimo de 25% na aposentadoria por invalidez (JEF-MT)", tags: ["acrescimo"],
    texto: `${CAB_JEF} — Acréscimo de 25% na Aposentadoria por Invalidez

1. O(a) periciando(a) é portador(a) de doença, lesão ou seqüela? Em caso afirmativo, indicar na tabela abaixo: ${TAB_DOENCA}
1.1 Descrever o histórico da(s) patologia(s) do(a) periciando(a):
1.2 Exame físico do(a) periciando(a):
1.3 Descrever exame(s) ou outro(s) documento(s) constantes no processo e apresentados pessoalmente pelo(a) periciando(a), que comprove(m) a(s) doença(s) ou lesão(ões):
2. O(a) periciando(a) é incapaz para a vida independente (necessita do auxílio permanente de outra pessoa para vestir-se, deslocar-se, alimentar-se, etc)?
2.1 Se a resposta ao quesito anterior for positiva, é possível FIXAR A DATA DO INÍCIO OU A DATA MÍNIMA da necessidade do acompanhamento de outra pessoa? Fundamente (indicando em que o perito judicial se embasou para chegar a esta conclusão).
3. O(a) periciando(a) está sendo submetido a algum tipo de tratamento e/ou toma algum medicamento? Se a(s) resposta(s) for positiva, qual? Tal medicamento possui efeitos colaterais? Quais?
4. Informe o perito se o(a) periciando(a) possui o necessário discernimento para a prática dos atos da vida civil, tais como a compra e venda e a celebração de contratos em geral.
5. Respostas quesitos autor/réu não contemplados nos itens anteriores:
6. Houve a participação de Assistente Técnico nomeado durante o ato pericial?
6.1 Se SIM, indicar: Nome / Registro
7. Outras anotações:`
  },
  {
    id: "ir", nome: "Isenção de IR — doença grave (Lei 7.713/88)", tags: ["ir"],
    texto: `Quesitos do Juízo:
1. O autor é ou foi portador de doença(s)? Em caso afirmativo, qual(is)? Descrever nome e CID. Tal patologia está prevista no inciso XIV, do art. 6º da Lei nº 7.713/88?
2. Qual a data estimada do início da(s) doença(s) ou do diagnóstico? Justifique.
3. Existe prognóstico de cura? Qual o prazo para que o autor seja submetido a novo exame?
4. Não sendo atualmente o requerente portador da enfermidade alegada, já esteve acometido em momento anterior? Qual data aproximada em que deixou de ser portador da doença?`
  },
  {
    id: "corpodelito", nome: "Exame de corpo de delito — lesão corporal (quesitos oficiais)", tags: ["corpodelito"],
    texto: `EXAME DE CORPO DE DELITO — LESÃO CORPORAL
Quesitos oficiais (correspondem às qualificadoras do art. 129 do Código Penal). Nos quesitos marcados com “resposta especificada”, descreva qual membro, sentido ou função, ou qual deformidade.

1º) Há ofensa à integridade corporal ou à saúde do(a) examinado(a)?
2º) Qual o instrumento ou meio que produziu a ofensa?
3º) Foi produzida por meio de veneno, fogo, explosivo, asfixia ou tortura, ou por outro meio insidioso ou cruel? (resposta especificada)
4º) Resultou incapacidade para as ocupações habituais por mais de trinta dias?
5º) Resultou perigo de vida?
6º) Resultou debilidade permanente de membro, sentido ou função? (resposta especificada)
7º) Resultou aceleração de parto?
8º) Resultou incapacidade permanente para o trabalho, ou enfermidade incurável? (resposta especificada)
9º) Resultou perda ou inutilização de membro, sentido ou função? (resposta especificada)
10º) Resultou deformidade permanente? (resposta especificada)
11º) Resultou aborto?`
  },
  {
    id: "internacao", nome: "Internação compulsória / involuntária (Lei 10.216/2001) — modelo base", tags: ["internacao"], base: true,
    texto: `MODELO BASE — revise e ajuste conforme os quesitos do seu Juízo.

1. O(a) periciando(a) é portador(a) de transtorno mental e/ou de transtorno por uso de substâncias psicoativas? Qual(is), com CID-10?
2. Descreva o histórico clínico, os tratamentos prévios (ambulatoriais, CAPS, internações) e a adesão a eles.
3. O quadro atual compromete a capacidade de autodeterminação e o juízo crítico do(a) periciando(a) quanto à sua doença e à necessidade de tratamento?
4. Há risco atual à integridade física do(a) próprio(a) periciando(a) e/ou de terceiros? Fundamente.
5. Os recursos extra-hospitalares (CAPS, ambulatório, Rede de Atenção Psicossocial) mostraram-se insuficientes (art. 4º da Lei 10.216/2001)?
6. Há indicação médica de internação? Em caso positivo, em qual modalidade (voluntária, involuntária ou compulsória) e por qual prazo estimado?
7. Qual tipo de estabelecimento é adequado ao caso (hospital geral, hospital psiquiátrico, unidade especializada) observando o art. 4º, §§ 2º e 3º, da Lei 10.216/2001?
8. Existem alternativas terapêuticas menos restritivas e igualmente eficazes?
9. O(a) periciando(a) possui discernimento para a prática dos atos da vida civil?
10. Qual o prognóstico e quais as condições necessárias para alta ou reavaliação?
11. Outras considerações.`
  }
];

const BENEFICIOS = [
  ["auxdoenca", "Auxílio por incapacidade temporária (auxílio-doença)"],
  ["aposentadoria", "Aposentadoria por incapacidade permanente (invalidez)"],
  ["auxacidente", "Auxílio-acidente"],
  ["loas", "BPC/LOAS — pessoa com deficiência"],
  ["pensao", "Pensão por morte — filho maior inválido"],
  ["acrescimo", "Acréscimo de 25% na aposentadoria"],
  ["ir", "Isenção de IR — doença grave"],
  ["internacao", "Internação compulsória / involuntária"],
  ["trabalhista", "Trabalhista (TRT) — acidente / doença ocupacional"],
  ["corpodelito", "Exame de corpo de delito — lesão corporal"],
  ["outro", "Outro"]
];

/* ===================== CAMPOS DOS FORMULÁRIOS ===================== */
/* [chave, rótulo, tipo, opções] ; tipos: text, area, date, time, sel, yn */
const F_PROCESSO = [
  ["numero", "Nº do processo", "text"],
  ["juizo", "Juízo / Juizado / Vara", "text"],
  ["beneficio", "Natureza / benefício em discussão", "sel", [["", "— selecione —"], ...BENEFICIOS]],
  ["natureza", "Natureza da ação (descrição livre)", "text"],
  ["autor", "Parte autora / reclamante", "text"],
  ["reu", "Parte ré / reclamada (INSS, União, empresa…)", "text"],
  ["local", "Local da perícia", "text"],
  ["data", "Data da perícia", "date"],
  ["horario", "Horário do agendamento", "time"],
  ["telemedicina", "Perícia por telemedicina?", "yn"],
  ["ausencia", "Ausência da parte pericianda?", "yn"],
  ["foiPaciente", "A parte foi paciente do(a) perito(a)?", "yn"],
  ["assistente", "Houve comparecimento de assistente técnico?", "yn"],
  ["assistenteNome", "Assistente técnico — nome", "text"],
  ["assistenteCRM", "Assistente técnico — CRM", "text"],
  ["assistenteEsp", "Assistente técnico — especialidade", "text"],
  ["presentes", "1.12. Presentes na perícia", "text"]
];

const F_PERICIANDO = [
  ["nome", "1.2. Periciando(a) — nome completo", "text"],
  ["nomeSocial", "Nome social", "text"],
  ["cpf", "1.3. CPF", "text"],
  ["rg", "1.4. Identidade (RG)", "text"],
  ["orgao", "Órgão expedidor / UF", "text"],
  ["nasc", "1.5. Data de nascimento", "date"],
  ["idade", "1.6. Idade (calculada na data da perícia)", "text"],
  ["sexo", "Sexo biológico", "sel", [["", "—"], ["Feminino", "Feminino"], ["Masculino", "Masculino"]]],
  ["genero", "Identidade de gênero", "text"],
  ["raca", "Raça/Cor", "text"],
  ["estadoCivil", "1.7. Estado civil", "text"],
  ["mae", "1.8. a) Mãe", "text"],
  ["pai", "1.8. b) Pai", "text"],
  ["escolaridade", "1.9. Escolaridade", "text"],
  ["profissao", "Profissão / formação técnico-profissional", "text"],
  ["ocupacao", "1.10. Ocupação atual (atividade laboral declarada)", "text"],
  ["atividadesAnteriores", "Outras atividades já exercidas", "area"],
  ["endereco", "1.11. Endereço (cidade, zona urbana/rural)", "text"],
  ["telefone", "Telefone", "text"],
  ["email", "E-mail", "text"],
  ["afastamentos", "Afastamentos / benefícios anteriores (datas)", "area"],
  ["reabilitacao", "Já passou por reabilitação profissional? Para qual atividade?", "text"]
];

const F_ANAMNESE = [
  ["cid", "2.1. Doença / CID-10", "area"],
  ["inicio", "2.2. Início da doença", "text"],
  ["localizacao", "2.3. Localização da doença, lesão ou dor", "text"],
  ["sintomas", "2.4. Descrição da dor e/ou dos sintomas principais", "area"],
  ["evolucao", "2.5. Tempo de evolução", "text"],
  ["melhora", "2.6. Fatores de melhora dos sintomas", "text"],
  ["piora", "2.7. Fatores de piora dos sintomas", "text"],
  ["comorbidades", "2.8. Comorbidades associadas", "area"],
  ["medicacoes", "2.9. Medicações em uso atual", "area"],
  ["repouso", "2.10. a) Ficou de repouso?", "text"],
  ["repousoPeriodo", "2.10. b) Período de repouso", "text"],
  ["internacao", "2.10. c) Houve internação?", "text"],
  ["internacaoData", "2.10. d) Data ou período da internação", "text"],
  ["cirurgia", "2.10. e) Houve cirurgia?", "text"],
  ["cirurgiaTipo", "2.10. f) Tipo de cirurgia realizada", "text"],
  ["cirurgiaData", "2.10. g) Data da cirurgia", "text"],
  ["tratamentos", "2.11. Tratamentos realizados ou em andamento", "area"],
  ["atividadesTrabalho", "2.12. Atividades realizadas no trabalho", "area"],
  ["dominante", "2.13. Membro dominante", "sel", [["", "—"], ["Destro", "Destro"], ["Canhoto", "Canhoto"], ["Ambidestro", "Ambidestro"]]],
  ["historiaLivre", "Relato complementar (livre)", "area"]
];

const FUNC_OPTS = ["Independente", "Independente com dificuldade", "Necessita de auxílio parcial", "Dependente", "Não avaliado"];

const F_EXAME = [
  ["#", "3.1. Exame físico geral"],
  ["estadoGeral", "a) Estado geral", "text"],
  ["consciencia", "b) Nível de consciência", "text"],
  ["orientacao", "c) Orientação no tempo e espaço", "text"],
  ["marcha", "d) Marcha", "text"],
  ["postura", "e) Postura", "text"],
  ["cooperacao", "f) Cooperação durante o exame", "text"],
  ["#", "3.2. Exame físico do segmento acometido"],
  ["segmento", "a) Local / segmento corporal avaliado", "text"],
  ["inspecao", "b) Inspeção", "area"],
  ["palpacao", "c) Palpação", "area"],
  ["movPassiva", "d) Movimentação passiva", "area"],
  ["movAtiva", "e) Movimentação ativa", "area"],
  ["forca", "f) Força muscular", "text"],
  ["sensibilidade", "g) Sensibilidade", "text"],
  ["reflexos", "h) Reflexos, quando aplicável", "text"],
  ["testes", "i) Testes especiais realizados, quando aplicável", "area"],
  ["testesResultado", "j) Resultado dos testes especiais", "area"],
  ["#", "3.3. Exame mental e comportamental"],
  ["aparencia", "a) Aparência e higiene", "text"],
  ["atitude", "b) Atitude perante o examinador", "text"],
  ["contatoVisual", "c) Contato visual", "text"],
  ["humor", "d) Humor", "text"],
  ["afeto", "e) Afeto", "text"],
  ["fala", "f) Fala e linguagem", "text"],
  ["pensamento", "g) Pensamento", "text"],
  ["percepcao", "h) Percepção", "text"],
  ["memoria", "i) Memória", "text"],
  ["atencao", "j) Atenção e concentração", "text"],
  ["juizo", "k) Juízo crítico", "text"],
  ["compreensao", "l) Capacidade de compreensão das perguntas", "text"],
  ["comportamento", "m) Comportamento durante a perícia", "text"],
  ["#", "3.4. Avaliação funcional"],
  ["alimentar", "a) Alimentar-se", "func"],
  ["higiene", "b) Realizar higiene pessoal", "func"],
  ["vestir", "c) Vestir-se", "func"],
  ["banhar", "d) Banhar-se", "func"],
  ["deambular", "e) Deambular", "func"],
  ["emPe", "f) Permanecer em pé", "func"],
  ["sentado", "g) Permanecer sentado", "func"],
  ["escadas", "h) Subir e descer escadas", "func"],
  ["agachar", "i) Agachar-se", "func"],
  ["ajoelhar", "j) Ajoelhar-se", "func"],
  ["carregar", "k) Carregar peso", "func"],
  ["repetitivos", "l) Realizar movimentos repetitivos", "func"],
  ["laborais", "m) Executar atividades laborais habituais", "func"]
];

const QUESITO_GRUPOS = [
  ["juizoExtra", "Quesitos do Juízo (adicionais ou colados dos autos)", "Use quando o juízo formulou quesitos próprios além do modelo selecionado acima."],
  ["assistente", "Assistente técnico / médico assistente", "Serão respondidos logo após os quesitos do juízo."],
  ["mp", "Ministério Público / Promotor(a)", ""],
  ["autor", "Parte autora / advogado(a) do autor", ""],
  ["reu", "Parte ré (INSS, União, reclamada) / advogado(a)", ""],
  ["outros", "Outros quesitos", ""]
];

/* ===================== TESTES ESPECIAIS (biblioteca enxuta) ===================== */
/* segmento: { nome, kw (palavras na queixa/CID), cid (prefixos CID-10), testes: [id, nome, como executar, positivo indica] } */
const TESTES = {
  coluna_cervical: { nome: "Coluna cervical", kw: ["cervical", "cervicalgia", "pescoço", "cervicobraquialgia"], cid: ["M50", "M54.1", "M54.2", "M47.1", "M47.2", "M48.0"], testes: [
    ["spurling", "Spurling (compressão foraminal)", "Sentado; extensão e inclinação da cabeça para o lado sintomático com compressão axial suave.", "Dor irradiada ao membro superior: sugere radiculopatia cervical."],
    ["distracao", "Distração cervical", "Sentado; tração axial suave da cabeça.", "Alívio da dor irradiada: reforça origem radicular/foraminal."],
    ["ulnt1", "Tensão neural do membro superior (ULNT1)", "Depressão escapular, abdução do ombro, supinação, extensão de punho e dedos, extensão do cotovelo e inclinação cervical contralateral.", "Reprodução dos sintomas modulada pela cervical: mecanossensibilidade neural."]
  ]},
  coluna_lombar: { nome: "Coluna lombar", kw: ["lombar", "lombalgia", "ciática", "ciatalgia", "lombociatalgia", "hérnia de disco", "discopatia", "coluna"], cid: ["M51", "M54.3", "M54.4", "M54.5", "M47", "M48", "M53"], testes: [
    ["lasegue", "Lasègue (elevação da perna estendida)", "Decúbito dorsal; elevação passiva do membro inferior com o joelho estendido. Registrar o ângulo.", "Dor irradiada abaixo do joelho entre 30° e 70°: sugere radiculopatia L5/S1."],
    ["lasegue_x", "Lasègue cruzado", "Elevação do membro inferior assintomático.", "Dor irradiada no membro sintomático: alta especificidade para hérnia discal."],
    ["slump", "Slump test", "Sentado; flexão torácica e cervical, extensão do joelho e dorsiflexão do tornozelo.", "Sintomas reproduzidos e aliviados pela extensão cervical: tensão neural."],
    ["schober", "Schober modificado", "Marcar a junção lombossacra e 10 cm acima; medir em flexão máxima. Registrar em cm.", "Aumento inferior a 5 cm: restrição da mobilidade lombar."],
    ["waddell", "Sinais de Waddell", "Avaliar 5 categorias: dor superficial/não anatômica, simulação (compressão axial, rotação em bloco), distração (Lasègue sentado), alterações regionais não anatômicas, reação exagerada.", "3 ou mais categorias positivas: componente não orgânico. Isoladamente não indica simulação."]
  ]},
  ombro: { nome: "Ombro", kw: ["ombro", "manguito", "supraespinal", "supraespinhal", "bursite", "impacto", "capsulite"], cid: ["M75", "S43", "S46"], testes: [
    ["neer", "Neer", "Elevação passiva do braço em rotação interna com a escápula estabilizada.", "Dor: impacto subacromial."],
    ["hawkins", "Hawkins-Kennedy", "Ombro e cotovelo a 90°; rotação interna passiva.", "Dor: impacto subacromial."],
    ["jobe", "Jobe (lata vazia)", "Abdução a 90° no plano escapular, polegares para baixo; resistir à força para baixo.", "Dor ou fraqueza: lesão do supraespinal."],
    ["patte", "Patte", "Abdução e cotovelo a 90°; rotação externa contra resistência.", "Fraqueza ou dor: lesão do infraespinal."],
    ["gerber", "Gerber (lift-off)", "Dorso da mão na região lombar; afastar a mão das costas.", "Incapacidade de afastar: lesão do subescapular."],
    ["speed", "Speed", "Flexão do ombro contra resistência, cotovelo estendido e antebraço supinado.", "Dor no sulco bicipital: tendinopatia da cabeça longa do bíceps."],
    ["droparm", "Queda do braço (drop arm)", "Levar a 90° de abdução e pedir descida lenta.", "Queda abrupta ou dor intensa: rotura do manguito rotador."]
  ]},
  cotovelo: { nome: "Cotovelo", kw: ["cotovelo", "epicondilite", "epicôndilo"], cid: ["M77.0", "M77.1", "S53"], testes: [
    ["cozen", "Cozen", "Cotovelo fletido, antebraço pronado; extensão do punho contra resistência.", "Dor no epicôndilo lateral: epicondilite lateral."],
    ["mill", "Mill", "Extensão passiva do cotovelo com pronação e flexão do punho.", "Dor no epicôndilo lateral: epicondilite lateral."],
    ["epimedial", "Teste para epicondilite medial", "Supinação e extensão passiva de cotovelo e punho.", "Dor no epicôndilo medial: epicondilite medial."]
  ]},
  punho_mao: { nome: "Punho e mão", kw: ["punho", "mão", "túnel do carpo", "carpo", "quervain", "gatilho", "dedo", "parestesia nas mãos"], cid: ["G56.0", "M65.3", "M65.4", "M18", "S62", "S63"], testes: [
    ["phalen", "Phalen", "Flexão máxima dos punhos por 60 segundos.", "Parestesia no território do mediano: síndrome do túnel do carpo."],
    ["tinel", "Tinel no túnel do carpo", "Percussão sobre o nervo mediano no punho.", "Choque ou parestesia irradiada aos dedos: neuropatia do mediano."],
    ["durkan", "Durkan (compressão do carpo)", "Compressão digital sobre o túnel do carpo por 30 segundos.", "Parestesia no território do mediano: túnel do carpo."],
    ["finkelstein", "Finkelstein", "Polegar fletido dentro da mão fechada; desvio ulnar do punho.", "Dor no estiloide radial: tenossinovite de De Quervain."]
  ]},
  quadril: { nome: "Quadril", kw: ["quadril", "coxartrose", "trocanter", "trocantérica", "virilha"], cid: ["M16", "M70.6", "M70.7", "S72", "S73"], testes: [
    ["faber", "FABER (Patrick)", "Flexão, abdução e rotação externa (figura de 4) com pressão no joelho.", "Dor inguinal: afecção do quadril. Dor posterior: sacroilíaca."],
    ["trendelenburg", "Trendelenburg", "Apoio unipodal por 30 segundos observando a pelve.", "Queda da pelve contralateral: fraqueza do glúteo médio."],
    ["thomas", "Thomas", "Decúbito dorsal; flexão máxima de um quadril, observar o outro.", "Elevação da coxa contralateral: contratura em flexão do quadril."]
  ]},
  joelho: { nome: "Joelho", kw: ["joelho", "menisco", "ligamento cruzado", "gonartrose", "condromalácia", "patela"], cid: ["M17", "M22", "M23", "S83", "S82"], testes: [
    ["lachman", "Lachman", "Joelho a 20–30°; tração anterior da tíbia com fêmur estabilizado.", "Translação aumentada sem ponto final firme: lesão do LCA."],
    ["gaveta_a", "Gaveta anterior", "Joelho a 90°, pé fixo; tração anterior da tíbia.", "Translação anterior aumentada: lesão do LCA."],
    ["gaveta_p", "Gaveta posterior", "Joelho a 90°; empurrar a tíbia posteriormente.", "Translação posterior aumentada: lesão do LCP."],
    ["mcmurray", "McMurray", "Flexão máxima com rotação da tíbia e extensão progressiva.", "Estalido doloroso na interlinha: lesão meniscal."],
    ["apley", "Apley (compressão)", "Decúbito ventral, joelho a 90°; compressão axial com rotação.", "Dor na interlinha: lesão meniscal."],
    ["valgovaro", "Estresse em valgo e varo", "Joelho a 0° e 30°; força em valgo e em varo.", "Abertura ou dor medial/lateral: lesão do LCM ou LCL."]
  ]},
  tornozelo_pe: { nome: "Tornozelo e pé", kw: ["tornozelo", "pé", "entorse", "aquiles", "calcâneo", "fascite", "plantar"], cid: ["M72.2", "M76.6", "S82.5", "S82.6", "S93", "M77.3"], testes: [
    ["gaveta_t", "Gaveta anterior do tornozelo", "Estabilizar a tíbia e tracionar o calcâneo anteriormente.", "Translação aumentada: lesão do ligamento talofibular anterior."],
    ["thompson", "Thompson", "Decúbito ventral; compressão da panturrilha.", "Ausência de flexão plantar: rotura do tendão calcâneo."],
    ["windlass", "Windlass", "Em pé; dorsiflexão passiva do hálux.", "Dor na inserção da fáscia plantar: fasciopatia plantar."]
  ]},
  neurologico: { nome: "Neurológico e equilíbrio", kw: ["neuropatia", "parestesia", "fraqueza", "equilíbrio", "tontura", "avc", "instabilidade", "marcha", "câimbra", "dormência"], cid: ["G", "I63", "I64", "I69", "R26", "R42"], testes: [
    ["romberg", "Romberg", "Em pé, pés juntos, olhos abertos e depois fechados por 30 segundos.", "Perda de equilíbrio só com olhos fechados: ataxia sensitiva."],
    ["tandem", "Marcha em tandem", "Caminhar em linha reta, calcanhar encostado nos dedos do outro pé.", "Desvios ou quedas: alteração de equilíbrio ou cerebelar."],
    ["indexnariz", "Índex-nariz", "Tocar alternadamente o nariz e o dedo do examinador.", "Dismetria ou tremor de intenção: disfunção cerebelar."],
    ["babinski", "Babinski", "Estímulo na borda lateral da planta, do calcanhar aos dedos.", "Extensão do hálux: lesão do trato corticoespinal."],
    ["hoffmann", "Hoffmann", "Flexão brusca da falange distal do 3º dedo.", "Flexão do polegar e do indicador: liberação piramidal."]
  ]},
  abdome: { nome: "Abdome", kw: ["abdominal", "abdome", "barriga", "apendicite", "vesícula", "hérnia", "dor abdominal"], cid: ["K", "R10", "N20", "N23"], testes: [
    ["blumberg", "Blumberg", "Compressão lenta e descompressão brusca no ponto de McBurney.", "Dor à descompressão: irritação peritoneal."],
    ["murphy", "Murphy", "Palpação profunda no ponto cístico durante inspiração profunda.", "Interrupção da inspiração por dor: colecistite."],
    ["giordano", "Giordano", "Punho-percussão no ângulo costovertebral.", "Dor: afecção renal (pielonefrite, litíase)."],
    ["rovsing", "Rovsing", "Compressão da fossa ilíaca esquerda.", "Dor na fossa ilíaca direita: apendicite."]
  ]}
};
const TEST_RES = ["Positivo", "Negativo", "Não realizado"];

/* Medidas funcionais objetivas */
const MEDIDAS = [
  ["dinamometria", "Dinamometria de preensão (Jamar)", "kgf", true, "Comparar direita × esquerda e com valores normativos por idade e sexo."],
  ["tug", "Timed Up and Go", "s", false, "Acima de 12 s sugere risco aumentado de quedas (idosos)."],
  ["sts5", "Sentar e levantar 5 vezes", "s", false, "Acima de 15 s sugere redução de força de membros inferiores."],
  ["perimetria", "Perimetria (circunferência)", "cm", true, "Diferença entre os lados sugere edema ou hipotrofia. Informar o nível medido em observação."]
];

/* Goniometria — valores de referência AAOS: [id, movimento, referência em graus, axial (um só valor)] */
const GONIO = {
  cervical: { nome: "Coluna cervical", mov: [["flex", "Flexão", 45, 1], ["ext", "Extensão", 45, 1], ["incl", "Inclinação lateral", 45], ["rot", "Rotação", 60]] },
  lombar: { nome: "Coluna toracolombar", mov: [["flex", "Flexão", 80, 1], ["ext", "Extensão", 25, 1], ["incl", "Inclinação lateral", 35], ["rot", "Rotação", 45]] },
  ombro: { nome: "Ombro", mov: [["flex", "Flexão", 180], ["ext", "Extensão", 60], ["abd", "Abdução", 180], ["re", "Rotação externa", 90], ["ri", "Rotação interna", 70]] },
  cotovelo: { nome: "Cotovelo e antebraço", mov: [["flex", "Flexão", 150], ["pron", "Pronação", 80], ["sup", "Supinação", 80]] },
  punho: { nome: "Punho", mov: [["flex", "Flexão", 80], ["ext", "Extensão", 70], ["rad", "Desvio radial", 20], ["uln", "Desvio ulnar", 30]] },
  quadril: { nome: "Quadril", mov: [["flex", "Flexão", 120], ["ext", "Extensão", 30], ["abd", "Abdução", 45], ["adu", "Adução", 30], ["ri", "Rotação interna", 45], ["re", "Rotação externa", 45]] },
  joelho: { nome: "Joelho", mov: [["flex", "Flexão", 135]] },
  tornozelo: { nome: "Tornozelo", mov: [["dorsi", "Dorsiflexão", 20], ["plant", "Flexão plantar", 50], ["inv", "Inversão", 35], ["ever", "Eversão", 15]] }
};
const GONIO_SEG = { coluna_cervical: "cervical", coluna_lombar: "lombar", ombro: "ombro", cotovelo: "cotovelo", punho_mao: "punho", quadril: "quadril", joelho: "joelho", tornozelo_pe: "tornozelo" };

const DEFAULT_PADRAO = { titulo: "PERÍCIAS MÉDICAS" };
const DEFAULT_PROFILE_PERITO = { nome: "", titulo: "PERÍCIAS MÉDICAS", linha2: "", crm: "", especialidade: "", qualificacoes: "", contato: "", cidade: "", logo: null };

const tierFor = (id, base, vel) => {
  base = base || "default";
  if (vel === "max") return base;
  const keep = ["conclusao", "quesitosJuizo", "imagem"];
  if (vel === "rapido") return id === "ocr" ? "default" : keep.includes(id) ? "default" : base === "complex" ? "default" : "quick";
  return base === "complex" && !keep.includes(id) ? "default" : base;
};

/* Texto enviado à IA: só as páginas escolhidas e sem cabeçalhos/rodapés repetidos (PJe, carimbos de assinatura). */
const prepDocText = (text, pagSel) => {
  let t = String(text || "");
  if (pagSel && /\d/.test(pagSel)) {
    const want = new Set();
    for (const part of String(pagSel).split(/[,;]+/)) {
      const m = /^\s*(\d+)\s*(?:-\s*(\d+))?\s*$/.exec(part); if (!m) continue;
      const a = Math.min(+m[1], +(m[2] || m[1])), b = Math.max(+m[1], +(m[2] || m[1]));
      for (let p = a; p <= b && p - a < 5000; p++) want.add(p);
    }
    if (want.size && /^--- página \d+ ---$/m.test(t)) t = t.split(/(?=^--- página \d+ ---$)/m).filter(pg => { const m = /^--- página (\d+) ---/.exec(pg); return !m || want.has(+m[1]); }).join("");
  }
  const lines = t.split("\n"), freq = new Map();
  const RODAPE = /(assinado eletronicamente|documento assinado|num\.\s*\d|p[áa]g\.\s*\d|fls?\.\s*\d|id\.?\s*\d{5,}|https?:\/\/|pje|processo judicial eletr[ôo]nico|este documento foi gerado|c[óo]digo de verifica)/i;
  const key = l => { const k = l.trim(); return RODAPE.test(k) ? "§" + k.replace(/\d+/g, "#") : k; };
  for (const l of lines) { const k = key(l); if (k.length >= 12 && k.length < 260 && !k.startsWith("--- página")) freq.set(k, (freq.get(k) || 0) + 1); }
  const seen = new Set(), out = []; let blank = 0;
  for (const l of lines) {
    const k = key(l);
    if (!k.startsWith("--- página") && (freq.get(k) || 0) >= 3) { if (k.startsWith("§") || seen.has(k)) continue; seen.add(k); }   // carimbos saem; repetições mantêm só a 1ª
    if (!l.trim()) { if (++blank > 1) continue; } else blank = 0;
    out.push(l.replace(/[ \t]{2,}/g, " "));
  }
  return out.join("\n").trim();
};


/* ===================== MÓDULOS DE ANAMNESE E EXAME (cada perito pode editar, criar e excluir) ===================== */
const DEFAULT_MODULOS = [
  { id: "geral", nome: "Geral", texto: "Anamnese: queixa principal, história da moléstia atual, antecedentes pessoais e familiares, hábitos (tabagismo, etilismo, outras substâncias), medicações em uso, tratamentos e afastamentos.\nExame: estado geral, sinais vitais (PA, FC, FR, temperatura, SpO2), peso, altura e IMC, hidratação, mucosas, nível de consciência, orientação, marcha e postura." },
  { id: "osteo_coluna", nome: "Osteomuscular — coluna", texto: "Anamnese: dor axial ou irradiada, trajeto, fatores de piora e melhora, limitação funcional, tratamentos (fisioterapia, infiltração, cirurgia).\nExame: inspeção (curvaturas, postura), palpação (contratura, pontos dolorosos), mobilidade cervical/lombar (goniometria, Schober), Lasègue/Slump, Spurling quando cervical, força, sensibilidade e reflexos dos membros, marcha (pontas e calcanhares), sinais de Waddell quando indicado." },
  { id: "osteo_ms", nome: "Osteomuscular — membros superiores", texto: "Anamnese: dor, parestesias, perda de força ou de destreza, dominância, atividades repetitivas no trabalho.\nExame: inspeção (trofismo, deformidades, cicatrizes), palpação, goniometria de ombro, cotovelo e punho, força (MRC) e preensão (dinamometria), testes especiais (Neer, Hawkins, Jobe, Phalen, Tinel, Finkelstein, Cozen conforme o caso), sensibilidade por território." },
  { id: "osteo_mi", nome: "Osteomuscular — membros inferiores", texto: "Anamnese: dor, falseio, travamento, limitação para marcha, escadas e agachamento, uso de órteses.\nExame: inspeção, perimetria comparativa, palpação, goniometria de quadril, joelho e tornozelo, estabilidade ligamentar, testes meniscais, força (MRC), marcha (claudicação, apoio monopodal), Timed Up and Go quando indicado." },
  { id: "neuro", nome: "Neurológica", texto: "Anamnese: cefaleia, crises convulsivas, déficits motores ou sensitivos, parestesias, tontura, alterações de marcha, de fala ou de deglutição, evolução e tratamentos.\nExame: consciência (Glasgow quando aplicável), nervos cranianos, força segmentar (MRC), tônus, trofismo, reflexos profundos e cutâneo-plantar, sensibilidade (tátil, dolorosa, vibratória e proprioceptiva), coordenação (índex-nariz, calcanhar-joelho, diadococinesia), equilíbrio (Romberg), marcha e sinais meníngeos." },
  { id: "snc", nome: "Sistema nervoso central / cognição", texto: "Anamnese: queixas de memória, atenção, linguagem, orientação e funções executivas; eventos como AVC, TCE ou infecções do SNC; repercussão nas atividades diárias; informante.\nExame: orientação, atenção, memória imediata e tardia, linguagem (compreensão, nomeação, repetição), praxias, gnosias e funções executivas; instrumentos de rastreio quando aplicados (por exemplo, Mini-Exame do Estado Mental, fluência verbal); escala de Rankin modificada para sequelas." },
  { id: "psiq", nome: "Psiquiátrica — exame do estado mental", texto: "Anamnese: sintomas, início e curso, gatilhos, tratamentos e adesão, internações, uso de substâncias, ideação ou tentativas de suicídio, funcionamento social, familiar e laboral, informante.\nExame do estado mental: aparência e higiene, atitude, consciência, orientação, atenção, memória, sensopercepção, pensamento (curso, forma e conteúdo), humor e afeto, psicomotricidade, juízo crítico e insight, inteligência estimada." },
  { id: "cardio", nome: "Cardiovascular", texto: "Anamnese: dispneia (classe funcional NYHA), dor torácica, palpitações, síncope, edema, fatores de risco.\nExame: PA, FC e ritmo, ausculta cardíaca, pulsos periféricos, turgência jugular, edema, sinais de insuficiência cardíaca; exames: ECG, ecocardiograma (fração de ejeção), teste ergométrico." },
  { id: "resp", nome: "Respiratória", texto: "Anamnese: dispneia (escala mMRC), tosse, expectoração, sibilância, tabagismo (anos-maço), exposições ocupacionais.\nExame: FR, SpO2, padrão respiratório, ausculta pulmonar; exames: espirometria (VEF1, CVF, VEF1/CVF), imagem de tórax." },
  { id: "abd", nome: "Abdominal / digestiva", texto: "Anamnese: dor abdominal, alterações do hábito intestinal, náuseas, vômitos, perda de peso, cirurgias, estomias.\nExame: inspeção (cicatrizes, hérnias, estomias), ausculta, palpação (dor, massas, visceromegalias), sinais de irritação peritoneal (Blumberg), Giordano." },
  { id: "oftalmo", nome: "Oftalmológica", texto: "Anamnese: baixa visual, início, tratamentos, uso de correção óptica.\nExame/documentos: acuidade visual com e sem correção em cada olho (tabela de Snellen), campo visual, biomicroscopia e fundo de olho conforme laudo do oftalmologista." },
  { id: "otorrino", nome: "Auditiva / otorrinolaringológica", texto: "Anamnese: perda auditiva, zumbido, vertigem, otorreia, exposição a ruído.\nExame/documentos: otoscopia, audiometria tonal e vocal (limiares por frequência), impedanciometria, uso de prótese auditiva." },
  { id: "derm", nome: "Dermatológica / cicatrizes", texto: "Anamnese: lesões, início, evolução, tratamentos, prurido, relação com o trabalho.\nExame: localização anatômica, tipo, dimensões em centímetros, coloração, aderência, retrações e repercussão funcional das cicatrizes; em queimaduras, extensão estimada da superfície corporal." },
  { id: "lesoes", nome: "Lesões traumáticas (corpo de delito)", texto: "Histórico do evento segundo o examinado (data, hora, meio ou instrumento referido).\nExame: descrever cada lesão com tipo (escoriação, equimose, hematoma, ferida contusa, incisa, perfurocontusa etc.), localização anatômica precisa, forma, dimensões em centímetros, coloração (cronologia da equimose), sinais de reação vital, compatibilidade com o meio referido e repercussão funcional." }
];
/* módulos sugeridos pela modalidade e pelos CIDs da perícia */
const modulosSugeridos = c => {
  const s = new Set(["geral"]), codes = (c.cids || []).map(x => x.c10 || "").filter(Boolean);
  const txt = [c.anamnese?.cid, c.anamnese?.localizacao, c.exame?.segmento].join(" ").toLowerCase();
  const has = (...p) => codes.some(cd => p.some(x => cd.startsWith(x)));
  if (has("F") || /depress|ansied|psic|esquizo|bipolar|mental/.test(txt)) s.add("psiq");
  if (has("G", "I60", "I61", "I62", "I63", "I64", "I69") || /avc|epilep|neuropat|parestes/.test(txt)) s.add("neuro");
  if (has("F0", "G30", "G31", "I69", "S06") || /demência|cognit|memória|tce/.test(txt)) s.add("snc");
  if (has("M40", "M41", "M42", "M43", "M45", "M46", "M47", "M48", "M50", "M51", "M53", "M54") || /lombar|cervical|coluna|ciát/.test(txt)) s.add("osteo_coluna");
  if (has("M75", "M77", "G56", "M65", "S4", "S5", "S6") || /ombro|cotovelo|punho|mão|carpo/.test(txt)) s.add("osteo_ms");
  if (has("M16", "M17", "M22", "M23", "S7", "S8", "S9") || /quadril|joelho|tornozelo|pé/.test(txt)) s.add("osteo_mi");
  if (codes.some(cd => /^I[0-5]/.test(cd) || /^I7/.test(cd))) s.add("cardio");
  if (has("J")) s.add("resp");
  if (has("K")) s.add("abd");
  if (codes.some(cd => /^H[0-5]/.test(cd))) s.add("oftalmo");
  if (codes.some(cd => /^H[6-9]/.test(cd))) s.add("otorrino");
  if (has("L", "T2", "T3")) s.add("derm");
  if (c.processo?.beneficio === "corpodelito") s.add("lesoes");
  return [...s];
};


/* ===================== AVALIAÇÃO DO PERITO (decisão exclusiva do perito; a IA só sugere) ===================== */
const OPC_DEC = l => [["", "— decidir —"], ...l.map(x => Array.isArray(x) ? x : [x, x])];
const F_AVALIACAO = [
  ["incap", "Incapacidade laborativa", "sel", OPC_DEC(["Sim", "Não"])],
  ["tipo", "Tipo da incapacidade", "sel", OPC_DEC(["Parcial", "Total", "Não se aplica"])],
  ["duracao", "Duração", "sel", OPC_DEC(["Temporária", "Permanente", "Não se aplica"])],
  ["percentual", "Percentual estimado de redução da capacidade (%)", "text"],
  ["did", "Data de início da doença (DID)", "text"],
  ["dii", "Data de início da incapacidade (DII)", "text"],
  ["nexo", "Nexo causal", "sel", OPC_DEC(["Sim", "Não", ["Indeterminado", "Indeterminado (dados insuficientes)"]])],
  ["concausa", "Concausa", "sel", OPC_DEC(["Sim", "Não"])],
  ["concausaGrau", "Grau da concausa", "sel", OPC_DEC([["Leve", "Leve (grau I)"], ["Moderado", "Moderado (grau II)"], ["Intenso", "Intenso (grau III)"], "Não se aplica"])],
  ["acidente", "Acidente de trabalho / doença ocupacional", "sel", OPC_DEC(["Sim", "Não", "Não se aplica"])],
  ["internacao", "Indicação de internação (Lei 10.216/2001)", "sel", OPC_DEC(["Indicada", "Não indicada"])],
  ["obs", "Observações do perito", "area"]
];
const avaliacaoTexto = c => {
  const a = c.avaliacao || {};
  return F_AVALIACAO.filter(([k]) => avalCampoVisivel(c, k)).map(([k, l]) => `- ${l}: ${String(a[k] ?? "").trim() || (k === "obs" ? "[sem observações]" : "[NÃO DEFINIDO PELO PERITO]")}`).join("\n");
};
const avalCampoVisivel = (c, k) => k !== "internacao" || c.processo?.beneficio === "internacao";
const avaliacaoPendentes = c => F_AVALIACAO.filter(([k]) => !["obs", "concausaGrau", "acidente"].includes(k) && avalCampoVisivel(c, k) && !String(c.avaliacao?.[k] ?? "").trim()).map(f => f[1]);

const migrarPromptsV6 = (steps, defSteps) => {
  const def = id => (defSteps || []).find(s => s.id === id)?.prompt || "";
  const entre = (t, a, b) => { const i = t.indexOf(a), j = t.indexOf(b, i + a.length); return i >= 0 && j > i ? t.slice(i + a.length, j) : ""; };
  const ins = (p, bloco, antes) => !bloco ? p : p.includes(antes) ? p.replace(antes, () => bloco + antes) : p + "\n\n" + bloco;
  const blocoConc = entre(def("conclusao"), "{{BENEFICIO}}\n\n", "MODELO:\n");
  const blocoQ = entre(def("quesitosJuizo"), "{{QUESITOS_JUIZO}}\n\n", "CONCLUSÃO JÁ REDIGIDA:");
  const blocoSec = entre(def("secoes"), "- Não escreva conclusão nesta etapa.\n\n", "MÓDULOS DE ANAMNESE");
  return (steps || []).map(s => {
    let p = s.prompt || "";
    if (s.id === "conclusao" && !p.includes("{{AVALIACAO_PERITO}}")) p = ins(p, blocoConc, "MODELO:\n");
    if ((s.id === "quesitosJuizo" || s.id === "quesitosPartes") && !p.includes("{{AVALIACAO_PERITO}}")) p = ins(p, blocoQ, "CONCLUSÃO JÁ REDIGIDA:");
    if (s.id === "secoes" && !p.includes("{{TIPO_LAUDO}}")) p = ins(p, blocoSec, "MÓDULOS DE ANAMNESE");
    return p === s.prompt ? s : { ...s, prompt: p };
  });
};


/* ===================== LAUDO COMPLEMENTAR (impugnação / esclarecimentos) ===================== */
const migrarAuxV7 = (aux, defAux) => {
  const t = aux?.complementar, d = defAux?.complementar || "", i = d.indexOf("\n\nORIGEM DO LAUDO ANTERIOR:");
  if (t && i > 0 && !t.includes("{{AUTOS_APOS_LAUDO}}")) aux.complementar = t + d.slice(i);
  return aux;
};
const DECISAO_COMP = c => ({ manter: "MANTER", alterar: "ALTERAR" })[c.complementar?.decisao] || "PENDENTE";


/* v8: sugestões fundamentadas (<sugerir>), etapa de internação, prompt de correções ditadas */
const migrarV8 = (pc, defSteps, defFormat) => {
  const OLD = 'escreva <red>Pendente: decisão do perito</red> e, logo depois, <investigar>sua sugestão técnica e os dados que faltam para embasá-la</investigar>. Nunca conclua esse ponto por conta própria.';
  const novaLinha = (defSteps.find(s => s.id === "conclusao")?.prompt || "").split("\n").find(l => l.includes("<sugerir campo")) || "";
  pc.steps = (pc.steps || []).map(s => {
    let p = s.prompt || "";
    if (novaLinha && p.includes(OLD)) p = p.split("\n").map(l => l.includes(OLD) ? novaLinha : l).join("\n");
    if (s.id === "conclusao" && !p.includes("{{SECAO:internacao}}")) {
      const d = (defSteps.find(x => x.id === "conclusao")?.prompt || ""), a = d.indexOf("AVALIAÇÃO PARA INTERNAÇÃO"), b = d.indexOf("FICHAMENTOS DOS DOCUMENTOS:");
      if (a > 0 && b > a) p = p.includes("FICHAMENTOS DOS DOCUMENTOS:") ? p.replace("FICHAMENTOS DOS DOCUMENTOS:", () => d.slice(a, b) + "FICHAMENTOS DOS DOCUMENTOS:") : p + "\n\n" + d.slice(a, b);
    }
    return p === s.prompt ? s : { ...s, prompt: p };
  });
  if (!pc.steps.some(s => s.id === "internacao")) { const d = defSteps.find(s => s.id === "internacao"); if (d) pc.steps.push(JSON.parse(JSON.stringify(d))); }
  if (pc.format && !pc.format.includes("<sugerir")) pc.format += "\n" + (defFormat || "").split("\n").find(l => l.includes("<sugerir")) ;
  return pc;
};

const indiretaTexto = c => { const x = c.indireta; if (!x?.sim) return ""; return `\nPERÍCIA INDIRETA: sim — informante: ${x.nome || "[nome não informado]"}${x.parentesco ? " (" + x.parentesco + ")" : ""}; motivo do não comparecimento do(a) periciando(a): ${x.motivo || "[não informado]"}.`; };
const migrarV9 = (pc, defFormat) => { if (pc.format && !pc.format.includes("PERÍCIA INDIRETA")) pc.format += "\n" + (defFormat || "").split("\n").find(l => l.startsWith("- PERÍCIA INDIRETA")); return pc; };

/* v10: indireta só na identificação, sem repetir seções, padrão fixo */
const migrarV10 = (pc, defFormat) => {
  if (!pc.format) return pc;
  const L = (defFormat || "").split("\n"), ind = L.find(l => l.startsWith("- PERÍCIA INDIRETA")), so = L.find(l => l.startsWith("- Redija SOMENTE")), pad = L.find(l => l.startsWith("- PADRÃO FIXO"));
  let f = pc.format.split("\n").map(l => l.startsWith("- PERÍCIA INDIRETA") && !l.includes("somente na etapa") ? ind : l).join("\n");
  if (so && !f.includes("- Redija SOMENTE")) f += "\n" + so;
  if (pad && !f.includes("PADRÃO FIXO")) f += "\n" + pad;
  pc.format = f; return pc;
};

/* v11: quadro "Dados da perícia" montado pela plataforma */
const migrarV11 = (pc, defSteps) => {
  const novo = (defSteps.find(s => s.id === "secoes")?.prompt || "").split("\n").find(l => l.startsWith('2) NÃO escreva "DADOS DA PERÍCIA"'));
  pc.steps = (pc.steps || []).map(s => s.id === "secoes" && novo && /^2\) "## DADOS DA PERÍCIA".*$/m.test(s.prompt || "") ? { ...s, prompt: s.prompt.replace(/^2\) "## DADOS DA PERÍCIA".*$/m, () => novo) } : s);
  return pc;
};

/* v12: exames, documentos e listas sempre em quadro */
const migrarV12 = (pc, defSteps, defFormat) => {
  const lin = (id, pre) => (defSteps.find(s => s.id === id)?.prompt || "").split("\n").find(l => l.startsWith(pre));
  const troca = (id, pre) => { const nv = lin(id, pre); if (!nv) return; pc.steps = pc.steps.map(s => s.id === id && s.prompt && !s.prompt.includes(nv) ? { ...s, prompt: s.prompt.split("\n").map(l => l.startsWith(pre) && !l.includes("quadro") ? nv : l).join("\n") } : s); };
  troca("secoes", "- Seção 4:"); troca("finais", '"## DOCUMENTOS E ARQUIVOS UTILIZADOS"');
  const q = (defFormat || "").split("\n").find(l => l.startsWith("- QUADROS:"));
  if (pc.format && q && !pc.format.includes("- QUADROS:")) pc.format += "\n" + q;
  return pc;
};

/* ---------- utilitários puros usados pelo servidor e pelo navegador ---------- */
const SH = (() => {
  const fmtDate = iso => { if (!iso) return ""; const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(iso); return m ? `${m[3]}/${m[2]}/${m[1]}` : iso; };
  const benefLabel = id => (BENEFICIOS.find(b => b[0] === id) || [, ""])[1];
  const CATS = [["processo", "Documentos da Justiça"], ["pessoais", "Documentos pessoais"], ["saude", "Documentos de saúde"], ["imagens", "Imagens e exames de imagem"], ["outros", "Outros"]];
  const catLabel = id => (CATS.find(c => c[0] === id) || [, "Outros"])[1];
  const getPath = (o, p) => p.split(".").reduce((a, k) => (a == null ? a : a[k]), o);
  const norm = s => String(s || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase();
  const cidLine = x => x.c10 ? `${x.d10} — CID-10 ${x.c10}${x.c11 ? ` / CID-11 ${x.c11}` : ""}` : `${x.d11} — CID-11 ${x.c11}`;
  const restr = (ref, v) => (v === "" || v == null || isNaN(+v)) ? "" : Math.max(0, Math.round((ref - +v) / ref * 100));
  function testesCount(t) {
    if (!t) return 0;
    return Object.values(t.res || {}).filter(r => r && r.r).length + Object.values(t.gonio || {}).flatMap(o => Object.values(o || {})).filter(g => g && (g.d || g.e)).length + Object.values(t.med || {}).filter(m => m && (m.d || m.e)).length + (t.dor && t.dor.valor !== "" && t.dor.valor != null ? 1 : 0);
  }
  function testesTexto(t) {
    t = t || {}; const res0 = t.res || {}, gon = t.gonio || {}, med = t.med || {}, dor = t.dor || {};
    const feitos = [], res = [];
    for (const seg of Object.values(TESTES)) for (const [id, nome] of seg.testes) {
      const r = res0[id]; if (!r || !r.r || r.r === "Não realizado") continue;
      feitos.push(`${nome}${r.lado ? " (" + r.lado + ")" : ""}`);
      res.push(`${nome}${r.lado ? " — " + r.lado : ""}: ${r.r}${r.obs ? " (" + r.obs + ")" : ""}`);
    }
    const g = [];
    for (const [gk, j] of Object.entries(GONIO)) for (const [mid, mn, ref, ax] of j.mov) {
      const v = (gon[gk] || {})[mid]; if (!v || (!v.d && !v.e)) continue;
      const parts = [];
      if (v.d !== "" && v.d != null) parts.push(`${ax ? "" : "D "}${v.d}° (restrição ${restr(ref, v.d)}%)`);
      if (!ax && v.e !== "" && v.e != null) parts.push(`E ${v.e}° (restrição ${restr(ref, v.e)}%)`);
      if (parts.length) g.push(`${j.nome} — ${mn}: ${parts.join("; ")}; referência ${ref}°`);
    }
    if (g.length) { feitos.push("Goniometria"); res.push("Goniometria (referência AAOS): " + g.join(" | ")); }
    for (const [id, nome, un, bil] of MEDIDAS) { const v = med[id]; if (!v || (!v.d && !v.e)) continue; const s = `${nome}: ${bil ? [v.d ? `D ${v.d} ${un}` : "", v.e ? `E ${v.e} ${un}` : ""].filter(Boolean).join("; ") : `${v.d} ${un}`}${v.obs ? " (" + v.obs + ")" : ""}`; feitos.push(nome); res.push(s); }
    if (dor.valor !== "" && dor.valor != null) { feitos.push(dor.escala === "END" ? "Escala numérica de dor" : "Escala visual analógica de dor"); res.push(`Dor (${dor.escala || "EVA"}): ${dor.valor}/10${dor.local ? " — " + dor.local : ""}${dor.obs ? " (" + dor.obs + ")" : ""}`); }
    const i = feitos.join("; "), jj = res.map(x => "- " + x).join("\n");
    return { i, j: jj, all: feitos.length ? `3.2 i) ${i}\n3.2 j)\n${jj}` : "" };
  }
  return { fmtDate, benefLabel, CATS, catLabel, getPath, norm, cidLine, restr, testesCount, testesTexto };
})();

  const api = { DEFAULT_PROFILE, TIPO_PADRAO, CAB_JEF, TAB_DOENCA, DEFAULT_QTEMPLATES, BENEFICIOS, F_PROCESSO, F_PERICIANDO, F_ANAMNESE, FUNC_OPTS, F_EXAME, QUESITO_GRUPOS, TESTES, TEST_RES, MEDIDAS, GONIO, GONIO_SEG, DEFAULT_PADRAO, DEFAULT_PROFILE_PERITO, tierFor, prepDocText, DEFAULT_MODULOS, modulosSugeridos, OPC_DEC, F_AVALIACAO, avaliacaoTexto, avalCampoVisivel, avaliacaoPendentes, migrarPromptsV6, migrarAuxV7, DECISAO_COMP, migrarV8, indiretaTexto, migrarV9, migrarV10, migrarV11, migrarV12, SH };
  if (typeof module !== "undefined" && module.exports) module.exports = api; else Object.assign(root, api);
})(typeof window !== "undefined" ? window : globalThis);
